"""Standalone script: reproduce Figure 3-8a & 3-8b — Average attack depth
and Average session duration across honeypot methods.

Reads per-method summary data from ``summary.csv`` and per-session
Baseline-1 data from ``baseline1_session.csv`` (both alongside this
script).

Outputs:
    ``3-8a.png`` + ``3-8a.pdf``
    ``3-8b.png`` + ``3-8b.pdf``

Figure size:
    10 : 7

The PNG/PDF output uses ``bbox_inches="tight"`` consistently with
Figure 3-7.

Usage:
    conda activate day0812
    python plot_3_8ab.py
"""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path
from statistics import mean, stdev

import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
# Constants — keep identical to the original reporter.py
# ---------------------------------------------------------------------------

SESSION_MINUTES_PER_ROUND = 2.5


# ---------------------------------------------------------------------------
# Publication colors
#
# These colors and hatch patterns are kept consistent with the original
# Figure 3-8 style and the revised Figure 3-7 style.
# ---------------------------------------------------------------------------

ATTACK_DEPTH_COLORS = {
    "Baseline-1": "#7A8FA6",
    "Baseline-2": "#9BB7C9",
    "Baseline-3": "#89A99A",
    "AdvancedShelLM": "#8F79B7",
    "Proposed-2": "#C58F7A",
    "Proposed-5": "#D2B86A",
}


ATTACK_DEPTH_PATTERNS = {
    "Baseline-1": "///",
    "Baseline-2": "...",
    "Baseline-3": "+++",
    "AdvancedShelLM": "oo",
    "Proposed-2": "xxx",
    "Proposed-5": "\\\\",
}


ATTACK_DEPTH_EDGE_COLOR = "#444444"


# ---------------------------------------------------------------------------
# Display labels
# ---------------------------------------------------------------------------

DISPLAY_LABELS = {
    "AdvancedShelLM": "Baseline-4",
}


def _display_label(method: str) -> str:
    """Map internal method names to publication display names."""

    return DISPLAY_LABELS.get(method, method)


# ---------------------------------------------------------------------------
# Data paths
# ---------------------------------------------------------------------------

DATA_DIR = Path(__file__).resolve().parent

SUMMARY_CSV = DATA_DIR / "summary.csv"

BASELINE1_CSV = DATA_DIR / "baseline1_session.csv"

CHECKPOINT_JSONL = DATA_DIR / "checkpoint.jsonl"


# ---------------------------------------------------------------------------
# Data helpers
# ---------------------------------------------------------------------------

@dataclass
class Summary:
    """Per-method aggregate statistics loaded from ``summary.csv``."""

    method: str
    average_attack_depth: float
    attack_depth_std: float
    sessions: int
    average_session_rounds: float
    session_rounds_std: float


def _session_rounds_stds(
    jsonl_path: Path
) -> dict[str, float]:
    """Per-method session-rounds std, recomputed from ``checkpoint.jsonl``.

    ``summary.csv`` exposes ``average_session_rounds`` but not the
    corresponding standard deviation, so the per-session rounds are
    recomputed here to restore the Figure 3-8b error bars.
    """

    rounds: dict[str, list[float]] = {}

    if not jsonl_path.exists():
        return {}

    for line in jsonl_path.open(encoding="utf-8"):

        line = line.strip()

        if not line:
            continue

        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue

        method = record.get("method")

        if method is None:
            continue

        rounds.setdefault(
            method,
            []
        ).append(
            float(record["session_rounds"])
        )

    return {
        method: stdev(values)
        for method, values in rounds.items()
        if len(values) > 1
    }


def load_summaries(
    csv_path: Path,
    rounds_jsonl_path: Path,
) -> list[Summary]:
    """Read per-method summaries from ``summary.csv`` and ``checkpoint.jsonl``."""

    rounds_stds = _session_rounds_stds(
        rounds_jsonl_path
    )

    summaries: list[Summary] = []

    with csv_path.open(
        encoding="utf-8-sig",
        newline=""
    ) as handle:

        for row in csv.DictReader(handle):

            method = row["method"]

            summaries.append(
                Summary(
                    method=method,
                    average_attack_depth=float(
                        row["average_attack_depth"]
                    ),
                    attack_depth_std=float(
                        row["attack_depth_std"]
                    ),
                    sessions=int(
                        row["sessions"]
                    ),
                    average_session_rounds=float(
                        row["average_session_rounds"]
                    ),
                    session_rounds_std=rounds_stds.get(
                        method,
                        0.0
                    ),
                )
            )

    return summaries


def load_baseline1(
    csv_path: Path
) -> list[dict[str, str]]:
    """Read baseline1_session.csv if it exists."""

    if not csv_path.exists():
        return []

    with csv_path.open(
        encoding="utf-8-sig",
        newline=""
    ) as handle:

        return list(csv.DictReader(handle))


# ---------------------------------------------------------------------------
# Plot configuration
# ---------------------------------------------------------------------------

def configure_plot() -> None:
    """Global matplotlib style matching the paper's publication format."""

    plt.rcParams.update({

        # ---------------------------------------------------------------
        # Font
        # ---------------------------------------------------------------
        "font.family": "Times New Roman",
        "font.size": 20,

        # ---------------------------------------------------------------
        # Axis
        # ---------------------------------------------------------------
        "axes.labelsize": 24,
        "axes.linewidth": 1.4,

        "axes.spines.top": True,
        "axes.spines.right": True,

        # ---------------------------------------------------------------
        # Grid
        # ---------------------------------------------------------------
        "axes.grid": True,
        "axes.axisbelow": True,

        # ---------------------------------------------------------------
        # Tick labels
        # ---------------------------------------------------------------
        "xtick.labelsize": 20,
        "ytick.labelsize": 20,

        "xtick.major.width": 1.2,
        "ytick.major.width": 1.2,

        "xtick.major.size": 7,
        "ytick.major.size": 7,

        "xtick.direction": "out",
        "ytick.direction": "out",

        # ---------------------------------------------------------------
        # Grid style
        # ---------------------------------------------------------------
        "grid.linewidth": 0.9,
        "grid.linestyle": "--",
        "grid.alpha": 0.3,

        # ---------------------------------------------------------------
        # Legend
        # ---------------------------------------------------------------
        "legend.fontsize": 20,

        # ---------------------------------------------------------------
        # Output resolution
        # ---------------------------------------------------------------
        "figure.dpi": 150,
        "savefig.dpi": 600,
    })


# ---------------------------------------------------------------------------
# Common formatting helper
# ---------------------------------------------------------------------------

def format_axes(ax) -> None:
    """Apply common axis/spine/tick formatting."""

    # -----------------------------------------------------------------------
    # Spines
    # -----------------------------------------------------------------------

    for spine in ax.spines.values():

        spine.set_color(
            ATTACK_DEPTH_EDGE_COLOR
        )

        spine.set_linewidth(2.0)

    # -----------------------------------------------------------------------
    # Tick parameters
    # -----------------------------------------------------------------------

    ax.tick_params(
        axis="both",
        which="both",
        direction="out",
        width=1.2,
        length=7,
        labelsize=22,
    )

    ax.tick_params(
        axis="y",
        which="major",
        width=1.2,
        length=7,
    )

    # -----------------------------------------------------------------------
    # Force Times New Roman
    # -----------------------------------------------------------------------

    for tick_label in (
        *ax.get_xticklabels(),
        *ax.get_yticklabels()
    ):

        tick_label.set_fontname(
            "Times New Roman"
        )

    # -----------------------------------------------------------------------
    # Grid
    # -----------------------------------------------------------------------

    ax.grid(
        True,
        axis="y",
        linestyle="--",
        alpha=0.3,
    )

    ax.grid(
        False,
        axis="x",
    )


# ---------------------------------------------------------------------------
# Figure 3-8a
# ---------------------------------------------------------------------------

def plot_figure_3_8a(
    summaries: list[Summary],
    baseline1_rows: list[dict[str, str]],
    output_dir: Path,
) -> None:
    """Bar chart: average completed attack stages per method with 95% CI."""

    configure_plot()

    # -----------------------------------------------------------------------
    # Calculate data
    # -----------------------------------------------------------------------

    labels: list[str] = []

    means: list[float] = []

    ci95: list[float] = []

    # -----------------------------------------------------------------------
    # Baseline-1
    # -----------------------------------------------------------------------

    if baseline1_rows:

        depths = [
            float(row["attack_depth"])
            for row in baseline1_rows
        ]

        if len(depths) != 30:

            raise ValueError(
                "Baseline-1 replay must contain exactly 30 sessions"
            )

        labels.append("Baseline-1")

        means.append(
            mean(depths)
        )

        baseline1_std = stdev(depths)

        ci95.append(
            1.96
            * baseline1_std
            / (len(depths) ** 0.5)
        )

    # -----------------------------------------------------------------------
    # Other methods (summary.csv)
    # -----------------------------------------------------------------------

    for item in summaries:

        labels.append(item.method)

        means.append(item.average_attack_depth)

        if item.sessions > 1:

            ci95.append(
                1.96
                * item.attack_depth_std
                / (item.sessions ** 0.5)
            )

        else:

            ci95.append(0.0)

    # -----------------------------------------------------------------------
    # Figure
    #
    # IMPORTANT:
    # Keep 10:7 aspect ratio.
    # -----------------------------------------------------------------------

    fig, ax = plt.subplots(
        figsize=(10, 7)
    )

    positions = list(
        range(len(labels))
    )

    # -----------------------------------------------------------------------
    # Bars
    # -----------------------------------------------------------------------

    bars = ax.bar(
        positions,
        means,

        width=0.36,

        color=[
            ATTACK_DEPTH_COLORS[label]
            for label in labels
        ],

        edgecolor=ATTACK_DEPTH_EDGE_COLOR,

        linewidth=1.2,

        yerr=ci95,

        capsize=5,

        error_kw={
            "ecolor": ATTACK_DEPTH_EDGE_COLOR,
            "elinewidth": 1.4,
            "capthick": 1.4,
        },
    )

    # -----------------------------------------------------------------------
    # Hatch patterns
    # -----------------------------------------------------------------------

    for bar, label in zip(
        bars,
        labels
    ):

        bar.set_hatch(
            ATTACK_DEPTH_PATTERNS[label]
        )

    # -----------------------------------------------------------------------
    # Value labels
    # -----------------------------------------------------------------------

    for position, value, error in zip(
        positions,
        means,
        ci95
    ):

        ax.text(
            position,

            value + error + 0.08,

            f"{value:.2f}",

            ha="center",
            va="bottom",

            fontsize=17,

            fontname="Times New Roman",
        )

    # -----------------------------------------------------------------------
    # Axes
    # -----------------------------------------------------------------------

    ax.set_xticks(
        positions,
        [_display_label(label) for label in labels]
    )

    ax.set_xlim(
        -0.5,
        len(labels) - 0.5
    )

    ax.set_ylim(
        0,
        4
    )

    ax.set_yticks(
        (0, 1, 2, 3, 4)
    )

    ax.set_ylabel(
        "Completed attack stages",
        fontsize=26,
        fontname="Times New Roman",
    )

    # -----------------------------------------------------------------------
    # Formatting
    # -----------------------------------------------------------------------

    format_axes(ax)

    # -----------------------------------------------------------------------
    # Layout
    #
    # Same principle as Figure 3-7:
    # use tight bounding-box cropping when saving.
    # -----------------------------------------------------------------------

    fig.tight_layout()

    # -----------------------------------------------------------------------
    # Save PNG + PDF
    # -----------------------------------------------------------------------

    png_path = output_dir / "3-8a.png"

    pdf_path = output_dir / "3-8a.pdf"

    fig.savefig(
        png_path,
        bbox_inches="tight",
        facecolor="white",
        dpi=600,
    )

    fig.savefig(
        pdf_path,
        format="pdf",
        bbox_inches="tight",
        facecolor="white",
    )

    plt.close(fig)

    print("Figure 3-8a saved:")

    print(
        f"  {png_path.resolve()}"
    )

    print(
        f"  {pdf_path.resolve()}"
    )


# ---------------------------------------------------------------------------
# Figure 3-8b
# ---------------------------------------------------------------------------

def plot_figure_3_8b(
    summaries: list[Summary],
    baseline1_rows: list[dict[str, str]],
    output_dir: Path,
) -> None:
    """Bar chart: round-derived session duration per method with 95% CI."""

    configure_plot()

    # -----------------------------------------------------------------------
    # Calculate data
    # -----------------------------------------------------------------------

    labels: list[str] = []

    means: list[float] = []

    ci95: list[float] = []

    # -----------------------------------------------------------------------
    # Baseline-1
    # -----------------------------------------------------------------------

    if baseline1_rows:

        baseline1_rounds = [
            float(row["session_rounds"])
            for row in baseline1_rows
        ]

        if len(baseline1_rounds) != 30:

            raise ValueError(
                "Baseline-1 replay must contain exactly 30 sessions"
            )

        labels.append("Baseline-1")

        means.append(
            mean(baseline1_rounds)
            * SESSION_MINUTES_PER_ROUND
        )

        ci95.append(
            1.96
            * stdev(baseline1_rounds)
            / (len(baseline1_rounds) ** 0.5)
            * SESSION_MINUTES_PER_ROUND
        )

    # -----------------------------------------------------------------------
    # Other methods (summary.csv + checkpoint.jsonl)
    # -----------------------------------------------------------------------

    for item in summaries:

        labels.append(item.method)

        means.append(
            item.average_session_rounds
            * SESSION_MINUTES_PER_ROUND
        )

        if item.sessions > 1:

            ci95.append(
                1.96
                * item.session_rounds_std
                / (item.sessions ** 0.5)
                * SESSION_MINUTES_PER_ROUND
            )

        else:

            ci95.append(0.0)

    # -----------------------------------------------------------------------
    # Figure
    #
    # IMPORTANT:
    # Keep exactly the same 10:7 aspect ratio as Figure 3-9a / 3-7.
    # -----------------------------------------------------------------------

    fig, ax = plt.subplots(
        figsize=(10, 7)
    )

    positions = list(
        range(len(labels))
    )

    # -----------------------------------------------------------------------
    # Bars
    # -----------------------------------------------------------------------

    bars = ax.bar(
        positions,
        means,

        width=0.36,

        color=[
            ATTACK_DEPTH_COLORS[label]
            for label in labels
        ],

        edgecolor=ATTACK_DEPTH_EDGE_COLOR,

        linewidth=1.2,

        yerr=ci95,

        capsize=5,

        error_kw={
            "ecolor": ATTACK_DEPTH_EDGE_COLOR,
            "elinewidth": 1.4,
            "capthick": 1.4,
        },
    )

    # -----------------------------------------------------------------------
    # Hatch patterns
    # -----------------------------------------------------------------------

    for bar, label in zip(
        bars,
        labels
    ):

        bar.set_hatch(
            ATTACK_DEPTH_PATTERNS[label]
        )

    # -----------------------------------------------------------------------
    # Value labels
    # -----------------------------------------------------------------------

    for position, value, error in zip(
        positions,
        means,
        ci95
    ):

        ax.text(
            position,

            value + error + 0.15,

            f"{value:.2f}",

            ha="center",
            va="bottom",

            fontsize=17,

            fontname="Times New Roman",
        )

    # -----------------------------------------------------------------------
    # Axes
    # -----------------------------------------------------------------------

    ax.set_xticks(
        positions,
        [_display_label(label) for label in labels]
    )

    ax.set_xlim(
        -0.5,
        len(labels) - 0.5
    )

    ax.set_ylim(
        0,
        12
    )

    ax.set_yticks(
        (0, 2, 4, 6, 8, 10, 12)
    )

    ax.set_ylabel(
        "Session duration (min)",
        fontsize=26,
        fontname="Times New Roman",
    )

    # -----------------------------------------------------------------------
    # Formatting
    # -----------------------------------------------------------------------

    format_axes(ax)

    # -----------------------------------------------------------------------
    # Layout
    # -----------------------------------------------------------------------

    fig.tight_layout()

    # -----------------------------------------------------------------------
    # Save PNG + PDF
    #
    # IMPORTANT:
    # bbox_inches="tight" makes the exported PDF cropped to the actual
    # figure contents, consistent with Figure 3-7.
    # -----------------------------------------------------------------------

    png_path = output_dir / "3-8b.png"

    pdf_path = output_dir / "3-8b.pdf"

    fig.savefig(
        png_path,
        bbox_inches="tight",
        facecolor="white",
        dpi=600,
    )

    fig.savefig(
        pdf_path,
        format="pdf",
        bbox_inches="tight",
        facecolor="white",
    )

    plt.close(fig)

    print("Figure 3-8b saved:")

    print(
        f"  {png_path.resolve()}"
    )

    print(
        f"  {pdf_path.resolve()}"
    )


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:

    # -----------------------------------------------------------------------
    # Check summary data
    # -----------------------------------------------------------------------

    if not SUMMARY_CSV.exists():

        raise SystemExit(
            f"Data file not found: {SUMMARY_CSV.resolve()}"
        )

    # -----------------------------------------------------------------------
    # Load data
    # -----------------------------------------------------------------------

    summaries = load_summaries(
        SUMMARY_CSV,
        CHECKPOINT_JSONL
    )

    baseline1_rows = load_baseline1(
        BASELINE1_CSV
    )

    print(
        f"Loaded {len(summaries)} method summaries "
        f"from {SUMMARY_CSV}"
    )

    if baseline1_rows:

        print(
            f"Loaded {len(baseline1_rows)} "
            f"Baseline-1 records "
            f"from {BASELINE1_CSV}"
        )

    else:

        print(
            f"Baseline-1 data not found at "
            f"{BASELINE1_CSV} — skipping Baseline-1 bar"
        )

    # -----------------------------------------------------------------------
    # Output directory
    # -----------------------------------------------------------------------

    output_dir = Path.cwd()

    # -----------------------------------------------------------------------
    # Generate Figure 3-8a
    # -----------------------------------------------------------------------

    plot_figure_3_8a(
        summaries,
        baseline1_rows,
        output_dir
    )

    # -----------------------------------------------------------------------
    # Generate Figure 3-8b
    # -----------------------------------------------------------------------

    plot_figure_3_8b(
        summaries,
        baseline1_rows,
        output_dir
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    main()