
from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

# --------------------------------------------------------------------------
# Plot styling (mirrors reporter.py)
# --------------------------------------------------------------------------
PLOT_SCALE = 1.2

REPORT_METHODS = (
    "Baseline-2", "Baseline-3", "Single-Agent-GPT-5.1", "AdvancedShelLM",
    "Proposed-2", "Proposed-5",
)

DISPLAY_LABELS = {
    "AdvancedShelLM": "Baseline-4",
    "Single-Agent-GPT-5.1": "Single-Agent\nGPT-5.1",
}


def _display_label(method: str) -> str:
    return DISPLAY_LABELS.get(method, method)


def _pyplot():
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams.update(
        {
            "font.family": "Times New Roman",
                    "font.size": 20,
                    "axes.labelsize": 24,
                    "axes.linewidth": 1.2,
                    "axes.spines.top": True,
                    "axes.spines.right": True,
                    "axes.grid": True,
                    "axes.axisbelow": True,
                    "xtick.labelsize": 20,
                    "ytick.labelsize": 20,
                    "xtick.major.width": 1.2,
                    "ytick.major.width": 1.2,
                    "xtick.major.size": 7,
                    "ytick.major.size": 7,
                    "xtick.direction": "out",
                    "ytick.direction": "out",
                    "grid.linewidth": 0.9,
                    "grid.linestyle": "--",
                    "grid.alpha": 0.4,
                    "legend.fontsize": 20,
                    "figure.dpi": 150,
                    "savefig.dpi": 600,
        }
    )
    return plt


def _save_figure(fig, path: Path) -> None:
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight", facecolor="white")


def _clean_log_ticks(axis, lower: float, upper: float) -> None:
    """Use sparse numeric labels on a log axis and suppress minor tick clutter."""

    from matplotlib.ticker import FixedLocator, FuncFormatter, NullLocator

    ticks: list[float] = []
    start = math.floor(math.log10(lower)) - 1
    stop = math.ceil(math.log10(upper)) + 1
    for exponent in range(start, stop + 1):
        for multiplier in (1, 3):
            value = multiplier * (10 ** exponent)
            if lower <= value <= upper:
                ticks.append(float(value))
    axis.set_major_locator(FixedLocator(ticks))
    axis.set_major_formatter(FuncFormatter(lambda value, _pos: f"{value:,.0f}"))
    axis.set_minor_locator(NullLocator())


@dataclass(frozen=True)
class SessionResult:
    task_id: str
    method: str
    interaction_tokens: int
    supervision_tokens: int
    coordination_tokens: int


@dataclass(frozen=True)
class MethodSummary:
    method: str
    interaction_tokens: int
    supervision_tokens: int
    coordination_tokens: int


def _ordered(results: Iterable[SessionResult]) -> tuple[SessionResult, ...]:
    method_order = {method: index for index, method in enumerate(REPORT_METHODS)}
    rows = tuple(
        sorted(results, key=lambda item: (method_order[item.method], item.task_id))
    )
    if not rows:
        raise ValueError("at least one SessionResult is required")
    keys = [(row.task_id, row.method) for row in rows]
    if len(keys) != len(set(keys)):
        raise ValueError("duplicate task/method session results are not allowed")
    return rows


def summarize(results: Iterable[SessionResult]) -> tuple[MethodSummary, ...]:
    rows = _ordered(results)
    summaries: list[MethodSummary] = []
    for method in REPORT_METHODS:
        group = [row for row in rows if row.method == method]
        if not group:
            continue
        summaries.append(
            MethodSummary(
                method=method,
                interaction_tokens=sum(row.interaction_tokens for row in group),
                supervision_tokens=sum(row.supervision_tokens for row in group),
                coordination_tokens=sum(row.coordination_tokens for row in group),
            )
        )
    return tuple(summaries)


def load_results(checkpoint_path: Path) -> list[SessionResult]:
    """Rebuild ``SessionResult`` objects from ``checkpoint.jsonl``."""
    results: list[SessionResult] = []
    with checkpoint_path.open(encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            row = json.loads(line)
            results.append(
                SessionResult(
                    task_id=row["task_id"],
                    method=row["method"],
                    interaction_tokens=int(row["interaction_tokens"]),
                    supervision_tokens=int(row["supervision_tokens"]),
                    coordination_tokens=int(row["coordination_tokens"]),
                )
            )
    return results


def plot_token_breakdown(
    results: Iterable[SessionResult], output_dir: Path
) -> Path:
    summary_by_method = {item.method: item for item in summarize(results)}
    # Keep the original methods together and place the newly added cooperative
    # baseline at the far right in Figure 3-9(b).
    breakdown_order = (
        "Baseline-2", "Baseline-3", "Single-Agent-GPT-5.1", "Proposed-2",
        "Proposed-5", "AdvancedShelLM"
    )
    summaries = tuple(
        summary_by_method[method]
        for method in breakdown_order
        if method in summary_by_method
    )
    plt = _pyplot()
    fig, ax = plt.subplots(figsize=(10, 7))
    labels = [item.method for item in summaries]
    interaction = [item.interaction_tokens for item in summaries]
    supervision = [item.supervision_tokens for item in summaries]
    # Keep the original two-category visual definition.  AdvancedShelLM's
    # Manager supervision and Proposed-5's cross-tier orchestration remain
    # separately available in summary.csv, but both are cooperative overhead
    # in the publication figure.
    coordination = [
        item.supervision_tokens + item.coordination_tokens for item in summaries
    ]
    positions = range(len(labels))
    ax.bar(
        positions, interaction, width=0.6,
        color="#8DB4E2",           # 填充底色
        edgecolor="#2E75B6",       # 边框和斜线颜色
        hatch="////",              # 斜线图案
        linewidth=1.2,             # 边框粗细
        label="Interaction",
        zorder=3,
    )
    ax.bar(
        positions, coordination, width=0.6, bottom=interaction,
        color="#92D050",           # 填充底色
        edgecolor="#548235",       # 边框和点阵颜色
        hatch="....",              # 点阵图案
        linewidth=1.2,
        label="Coordination",
        zorder=3,
    )
    totals = [
        interaction_tokens + coordination_tokens
        for interaction_tokens, coordination_tokens in zip(interaction, coordination)
    ]
    for position, total in zip(positions, totals):
        ax.text(
            position,
            total * 1.018,
            f"{total:,}",
            ha="center",
            va="bottom",
            fontsize=17,
            fontname="Times New Roman",
        )
    ax.set_xticks(list(positions), [_display_label(label) for label in labels])
    ax.tick_params(axis="x", labelsize=18)
    use_log_scale = max(totals) / min(totals) >= 8
    if use_log_scale:
        ax.set_yscale("log")
        ax.set_ylim(min(totals) * 0.72, max(totals) * 1.35)
        _clean_log_ticks(ax.yaxis, min(totals) * 0.72, max(totals) * 1.35)
    else:
        ax.set_ylim(0, max(totals) * 1.12)
    ax.set_ylabel("Total tokens")
    ax.legend()
    ax.grid(True, axis="both")
    ax.tick_params(axis="both", which="both", direction="out", width=1.0, length=4)
    path = output_dir / "token_breakdown.pdf"
    _save_figure(fig, path)
    plt.close(fig)
    return path


def main() -> None:
    output_dir = Path(__file__).resolve().parent
    results = load_results(output_dir / "checkpoint.jsonl")
    path = plot_token_breakdown(results, output_dir)
    print(f"Saved figure to {path}")


if __name__ == "__main__":
    main()
