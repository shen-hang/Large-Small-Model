

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from statistics import mean
from typing import Iterable

# --------------------------------------------------------------------------
# Plot styling (mirrors reporter.py)
# --------------------------------------------------------------------------
PLOT_SCALE = 1.2
SESSION_MINUTES_PER_ROUND = 2.5

REPORT_METHODS = (
    "Baseline-2", "Baseline-3", "Single-Agent-GPT-5.1", "AdvancedShelLM",
    "Proposed-2", "Proposed-5",
)

ATTACK_DEPTH_COLORS = {
    "Baseline-1": "#7A8FA6",
    "Baseline-2": "#9BB7C9",
    "Baseline-3": "#89A99A",
    "Single-Agent-GPT-5.1": "#B89A88",
    "AdvancedShelLM": "#8F79B7",
    "Proposed-2": "#C58F7A",
    "Proposed-5": "#D2B86A",
}
ATTACK_DEPTH_EDGE_COLOR = "#444444"
METHOD_MARKERS = {
    "Baseline-2": "o",
    "Baseline-3": "s",
    "Single-Agent-GPT-5.1": "P",
    "AdvancedShelLM": "D",
    "Proposed-2": "^",
    "Proposed-5": "v",
}

DISPLAY_LABELS = {
    "AdvancedShelLM": "Baseline-4",
    "Single-Agent-GPT-5.1": "Single-Agent\nGPT-5.1",
}


def _display_label(method: str) -> str:
    return DISPLAY_LABELS.get(method, method)


def _pyplot():
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams.update(
        {
            "font.family": "Times New Roman",
            "font.size": 20,
            "axes.labelsize": 24,
            "axes.linewidth": 1.2,
            "axes.spines.top": True,
            "axes.spines.right": True,
            "axes.grid": True,
            "axes.axisbelow": True,
            "xtick.labelsize": 20,
            "ytick.labelsize": 20,
            "xtick.major.width": 1.2,
            "ytick.major.width": 1.2,
            "xtick.major.size": 7,
            "ytick.major.size": 7,
            "xtick.direction": "out",
            "ytick.direction": "out",
            "grid.linewidth": 0.9,
            "grid.linestyle": "--",
            "grid.alpha": 0.4,
            "legend.fontsize": 20,
            "figure.dpi": 150,
            "savefig.dpi": 600,
        }
    )
    return plt


def _save_figure(fig, path: Path) -> None:
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight", facecolor="white")


def _clean_log_ticks(axis, lower: float, upper: float) -> None:
    """Use sparse numeric labels on a log axis and suppress minor tick clutter."""

    from matplotlib.ticker import FixedLocator, FuncFormatter, NullLocator

    ticks: list[float] = []
    start = math.floor(math.log10(lower)) - 1
    stop = math.ceil(math.log10(upper)) + 1
    for exponent in range(start, stop + 1):
        for multiplier in (1, 3):
            value = multiplier * (10 ** exponent)
            if lower <= value <= upper:
                ticks.append(float(value))
    axis.set_major_locator(FixedLocator(ticks))
    axis.set_major_formatter(FuncFormatter(lambda value, _pos: f"{value:,.0f}"))
    axis.set_minor_locator(NullLocator())


@dataclass(frozen=True)
class SessionResult:
    task_id: str
    method: str
    overall_tokens: int
    session_rounds: int


@dataclass(frozen=True)
class MethodSummary:
    method: str
    average_overall_tokens: float
    average_session_rounds: float


def _ordered(results: Iterable[SessionResult]) -> tuple[SessionResult, ...]:
    method_order = {method: index for index, method in enumerate(REPORT_METHODS)}
    rows = tuple(
        sorted(results, key=lambda item: (method_order[item.method], item.task_id))
    )
    if not rows:
        raise ValueError("at least one SessionResult is required")
    keys = [(row.task_id, row.method) for row in rows]
    if len(keys) != len(set(keys)):
        raise ValueError("duplicate task/method session results are not allowed")
    return rows


def summarize(results: Iterable[SessionResult]) -> tuple[MethodSummary, ...]:
    rows = _ordered(results)
    summaries: list[MethodSummary] = []
    for method in REPORT_METHODS:
        group = [row for row in rows if row.method == method]
        if not group:
            continue
        summaries.append(
            MethodSummary(
                method=method,
                average_overall_tokens=mean(row.overall_tokens for row in group),
                average_session_rounds=mean(row.session_rounds for row in group),
            )
        )
    return tuple(summaries)


def load_results(checkpoint_path: Path) -> list[SessionResult]:
    """Rebuild ``SessionResult`` objects from ``checkpoint.jsonl``."""
    results: list[SessionResult] = []
    with checkpoint_path.open(encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            row = json.loads(line)
            results.append(
                SessionResult(
                    task_id=row["task_id"],
                    method=row["method"],
                    overall_tokens=int(row["overall_tokens"]),
                    session_rounds=int(row["session_rounds"]),
                )
            )
    return results


def _plot_token_cost_tradeoff(
    labels: list[str],
    average_tokens: list[float],
    performance: list[float],
    ylabel: str,
    path: Path,
) -> Path:
    """Draw the resource/performance trade-off without collapsing it to a ratio."""

    plt = _pyplot()
    fig, ax = plt.subplots(figsize=(10, 7))
    for label, tokens, value in zip(labels, average_tokens, performance):
        ax.scatter(
            tokens,
            value,
            s=150,
            marker=METHOD_MARKERS[label],
            color=ATTACK_DEPTH_COLORS[label],
            edgecolor=ATTACK_DEPTH_EDGE_COLOR,
            linewidth=1.4,
            zorder=3,
        )
    token_ratio = max(average_tokens) / min(average_tokens)
    x_padding = (max(average_tokens) - min(average_tokens)) * 0.12
    y_padding = (max(performance) - min(performance)) * 0.22
    use_log_x = token_ratio >= 8
    if use_log_x:
        x_min = min(average_tokens) * 0.78
        x_max = max(average_tokens) * 1.28
        ax.set_xscale("log")
        ax.set_xlim(x_min, x_max)
        _clean_log_ticks(ax.xaxis, x_min, x_max)
    else:
        x_min = min(average_tokens) - x_padding
        x_max = max(average_tokens) + x_padding
        ax.set_xlim(x_min, x_max)
    y_min = min(performance) - y_padding
    y_max = max(performance) + y_padding
    ax.set_ylim(y_min, y_max)

    # Projection drop-lines from each marker down to the x-axis and across to
    # the y-axis, in a light gray that stands out slightly from the grid.
    left_edge = ax.get_xlim()[0]
    bottom_edge = ax.get_ylim()[0]
    for tokens, value in zip(average_tokens, performance):
        ax.plot(
            [tokens, tokens],
            [bottom_edge, value],
            color="#808080",
            linestyle="--",
            linewidth=1.0,
            alpha=1.0,
            zorder=2,
        )
        ax.plot(
            [left_edge, tokens],
            [value, value],
            color="#808080",
            linestyle="--",
            linewidth=1.0,
            alpha=1.0,
            zorder=2,
        )

    # Fixed lower-right placement for the two methods whose adaptive labels
    # would otherwise collide.
    fixed_positions = {
        "Baseline-2": (12, -10, "left", "top"),
        "Proposed-2": (12, -10, "left", "top"),
    }
    for label, tokens, value in zip(labels, average_tokens, performance):
        if label in fixed_positions:
            dx, dy, ha, va = fixed_positions[label]
        else:
            # Place each label in the quadrant away from the nearest borders
            # so it never crosses outside the axes.
            if use_log_x:
                x_frac = (math.log10(tokens) - math.log10(x_min)) / (
                    math.log10(x_max) - math.log10(x_min)
                )
            else:
                x_frac = (tokens - x_min) / (x_max - x_min)
            y_frac = (value - y_min) / (y_max - y_min)
            left = x_frac > 0.5
            below = y_frac > 0.5
            dx = -12 if left else 12
            dy = -10 if below else 10
            ha = "right" if left else "left"
            va = "top" if below else "bottom"
        ax.annotate(
            f"{_display_label(label)} ({tokens:.0f}, {value:.2f})",
            xy=(tokens, value),
            xytext=(dx, dy),
            textcoords="offset points",
            ha=ha,
            va=va,
            fontsize=19,
            fontname="Times New Roman",
        )
    ax.set_xlabel("Average tokens per task")
    ax.set_ylabel(ylabel)
    for spine in ax.spines.values():
        spine.set_color(ATTACK_DEPTH_EDGE_COLOR)
        spine.set_linewidth(1.0)
    ax.tick_params(
        axis="both", which="both", direction="out", width=1.2, length=7
    )
    ax.tick_params(axis="y", which="major", width=1.2, length=7)
    ax.grid(True, axis="both", linestyle="--", alpha=0.3)
    _save_figure(fig, path)
    plt.close(fig)
    return path


def plot_token_cost_vs_estimated_interaction_duration(
    results: Iterable[SessionResult], output_dir: Path
) -> Path:
    """Plot token cost against round-derived estimated interaction duration."""

    summaries = summarize(results)
    return _plot_token_cost_tradeoff(
        [item.method for item in summaries],
        [item.average_overall_tokens for item in summaries],
        [
            item.average_session_rounds * SESSION_MINUTES_PER_ROUND
            for item in summaries
        ],
        "Average session duration (min)",
        output_dir / "token_cost_vs_estimated_interaction_duration.pdf",
    )


def main() -> None:
    output_dir = Path(__file__).resolve().parent
    results = load_results(output_dir / "checkpoint.jsonl")
    path = plot_token_cost_vs_estimated_interaction_duration(results, output_dir)
    print(f"Saved figure to {path}")


if __name__ == "__main__":
    main()
