"""Standalone script: reproduce Figure 3-7a & 3-7b — similarity Score (%)
across four text-similarity metrics for the original vanilla and fine-tuned
vanilla models.

Reads ``Fig3-7_图中数据.json`` and outputs
``3-7a.png`` + ``3-7a.pdf`` and
``3-7b.png`` + ``3-7b.pdf`` in the current directory.

Style follows the provided reference figure:
- Qwen3-4B: light gray-blue + diagonal hatch
- Qwen3-8B: light pink + dotted hatch
- Llama2-8B: light green + cross hatch
- Llama3-8B: light cream/yellow + diagonal hatch
- Horizontal value labels
- No title above the figure

Usage:
    conda activate day0812
    python plot_3_7ab.py
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


# ---------------------------------------------------------------------------
# Data path
# ---------------------------------------------------------------------------
DATA_JSON = Path(__file__).resolve().parent / "fig7ab.json"


# ---------------------------------------------------------------------------
# Model styles
#
# Matched to the reference image:
# Qwen3-4B  -> light gray-blue + ///
# Qwen3-8B  -> light pink + ...
# Llama2-8B -> light green + xxx
# Llama3-8B -> light cream/yellow + \\\
# ---------------------------------------------------------------------------
MODEL_STYLES = {
    "Qwen3-4B": (
        "#D9E1E8",   # light gray-blue
        "///"
    ),
    "Qwen3-8B": (
        "#E8C8C8",   # light pink
        "..."
    ),
    "Llama2-7B": (
        "#C8D9CC",   # light green
        "xxx"
    ),
    "Llama3-8B": (
        "#E9E5C7",   # light cream/yellow
        "\\\\"
    ),
}

BAR_EDGE_COLOR = "#444444"


# ---------------------------------------------------------------------------
# Global plotting configuration
# ---------------------------------------------------------------------------
def configure_plot() -> None:
    """Global matplotlib style matching the paper/reference figure."""

    plt.rcParams.update({
        "font.family": "Times New Roman",
        "font.size": 20,

        "axes.labelsize": 24,
        "axes.linewidth": 1.2,

        "axes.spines.top": True,
        "axes.spines.right": True,

        "axes.grid": True,
        "axes.axisbelow": True,

        "xtick.labelsize": 20,
        "ytick.labelsize": 20,

        "xtick.major.width": 1.2,
        "ytick.major.width": 1.2,

        "xtick.major.size": 7,
        "ytick.major.size": 7,

        "xtick.direction": "out",
        "ytick.direction": "out",

        "grid.linewidth": 0.9,
        "grid.linestyle": "--",
        "grid.alpha": 0.4,

        "legend.fontsize": 16,

        "figure.dpi": 150,
        "savefig.dpi": 600,
    })


# ---------------------------------------------------------------------------
# Load JSON data
# ---------------------------------------------------------------------------
def load_data(json_path: Path) -> dict:
    """Read the extracted figure data JSON."""

    with json_path.open(encoding="utf-8") as handle:
        return json.load(handle)


# ---------------------------------------------------------------------------
# Extract model short name
# ---------------------------------------------------------------------------
def model_short_name(full_method: str) -> str:
    """
    Example:
        'Original vanilla Qwen3-4B' -> 'Qwen3-4B'
    """

    return full_method.split()[-1]


# ---------------------------------------------------------------------------
# Plot one figure
# ---------------------------------------------------------------------------
def plot_figure(
    fig_key: str,
    out_name: str,
    data: dict,
    output_dir: Path
) -> None:
    """Draw one grouped bar chart and save PNG + PDF."""

    configure_plot()

    metrics = data["横轴_x轴_指标"]
    cfg = data[fig_key]

    methods = cfg["图例_方法"]
    values = cfg["柱状图数据_方法x指标"]

    # -----------------------------------------------------------------------
    # Figure
    # -----------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(10, 7))

    # -----------------------------------------------------------------------
    # Grouped bars
    # -----------------------------------------------------------------------
    x = np.arange(len(metrics))

    n = len(methods)

    # Width of each individual bar
    width = 0.20

    # Center the four bars around each x position
    offsets = (np.arange(n) - (n - 1) / 2) * width

    for i, method in enumerate(methods):

        model_name = model_short_name(method)

        color, hatch = MODEL_STYLES[model_name]

        vals = values[method]

        bars = ax.bar(
            x + offsets[i],
            vals,
            width=width,

            label=method,

            # Reference-image-like muted fill
            color=color,

            # Dark gray outline
            edgecolor=BAR_EDGE_COLOR,
            linewidth=1.2,

            # Hatch pattern
            hatch=hatch,

            # Keep hatch visually clear
            alpha=0.95,
        )

        # -------------------------------------------------------------------
        # Value labels
        #
        # IMPORTANT:
        # The labels are now horizontal instead of vertical.
        # -------------------------------------------------------------------
        for k, val in enumerate(vals):

            ax.text(
                x[k] + offsets[i],

                # Put number slightly above the bar
                val + 1.5,

                f"{val:.2f}",

                ha="center",
                va="bottom",

                # Horizontal text
                rotation=0,

                fontsize=13,
                fontname="Times New Roman",

                # Prevent clipping/overlap
                clip_on=False,
            )

    # -----------------------------------------------------------------------
    # X-axis
    # -----------------------------------------------------------------------
    ax.set_xticks(x)
    ax.set_xticklabels(metrics)

    ax.set_xlim(
        -0.5,
        len(metrics) - 0.5
    )

    # -----------------------------------------------------------------------
    # Y-axis
    # -----------------------------------------------------------------------
    ax.set_ylabel(
        "Score (%)",
        fontsize=26,
        fontweight="normal"
    )

    ax.set_ylim(0, 100)

    ax.set_yticks(
        (0, 20, 40, 60, 80, 100)
    )

    # -----------------------------------------------------------------------
    # IMPORTANT:
    # No title.
    #
    # The previous code had:
    #     ax.set_title(...)
    #
    # It has been completely removed.
    # -----------------------------------------------------------------------

    # -----------------------------------------------------------------------
    # Grid
    # -----------------------------------------------------------------------
    ax.grid(
        True,
        axis="both"
    )

    # -----------------------------------------------------------------------
    # Legend
    #
    # Two rows, matching the reference figure.
    # -----------------------------------------------------------------------
    ax.legend(
        fontsize=16,
        ncol=2,
        loc="upper left",
        frameon=True,

        # Slightly move legend downward from the top border
        bbox_to_anchor=(0.0, 0.99),

        # Keep the legend compact
        columnspacing=1.0,
        handletextpad=0.5,
    )

    # -----------------------------------------------------------------------
    # Layout
    # -----------------------------------------------------------------------
    fig.tight_layout()

    # -----------------------------------------------------------------------
    # Save
    # -----------------------------------------------------------------------
    png_path = output_dir / f"{out_name}.png"
    pdf_path = output_dir / f"{out_name}.pdf"

    fig.savefig(
        png_path,
        bbox_inches="tight",
        facecolor="white"
    )

    fig.savefig(
        pdf_path,
        format="pdf",
        bbox_inches="tight",
        facecolor="white"
    )

    plt.close(fig)

    print(f"Figure {out_name} saved:")
    print(f"  {png_path.resolve()}")
    print(f"  {pdf_path.resolve()}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:

    if not DATA_JSON.exists():
        raise SystemExit(
            f"Data file not found: {DATA_JSON.resolve()}"
        )

    data = load_data(DATA_JSON)

    output_dir = Path.cwd()

    # Figure 3-7a
    plot_figure(
        "Fig3-7(a)",
        "3-7a",
        data,
        output_dir
    )

    # Figure 3-7b
    plot_figure(
        "Fig3-7(b)",
        "3-7b",
        data,
        output_dir
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    main()