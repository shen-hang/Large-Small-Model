"""
Standalone script: reproduce Figure 11 — average group reward per round
across three mechanisms (Baseline-4, Baseline-5, Proposed-5).

Style follows the reference figure 3-7a.pdf:
- Baseline-4 : light gray-blue  + diagonal hatch (///)
- Baseline-5 : light pink       + dotted hatch   (...)
- Proposed-5 : light green       + cross hatch    (xxx)
- Aspect ratio 10:7

Outputs ``fig11.png`` + ``fig11.pdf`` in the current directory.

Usage:
    python fig11.py
"""

import io

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Global plotting configuration (matching 3-7a.pdf)
# ---------------------------------------------------------------------------
plt.rcParams.update({
    "font.family": "Times New Roman",
    "font.size": 20,

    "axes.labelsize": 24,
    "axes.linewidth": 1.2,

    "axes.spines.top": True,
    "axes.spines.right": True,

    "axes.grid": True,
    "axes.axisbelow": True,

    "xtick.labelsize": 20,
    "ytick.labelsize": 20,

    "xtick.major.width": 1.2,
    "ytick.major.width": 1.2,

    "xtick.major.size": 7,
    "ytick.major.size": 7,

    "xtick.direction": "out",
    "ytick.direction": "out",

    "grid.linewidth": 0.9,
    "grid.linestyle": "--",
    "grid.alpha": 0.4,

    "legend.fontsize": 16,

    "figure.dpi": 150,
    "savefig.dpi": 600,

    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------
csv_data = """mechanism,High-value,Novelty-oriented,Effectiveness-oriented,Medium-value,Low-value,Unreliable,total 
Baseline-5 ,4.355769,4.364863,2.053699,3.334894,1.533133,4.357643,20.000000 
Baseline-6,5.146478,3.362106,3.368797,3.166916,1.055811,3.899892,20.000000 
Proposed-5 ,6.518232,3.002080,3.014650,3.765082,0.519555,3.180401,20.000000"""

df = pd.read_csv(io.StringIO(csv_data))

df.columns = [c.strip() for c in df.columns]
df["mechanism"] = df["mechanism"].str.strip()

categories = [
    "High-value",
    "Novelty-oriented",
    "Effectiveness-oriented",
    "Medium-value",
    "Low-value",
    "Unreliable",
]

data_values = df[categories].values.T

mechanisms = [
    "Baseline-5",
    "Baseline-6",
    "Proposed-5",
]


# ---------------------------------------------------------------------------
# Bar styles (matching 3-7a.pdf)
# ---------------------------------------------------------------------------
colors = [
    "#D9E1E8",   # light gray-blue
    "#E8C8C8",   # light pink
    "#C8D9CC",   # light green
]

hatches = [
    "///",        # diagonal
    "...",        # dotted
    "xxx",        # cross
]

edgecolor = "#444444"


estimated_errors = np.array([
    [0.05, 0.15, 0.20],
    [0.05, 0.10, 0.10],
    [0.05, 0.10, 0.10],
    [0.05, 0.10, 0.15],
    [0.05, 0.05, 0.05],
    [0.05, 0.30, 0.35],
]).T


# ---------------------------------------------------------------------------
# Figure
#
# Page size is pinned to 3-9d.pdf's exact page dimensions
# (690.876 x 474.685 pt, i.e. figsize=(10, 7) cropped by
# ``bbox_inches="tight"``).
#
# The plot area is laid out by ``tight_layout()`` so the bars stay wide —
# consistent with the paper's other bar charts (3-7a, 3-9b).
#
# We save WITHOUT ``bbox_inches="tight"`` so the page size is exact.
# ---------------------------------------------------------------------------
TARGET_SIZE_INCHES = (
    690.87625 / 72.0,
    474.6850106476 / 72.0
)

fig, ax = plt.subplots(figsize=TARGET_SIZE_INCHES)


# ---------------------------------------------------------------------------
# Bars
# ---------------------------------------------------------------------------
bar_width = 0.25
index = np.arange(len(categories))

for i, mechanism in enumerate(mechanisms):

    offset = (i - 1) * bar_width

    ax.bar(
        index + offset,
        data_values[:, i],
        bar_width,
        yerr=estimated_errors[i],
        label=mechanism,
        color=colors[i],
        hatch=hatches[i],
        edgecolor=edgecolor,
        linewidth=1.2,
        capsize=4,
        error_kw={
            "elinewidth": 1.2,
            "ecolor": "black",
            "capthick": 1.2
        }
    )


# ---------------------------------------------------------------------------
# Axes
# ---------------------------------------------------------------------------
ax.set_xticks(index)

ax.set_xticklabels(
    [
        "High-value",
        "Novelty",
        "Effectiveness",
        "Medium-value",
        "Low-value",
        "Unreliable"
    ],
    fontsize=16
)

ax.set_ylabel(
    "Average group reward per round",
    fontsize=22
)

ax.set_ylim(0, 7.0)

ax.set_yticks(
    np.arange(0, 7, 1)
)

ax.yaxis.grid(True)
ax.xaxis.grid(False)


# ---------------------------------------------------------------------------
# Legend
# ---------------------------------------------------------------------------
ax.legend(
    loc="upper right",
    fontsize=16,
    frameon=True,
    edgecolor="#cccccc",
    fancybox=True,
    borderpad=0.8
)


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------
fig.tight_layout()


# ---------------------------------------------------------------------------
# Move the entire plot area upward
#
# Change this value to control the amount of upward movement:
#
#   0.02 -> move up slightly
#   0.04 -> current setting
#   0.05 -> move up more
#   0.06 -> move up significantly
# ---------------------------------------------------------------------------
MOVE_UP = 0.03

pos = ax.get_position()

ax.set_position([
    pos.x0,              # keep horizontal position unchanged
    pos.y0 + MOVE_UP,    # move upward
    pos.width,           # keep width unchanged
    pos.height           # keep height unchanged
])


# ---------------------------------------------------------------------------
# Save
# ---------------------------------------------------------------------------
fig.savefig(
    "fig11.png",
    facecolor="white"
)

fig.savefig(
    "fig11.pdf",
    format="pdf",
    facecolor="white"
)


# ---------------------------------------------------------------------------
# Show
# ---------------------------------------------------------------------------
plt.show()