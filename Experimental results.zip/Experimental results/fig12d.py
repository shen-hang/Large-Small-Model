"""Standalone script: reproduce Figure 3-11d — Experimental rounds vs Delay (ms).
Data extracted from task4.xlsx.
"""

import matplotlib.pyplot as plt

# ===========================================================================
# Data from task4.xlsx
# ===========================================================================
rounds = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

vehicle   = [177.00, 207.17, 184.23, 182.40, 194.51, 169.39, 189.97, 179.31, 168.07, 187.82]
drone     = [185.42, 254.68, 200.91, 191.22, 204.38, 176.85, 204.44, 182.53, 179.14, 194.26]
satellite = [192.35, 211.56, 182.74, 205.13, 198.46, 182.97, 207.21, 177.42, 190.87, 200.52]

# ===========================================================================
# Global style
# ===========================================================================
plt.rcParams.update({
    "font.family": "Times New Roman",
    "font.size": 20,
    "axes.labelsize": 24,
    "axes.linewidth": 1.2,
    "axes.spines.top": True,
    "axes.spines.right": True,
    "axes.grid": True,
    "axes.axisbelow": True,
    "xtick.labelsize": 20,
    "ytick.labelsize": 20,
    "xtick.major.width": 1.2,
    "ytick.major.width": 1.2,
    "xtick.major.size": 7,
    "ytick.major.size": 7,
    "xtick.direction": "out",
    "ytick.direction": "out",
    "grid.linewidth": 0.9,
    "grid.linestyle": "--",
    "grid.alpha": 0.4,
    "legend.fontsize": 30,
    "figure.dpi": 150,
    "savefig.dpi": 600,
})

# ===========================================================================
# Plot
# ===========================================================================
colors = {
    'vehicle':   '#2ca02c',
    'drone':     '#ff7f0e',
    'satellite': '#1f77b4',
}
markers = {
    'vehicle':   's',
    'drone':     'o',
    'satellite': '^',
}
linestyles = {
    'vehicle':   '-',
    'drone':     ':',
    'satellite': '--',
}

fig, ax = plt.subplots(figsize=(10, 7))

ax.plot(rounds, vehicle,   label='vehicle',   color=colors['vehicle'],   marker=markers['vehicle'],   linestyle=linestyles['vehicle'],   markerfacecolor='none', markersize=7, linewidth=2.0)
ax.plot(rounds, drone,     label='drone',     color=colors['drone'],     marker=markers['drone'],     linestyle=linestyles['drone'],     markerfacecolor='none', markersize=7, linewidth=2.0)
ax.plot(rounds, satellite, label='satellite', color=colors['satellite'], marker=markers['satellite'], linestyle=linestyles['satellite'], markerfacecolor='none', markersize=7, linewidth=2.0)

# --- Axes ---
ax.set_xlabel("Task rounds", fontsize=30)
ax.set_ylabel("Delay (ms)", fontsize=30)
ax.set_xlim(1, 10)
ax.set_ylim(160, 280)

# --- Legend & grid ---
ax.legend(fontsize=30, frameon=True)
ax.grid(True, linestyle='--', alpha=0.4)

# --- Save ---
fig.tight_layout()
fig.savefig("Fig3-11d.pdf", format='pdf', dpi=600, bbox_inches='tight', facecolor="white")
fig.savefig("Fig3-11d.png", dpi=600, bbox_inches='tight', facecolor="white")
print("Saved: Fig3-11d.pdf, Fig3-11d.png")
plt.close(fig)
