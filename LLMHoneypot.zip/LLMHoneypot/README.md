
# LLMHoneypot Experimental Repository

The reproducible honeypot benchmark and reporting pipeline are located in
[`honeypot_exp`](honeypot_exp). See `honeypot_exp/README.md` for environment
setup, method definitions, API-free validation, real-run commands, checkpoint
re-scoring, and reproducibility notes.

Publication figures at the repository root are derived artifacts. Raw and
intermediate API credentials must never be committed. Generated honeypot
credentials are synthetic and should be redacted from public raw-response
files to avoid triggering secret scanners.

