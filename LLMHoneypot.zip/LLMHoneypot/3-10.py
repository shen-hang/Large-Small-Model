from __future__ import annotations

import csv
import os

import matplotlib.pyplot as plt
import numpy as np

from incentive_common import (
    Config,
    GROUPS,
    generate_trace,
    group_means,
    mean_ci,
    run_mechanism,
)


COLORS = ['#2ca02c', '#9467bd', '#1f77b4', '#ff7f0e', '#7f7f7f', '#8c564b']
MARKERS = ['D', 'o', '^', 's', 'v', 'P']
LINESTYLES = ['-', ':', '-.', '--', '-', '--']


def configure_plot() -> None:
    plt.rcParams.update({
        'font.family': 'serif',
        'font.serif': ['Times New Roman', 'DejaVu Serif'],
        'axes.linewidth': 1.4,
        'xtick.major.width': 1.2,
        'ytick.major.width': 1.2,
        'grid.linewidth': 0.8,
    })


def plot_trajectory(
    x: np.ndarray,
    values: np.ndarray,
    ylabel: str,
    output_path: str,
    ylim: tuple[float, float] | None = None,
) -> None:
    mean, _ = mean_ci(values)
    fig, ax = plt.subplots(figsize=(8, 5))
    for group_id, label in enumerate(GROUPS):
        ax.plot(
            x,
            mean[:, group_id],
            label=label,
            color=COLORS[group_id],
            linestyle=LINESTYLES[group_id],
            marker=MARKERS[group_id],
            markerfacecolor='none',
            linewidth=2.0,
            markersize=6,
            markevery=10,
        )
    ax.set_xlabel('Round', fontsize=18)
    ax.set_ylabel(ylabel, fontsize=18)
    ax.tick_params(labelsize=16)
    ax.set_xlim(x[0], x[-1])
    if ylim is not None:
        ax.set_ylim(*ylim)
    else:
        ax.set_ylim(bottom=0)
    ax.grid(True, linestyle='--', alpha=0.4)
    ax.legend(
        fontsize=11,
        frameon=True,
        ncol=2,
        loc='best',
    )
    fig.tight_layout()
    fig.savefig(output_path, format='pdf', dpi=600, bbox_inches='tight')
    plt.close(fig)


def main() -> None:
    cfg = Config()
    output_dir = os.path.join('output', 'incentive_redesign')
    pdf_dir = os.path.join(output_dir, 'pdf')
    os.makedirs(pdf_dir, exist_ok=True)
    configure_plot()

    reputation_runs = []
    reward_runs = []
    threshold_runs = []
    rejection_runs = []
    master_rng = np.random.default_rng(cfg.seed)

    for _ in range(cfg.repetitions):
        seed = int(master_rng.integers(0, 2**32 - 1))
        trace = generate_trace(cfg, seed)
        result = run_mechanism(trace, cfg, 'Proposed Incentive')
        group_index = trace['group_index']
        reputation_runs.append(group_means(result['reputation'], group_index))
        # Sum rewards within each behavior type. With one representative node
        # per type, the six rewards add up to the per-round budget of 20.
        group_reward = group_means(result['reward'], group_index)
        group_reward *= cfg.nodes_per_group
        reward_runs.append(group_reward)
        rejected = (result['score'] < cfg.score_threshold).astype(float)
        threshold_runs.append(group_means(rejected, group_index))
        # Number of threshold-triggering submissions per representative node
        # during one 100-round repetition.
        rejection_runs.append(group_means(rejected, group_index).sum(axis=0))

    reputation_runs = np.asarray(reputation_runs)
    reward_runs = np.asarray(reward_runs)
    cumulative_runs = np.cumsum(reward_runs, axis=1)
    threshold_runs = np.asarray(threshold_runs)
    rejection_runs = np.asarray(rejection_runs)

    plot_trajectory(
        np.arange(cfg.rounds + 1),
        reputation_runs,
        'Reputation',
        os.path.join(pdf_dir, 'node_behavior_reputation.pdf'),
        ylim=(0.4, 1),
    )
    plot_trajectory(
        np.arange(cfg.rounds),
        reward_runs,
        'Group reward per round',
        os.path.join(pdf_dir, 'node_behavior_group_reward_per_round.pdf'),
    )
    plot_trajectory(
        np.arange(cfg.rounds),
        cumulative_runs,
        'Cumulative group reward',
        os.path.join(pdf_dir, 'node_behavior_cumulative_group_reward.pdf'),
    )

    # Long-format per-round data used to reproduce all three trajectories.
    # Reputation includes its initial value at round 0; rewards start at 1.
    reputation_mean, reputation_ci = mean_ci(reputation_runs)
    reward_mean, reward_ci = mean_ci(reward_runs)
    cumulative_mean, cumulative_ci = mean_ci(cumulative_runs)
    threshold_mean, threshold_ci = mean_ci(threshold_runs)
    with open(
        os.path.join(output_dir, 'node_behavior_per_round.csv'),
        'w', newline='', encoding='utf-8-sig'
    ) as stream:
        writer = csv.writer(stream)
        writer.writerow([
            'round', 'node_type', 'reputation_mean', 'reputation_ci95',
            'reward_per_round_mean', 'reward_per_round_ci95',
            'cumulative_reward_mean', 'cumulative_reward_ci95',
            'threshold_trigger_rate_mean', 'threshold_trigger_rate_ci95',
        ])
        for round_id in range(cfg.rounds + 1):
            for group_id, label in enumerate(GROUPS):
                reward_values = ['', '', '', '', '', '']
                if round_id > 0:
                    reward_index = round_id - 1
                    reward_values = [
                        f'{reward_mean[reward_index, group_id]:.6f}',
                        f'{reward_ci[reward_index, group_id]:.6f}',
                        f'{cumulative_mean[reward_index, group_id]:.6f}',
                        f'{cumulative_ci[reward_index, group_id]:.6f}',
                        f'{threshold_mean[reward_index, group_id]:.6f}',
                        f'{threshold_ci[reward_index, group_id]:.6f}',
                    ]
                writer.writerow([
                    round_id,
                    label,
                    f'{reputation_mean[round_id, group_id]:.6f}',
                    f'{reputation_ci[round_id, group_id]:.6f}',
                    *reward_values,
                ])

    with open(
        os.path.join(output_dir, 'node_behavior_summary.csv'),
        'w', newline='', encoding='utf-8-sig'
    ) as stream:
        writer = csv.writer(stream)
        writer.writerow([
            'node_type', 'final_reputation_mean', 'final_reputation_ci95',
            'mean_group_reward_per_round', 'cumulative_group_reward',
            'threshold_trigger_count_mean', 'threshold_trigger_count_ci95',
            'threshold_trigger_rate'
        ])
        final_rep_mean, final_rep_ci = mean_ci(reputation_runs[:, -1, :])
        mean_reward = reward_runs.mean(axis=(0, 1))
        cumulative_reward = cumulative_runs[:, -1, :].mean(axis=0)
        trigger_count_mean, trigger_count_ci = mean_ci(rejection_runs)
        rejection_rate = trigger_count_mean / cfg.rounds
        for group_id, label in enumerate(GROUPS):
            writer.writerow([
                label,
                f'{final_rep_mean[group_id]:.6f}',
                f'{final_rep_ci[group_id]:.6f}',
                f'{mean_reward[group_id]:.6f}',
                f'{cumulative_reward[group_id]:.6f}',
                f'{trigger_count_mean[group_id]:.6f}',
                f'{trigger_count_ci[group_id]:.6f}',
                f'{rejection_rate[group_id]:.6f}',
            ])

    overall_trigger_runs = rejection_runs.sum(axis=1)
    overall_trigger_mean, overall_trigger_ci = mean_ci(overall_trigger_runs)
    submissions_per_run = cfg.rounds * len(GROUPS) * cfg.nodes_per_group
    overall_trigger_rate = overall_trigger_mean / submissions_per_run
    with open(
        os.path.join(output_dir, 'threshold_trigger_summary.csv'),
        'w', newline='', encoding='utf-8-sig'
    ) as stream:
        writer = csv.writer(stream)
        writer.writerow([
            'node_type', 'submissions_per_repetition',
            'trigger_count_mean', 'trigger_count_ci95', 'trigger_rate'
        ])
        for group_id, label in enumerate(GROUPS):
            writer.writerow([
                label,
                cfg.rounds * cfg.nodes_per_group,
                f'{trigger_count_mean[group_id]:.6f}',
                f'{trigger_count_ci[group_id]:.6f}',
                f'{rejection_rate[group_id]:.6f}',
            ])
        writer.writerow([
            'Overall',
            submissions_per_run,
            f'{overall_trigger_mean:.6f}',
            f'{overall_trigger_ci:.6f}',
            f'{overall_trigger_rate:.6f}',
        ])

    print('Node behavior experiment completed.')
    for group_id, label in enumerate(GROUPS):
        print(
            f'{label}: final reputation={final_rep_mean[group_id]:.4f} '
            f'+/- {final_rep_ci[group_id]:.4f}, '
            f'mean group reward={mean_reward[group_id]:.4f}, '
            f'cumulative group reward={cumulative_reward[group_id]:.4f}, '
            f'threshold triggers={trigger_count_mean[group_id]:.2f} '
            f'+/- {trigger_count_ci[group_id]:.2f} of {cfg.rounds} '
            f'({rejection_rate[group_id]:.2%})'
        )
    print(
        f'Overall: threshold triggers={overall_trigger_mean:.2f} '
        f'+/- {overall_trigger_ci:.2f} of {submissions_per_run} '
        f'({overall_trigger_rate:.2%}) per repetition'
    )


if __name__ == '__main__':
    main()
