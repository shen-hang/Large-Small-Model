"""Build and freeze the 120-atom cross-tier deception knowledge base."""

from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
ATOM_PATH = ROOT / "strategy_atoms.json"
MANIFEST_PATH = ROOT / "strategy_atoms_manifest.json"
VERSION = "sagvn-strategy-atoms-v4.0.0"


BEHAVIORS = {
    # Counts reproduce Table III in the paper.  The MITRE reference identifies
    # the public behavior used for manual deception-oriented abstraction.
    "brute_force": (12, "T1110", "Brute Force", "brute-force authentication", "SSH", "ops/winter2026", "/var/log/auth.log", "10.20.1.21:22", ["brute", "password", "login", "ssh"]),
    "data_theft": (14, "T1041", "Exfiltration Over C2 Channel", "data theft", "database export", "telemetry/vehicle123", "/opt/app/config.json", "10.40.3.10:5432", ["exfiltration", "database", "secret", "export"]),
    "vulnerability_exploitation": (14, "T1190", "Exploit Public-Facing Application", "vulnerability exploitation", "HTTP debug API", "debug/admin2026", "/opt/web/version.txt", "10.30.2.32:8080", ["exploit", "vulnerability", "debug", "http"]),
    "authorization_bypass": (10, "T1556", "Modify Authentication Process", "authorization bypass", "NETCONF management", "maint/diagpass", "/etc/netconf/acl.conf", "10.40.3.21:830", ["authorization", "bypass", "management", "netconf"]),
    "privilege_escalation": (14, "T1068", "Exploitation for Privilege Escalation", "privilege escalation", "sudo and Docker", "deploy/vehicle123", "/etc/sudoers.d/deploy", "10.30.2.32:22", ["sudo", "root", "privilege", "docker"]),
    "man_in_the_middle": (12, "T1557", "Adversary-in-the-Middle", "man-in-the-middle interception", "TLS relay", "relay/capture2026", "/etc/ssl/private/relay.key", "10.30.2.21:443", ["mitm", "relay", "certificate", "tls"]),
    "valid_account_abuse": (12, "T1078", "Valid Accounts", "valid-account abuse", "SSH and database", "deploy/vehicle123", "/home/deploy/.ssh/id_rsa", "10.40.3.32:22", ["valid", "account", "credential", "ssh"]),
    "tunneling": (10, "T1572", "Protocol Tunneling", "network tunneling", "SSH port forwarding", "tunnel/tunnelpass", "/home/deploy/.ssh/config", "10.40.3.10:5432", ["tunnel", "forward", "proxy", "ssh"]),
    "backdoor": (12, "T1505.003", "Web Shell", "backdoor persistence", "systemd update service", "svc-update/update2026", "/etc/systemd/system/telemetry-update.service", "10.30.2.10:443", ["backdoor", "persistence", "systemd", "beacon"]),
    "log_deletion": (10, "T1070.002", "Clear Linux or Mac System Logs", "log deletion", "audit and journald", "audit/cleanup2026", "/var/log/auth.log", "10.20.1.10:22", ["log", "delete", "audit", "cleanup"]),
}


ROLE_SPECS = (
    ("host", ["ground"], ["reconnaissance"], "Present a ground-tier decoy host whose identity and banner plausibly reflect {label}."),
    ("service", ["ground", "air"], ["reconnaissance"], "Expose the decoy service {service} with stable ports, versions and banners for {label}."),
    ("credential", ["ground", "air"], ["sensitive_information_theft"], "Plant synthetic credential {credential} as a reusable lure associated with {label}."),
    ("file", ["ground"], ["sensitive_information_theft"], "Place synthetic artifact {file} with internally consistent metadata and clues for {label}."),
    ("pivot", ["ground", "space"], ["lateral_movement"], "Advertise controlled pivot target {pivot} for {label} and keep its host identity consistent across tiers."),
    ("service", ["air"], ["reconnaissance", "sensitive_information_theft"], "Instrument {service} with believable telemetry that reveals staged evidence of {label}."),
    ("credential", ["air", "space"], ["sensitive_information_theft", "lateral_movement"], "Reuse only the synthetic identity {credential} across selected decoys to support a traceable {label} path."),
    ("file", ["air"], ["privilege_escalation"], "Expose a canary configuration derived from {file} that suggests a controlled privilege boundary for {label}."),
    ("host", ["ground", "air", "space"], ["reconnaissance", "lateral_movement"], "Maintain identical naming, time and ownership facts for {label} artifacts across ground, air and space nodes."),
    ("service", ["space"], ["privilege_escalation", "lateral_movement"], "Return protocol-correct but synthetic service state that guides {label} activity toward {pivot}."),
    ("pivot", ["air", "space"], ["lateral_movement"], "Route the apparent next step for {label} through monitored decoy endpoint {pivot} without exposing real assets."),
    ("file", ["ground", "air", "space"], ["sensitive_information_theft", "privilege_escalation"], "Record canary access and preserve a consistent synthetic forensic trace for {label} around {file}."),
    ("credential", ["ground", "space"], ["privilege_escalation", "lateral_movement"], "Expose a scoped synthetic recovery identity {credential} that redirects {label} activity to monitored assets."),
    ("service", ["ground", "air", "space"], ["reconnaissance", "lateral_movement"], "Keep the synthetic {service} control-plane metadata consistent while steering {label} toward {pivot}."),
)


def build_atoms() -> list[dict[str, object]]:
    atoms: list[dict[str, object]] = []
    for attack_type, values in BEHAVIORS.items():
        count, technique_id, technique_name, label, service, credential, file_path, pivot, behavior_keywords = values
        for number, (category, tiers, stages, template) in enumerate(ROLE_SPECS[:count], start=1):
            content = template.format(
                label=label,
                service=service,
                credential=credential,
                file=file_path,
                pivot=pivot,
            )
            atoms.append(
                {
                    "atom_id": f"{attack_type}-{number:02d}",
                    "attack_type": attack_type,
                    "category": category,
                    "content": content,
                    "keywords": list(dict.fromkeys([
                        *behavior_keywords,
                        category,
                        service.casefold(),
                        credential.split("/", 1)[0],
                        file_path,
                        pivot,
                    ])),
                    "tiers": tiers,
                    "stages": stages,
                    "source": {
                        "framework": "MITRE ATT&CK Enterprise",
                        "technique_id": technique_id,
                        "technique_name": technique_name,
                        "url": f"https://attack.mitre.org/techniques/{technique_id.replace('.', '/')}/",
                    },
                    "construction_method": "manual deception abstraction and semantic role expansion",
                    "review_status": "human-review-required",
                    "review_version": "v1",
                }
            )
    return atoms


def main() -> int:
    atoms = build_atoms()
    if len(atoms) != 120:
        raise ValueError(f"expected 120 atoms, got {len(atoms)}")
    payload = (json.dumps(atoms, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    ATOM_PATH.write_bytes(payload)
    digest = hashlib.sha256(payload).hexdigest()
    manifest = {
        "knowledge_base_version": VERSION,
        "frozen_at": "2026-10-13",
        "atom_file": ATOM_PATH.name,
        "sha256": digest,
        "atom_count": len(atoms),
        "attack_type_counts": dict(sorted(Counter(str(a["attack_type"]) for a in atoms).items())),
        "category_counts": dict(sorted(Counter(str(a["category"]) for a in atoms).items())),
        "allowed_tiers": ["ground", "air", "space"],
        "allowed_stages": ["reconnaissance", "sensitive_information_theft", "privilege_escalation", "lateral_movement"],
        "construction_pipeline": [
            "MITRE ATT&CK behavior screening",
            "manual deception-oriented abstraction",
            "semantic role expansion",
        ],
        "review_note": "Every atom retains source provenance; review_status must be changed only after human verification.",
        "leakage_control": "No held-out reference responses or evaluator success labels are stored in any atom.",
        "intended_use": "Clean parent knowledge base for paired quality-sensitivity experiments.",
    }
    MANIFEST_PATH.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"atoms={len(atoms)} version={VERSION} sha256={digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
