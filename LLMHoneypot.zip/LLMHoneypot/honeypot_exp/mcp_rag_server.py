"""MCP Streamable HTTP server for strategy-atom retrieval benchmarks."""

from __future__ import annotations

import argparse
import asyncio
from pathlib import Path
import site
import sys
from typing import Any


# Some Conda installations do not automatically add the per-user site directory.
_USER_SITE = site.getusersitepackages()
if _USER_SITE and _USER_SITE not in sys.path:
    sys.path.append(_USER_SITE)

try:
    from mcp.server.fastmcp import FastMCP
except ImportError as exc:  # pragma: no cover - exercised by deployment setup
    raise SystemExit(
        "The official MCP SDK is required. Run: python -m pip install --user "
        "mcp==1.29.0"
    ) from exc


PROJECT_DIR = Path(__file__).resolve().parent
DEFAULT_ATOM_PATH = PROJECT_DIR / "strategy_atoms.json"
from strategy_retrieval import AtomIndex


def build_server(
    atom_path: Path,
    host: str = "127.0.0.1",
    port: int = 8000,
) -> FastMCP:
    index = AtomIndex(atom_path)
    server = FastMCP(
        "SAGVN Strategy Atom RAG",
        instructions=(
            "Retrieve host, service, credential, file and pivot strategy atoms "
            "for cross-tier honeypot orchestration."
        ),
        host=host,
        port=port,
        streamable_http_path="/mcp",
        stateless_http=True,
        json_response=True,
    )

    @server.tool()
    def search_strategy_atoms(
        threat_summary: str,
        attack_stage: str,
        source_tier: str,
        target_tiers: list[str],
        top_k: int = 5,
    ) -> dict[str, Any]:
        """Retrieve the top-k strategy atoms for one cross-tier threat."""

        if not threat_summary.strip():
            raise ValueError("threat_summary must not be empty")
        if source_tier not in {"ground", "air", "space"}:
            raise ValueError("source_tier must be ground, air or space")
        if not set(target_tiers).issubset({"ground", "air", "space"}):
            raise ValueError("target_tiers contains an unknown tier")
        if not 1 <= top_k <= 10:
            raise ValueError("top_k must be between 1 and 10")
        result = index.retrieve(
            threat_summary,
            attack_stage,
            source_tier,
            target_tiers,
            top_k,
        )
        return {
            "atoms": list(result.atoms),
            "retrieval_count": len(result.atoms),
            "retrieval_compute_ms": round(result.compute_ms, 6),
            "knowledge_base_atoms": result.knowledge_base_atoms,
            "knowledge_base_version": result.knowledge_base_version,
            "knowledge_base_sha256": result.knowledge_base_sha256,
            "retrieved_content_sha256": result.retrieved_content_sha256,
        }

    return server


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the strategy-atom MCP RAG server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--atom-file", type=Path, default=DEFAULT_ATOM_PATH)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    server = build_server(args.atom_file.resolve(), args.host, args.port)
    print(f"MCP RAG server: http://{args.host}:{args.port}/mcp")
    print(f"Strategy atoms: {args.atom_file.resolve()}")
    try:
        server.run(transport="streamable-http")
    except (KeyboardInterrupt, asyncio.CancelledError):
        print("MCP RAG server stopped.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
