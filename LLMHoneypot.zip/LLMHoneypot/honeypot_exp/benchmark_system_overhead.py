"""Benchmark MCP-RAG retrieval and edge GPT-5.1 orchestration overhead.

The probe is isolated from the main experiment: it reads deterministic tasks
and writes only to ``outputs/system_overhead_probe``.
"""

from __future__ import annotations

import argparse
import asyncio
import csv
from dataclasses import asdict, dataclass
from datetime import timedelta
import json
import os
from pathlib import Path
import site
from statistics import mean, pstdev
import sys
from time import perf_counter_ns
from typing import Any


_USER_SITE = site.getusersitepackages()
if _USER_SITE and _USER_SITE not in sys.path:
    sys.path.append(_USER_SITE)

try:
    import httpx
    from mcp import ClientSession
    from mcp.client.streamable_http import streamable_http_client
    from mcp.types import TextContent
except ImportError as exc:  # pragma: no cover - exercised by deployment setup
    raise SystemExit(
        "The official MCP SDK is required. Run: python -m pip install --user "
        "mcp==1.29.0"
    ) from exc

from config import EDGE_MODEL_NAME, MODEL_PROFILES, OUTPUT_DIR
from model import ChatResult, ModelClient, ModelError
from tasks import TASK_COUNT, AttackTask, generate_tasks


EDGE_BASE_URL = str(MODEL_PROFILES[EDGE_MODEL_NAME]["base_url"]).rstrip("/")
DEFAULT_OUTPUT_DIR = OUTPUT_DIR / "system_overhead_probe"
DEFAULT_MCP_URL = "http://127.0.0.1:8000/mcp"
EDGE_MAX_TOKENS = 300
EDGE_SYSTEM_PROMPT = """You are the edge orchestration LLM for a cross-tier
honeypot system. Analyze the supplied threat and retrieved strategy atoms.
Return a compact JSON object with keys threat_semantics, ground_tasks,
air_tasks, space_tasks, and consistency_constraints. Use only decoy data from
the retrieved atoms. Do not include reasoning or markdown."""

_EDGE_HTTP_CLIENT = httpx.Client(
    timeout=60.0,
    follow_redirects=True,
    # CrazyRouter's China endpoint works by direct TLS connection in this
    # environment; inherited HTTP(S)_PROXY settings terminate the handshake.
    trust_env=False,
)


def _crazyrouter_transport(
    url: str,
    headers: dict[str, str],
    payload: dict[str, Any],
    timeout: float,
) -> dict[str, Any]:
    """HTTPX transport used only by this benchmark's CrazyRouter calls."""

    try:
        response = _EDGE_HTTP_CLIENT.post(
            url,
            headers=headers,
            json=payload,
            timeout=timeout,
        )
        response.raise_for_status()
        result = response.json()
    except httpx.HTTPStatusError as exc:
        detail = exc.response.text[:500]
        raise ModelError(
            f"CrazyRouter returned HTTP {exc.response.status_code}: {detail}"
        ) from exc
    except httpx.RequestError as exc:
        raise ModelError(f"CrazyRouter request failed: {exc}") from exc
    except ValueError as exc:
        raise ModelError("CrazyRouter returned invalid JSON") from exc
    if not isinstance(result, dict):
        raise ModelError("CrazyRouter response must be a JSON object")
    return result


_EDGE_MODEL_CLIENT = ModelClient(transport=_crazyrouter_transport)


@dataclass(frozen=True)
class ProbeRecord:
    trial: int
    task_id: str
    top_k: int
    rag_latency_ms: float
    rag_compute_ms: float
    rag_request_bytes: int
    rag_response_bytes: int
    retrieved_atoms: int
    edge_llm_latency_ms: float | None
    edge_prompt_tokens: int | None
    edge_completion_tokens: int | None
    edge_total_tokens: int | None
    edge_request_bytes: int | None
    edge_response_bytes: int | None
    end_to_end_latency_ms: float | None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Benchmark MCP-RAG and GPT-5.1 edge orchestration overhead."
    )
    parser.add_argument("--task-id", default="T04")
    parser.add_argument("--repeats", type=int, default=10)
    parser.add_argument("--warmup", type=int, default=1)
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument("--mcp-url", default=DEFAULT_MCP_URL)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument(
        "--observed-response",
        default="First-round endpoint response captured by the honeypot.",
        help="sanitized response from the already completed first interaction",
    )
    parser.add_argument(
        "--rag-only",
        action="store_true",
        help="benchmark MCP retrieval without calling GPT-5.1",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="validate configuration without contacting MCP or GPT-5.1",
    )
    return parser


def _json_bytes(value: Any) -> int:
    return len(
        json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    )


def _percentile(values: list[float], percentile: float) -> float:
    ordered = sorted(values)
    if not ordered:
        raise ValueError("percentile requires at least one value")
    position = (len(ordered) - 1) * percentile
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    fraction = position - lower
    return ordered[lower] + (ordered[upper] - ordered[lower]) * fraction


def _metric_summary(values: list[float]) -> dict[str, float]:
    return {
        "mean": round(mean(values), 3),
        "std": round(pstdev(values), 3),
        "p95": round(_percentile(values, 0.95), 3),
        "min": round(min(values), 3),
        "max": round(max(values), 3),
    }


def _task_or_error(task_id: str) -> AttackTask:
    tasks = {task.task_id: task for task in generate_tasks(TASK_COUNT)}
    normalized = task_id.upper()
    if normalized not in tasks:
        raise ValueError(f"unknown task ID {task_id!r}; choose T01 through T30")
    return tasks[normalized]


def _threat_summary(task: AttackTask, observed_response: str) -> str:
    step = task.steps[0]
    return (
        f"Threat family={task.family}; attacker={task.attacker_profile}; "
        f"observed_stage={step.stage}; source_tier={step.tier}; "
        f"observed_command={step.command}; observed_response={observed_response}"
    )


def _rag_arguments(
    task: AttackTask, top_k: int, observed_response: str
) -> dict[str, Any]:
    return {
        "threat_summary": _threat_summary(task, observed_response),
        "attack_stage": task.steps[0].stage,
        "source_tier": task.steps[0].tier,
        "target_tiers": list(task.target_tiers),
        "top_k": top_k,
    }


def _parse_tool_result(result: Any) -> dict[str, Any]:
    if getattr(result, "isError", False):
        raise RuntimeError(f"MCP tool returned an error: {result.content}")
    structured = getattr(result, "structuredContent", None)
    if isinstance(structured, dict):
        return structured
    for block in result.content:
        if isinstance(block, TextContent):
            try:
                parsed = json.loads(block.text)
            except json.JSONDecodeError:
                continue
            if isinstance(parsed, dict):
                return parsed
    raise RuntimeError("MCP tool did not return structured JSON")


def _edge_messages(
    task: AttackTask, rag_result: dict[str, Any], observed_response: str
) -> list[dict[str, str]]:
    user_payload = {
        "task_id": task.task_id,
        "threat_summary": _threat_summary(task, observed_response),
        "permitted_target_tiers": list(task.target_tiers),
        "retrieved_strategy_atoms": rag_result["atoms"],
    }
    return [
        {"role": "system", "content": EDGE_SYSTEM_PROMPT},
        {
            "role": "user",
            "content": json.dumps(user_payload, ensure_ascii=False),
        },
    ]


async def _call_edge_llm(messages: list[dict[str, str]]) -> tuple[ChatResult, float]:
    started_ns = perf_counter_ns()
    result = await asyncio.to_thread(
        _EDGE_MODEL_CLIENT.chat,
        messages,
        EDGE_MODEL_NAME,
        max_tokens=EDGE_MAX_TOKENS,
    )
    return result, (perf_counter_ns() - started_ns) / 1_000_000


async def run_probe(args: argparse.Namespace) -> tuple[list[ProbeRecord], float]:
    task = _task_or_error(args.task_id)
    rag_arguments = _rag_arguments(task, args.top_k, args.observed_response)
    records: list[ProbeRecord] = []
    connection_started_ns = perf_counter_ns()
    async with streamable_http_client(args.mcp_url) as (
        read_stream,
        write_stream,
        _,
    ):
        async with ClientSession(read_stream, write_stream) as session:
            await session.initialize()
            tools = await session.list_tools()
            tool_names = {tool.name for tool in tools.tools}
            if "search_strategy_atoms" not in tool_names:
                raise RuntimeError(
                    "MCP server does not expose search_strategy_atoms; "
                    f"available tools: {sorted(tool_names)}"
                )
            connection_ms = (perf_counter_ns() - connection_started_ns) / 1_000_000
            total_iterations = args.warmup + args.repeats
            for iteration in range(total_iterations):
                rag_started_ns = perf_counter_ns()
                tool_result = await session.call_tool(
                    "search_strategy_atoms",
                    arguments=rag_arguments,
                    read_timeout_seconds=timedelta(seconds=30),
                )
                rag_latency_ms = (perf_counter_ns() - rag_started_ns) / 1_000_000
                rag_result = _parse_tool_result(tool_result)
                if int(rag_result["retrieval_count"]) != args.top_k:
                    raise RuntimeError("MCP server returned an unexpected atom count")

                edge_result: ChatResult | None = None
                edge_latency_ms: float | None = None
                messages: list[dict[str, str]] | None = None
                if not args.rag_only:
                    messages = _edge_messages(task, rag_result, args.observed_response)
                    edge_result, edge_latency_ms = await _call_edge_llm(messages)

                if iteration < args.warmup:
                    print(f"Warm-up {iteration + 1}/{args.warmup} complete")
                    continue
                trial = iteration - args.warmup + 1
                record = ProbeRecord(
                    trial=trial,
                    task_id=task.task_id,
                    top_k=args.top_k,
                    rag_latency_ms=round(rag_latency_ms, 3),
                    rag_compute_ms=float(rag_result["retrieval_compute_ms"]),
                    rag_request_bytes=_json_bytes(
                        {
                            "tool": "search_strategy_atoms",
                            "arguments": rag_arguments,
                        }
                    ),
                    rag_response_bytes=_json_bytes(rag_result),
                    retrieved_atoms=int(rag_result["retrieval_count"]),
                    edge_llm_latency_ms=(
                        round(edge_latency_ms, 3)
                        if edge_latency_ms is not None
                        else None
                    ),
                    edge_prompt_tokens=(
                        edge_result.prompt_tokens if edge_result else None
                    ),
                    edge_completion_tokens=(
                        edge_result.completion_tokens if edge_result else None
                    ),
                    edge_total_tokens=(
                        edge_result.total_tokens if edge_result else None
                    ),
                    edge_request_bytes=(
                        _json_bytes({"messages": messages}) if messages else None
                    ),
                    edge_response_bytes=(
                        len(edge_result.content.encode("utf-8"))
                        if edge_result
                        else None
                    ),
                    end_to_end_latency_ms=(
                        round(rag_latency_ms + edge_latency_ms, 3)
                        if edge_latency_ms is not None
                        else None
                    ),
                )
                records.append(record)
                edge_text = (
                    f", edge={record.edge_llm_latency_ms:.3f} ms"
                    if record.edge_llm_latency_ms is not None
                    else ""
                )
                print(
                    f"[{trial:02d}/{args.repeats:02d}] "
                    f"RAG={record.rag_latency_ms:.3f} ms "
                    f"(compute={record.rag_compute_ms:.3f} ms){edge_text}"
                )
    return records, connection_ms


def _build_summary(
    args: argparse.Namespace,
    records: list[ProbeRecord],
    connection_ms: float,
) -> dict[str, Any]:
    rag_latency = [record.rag_latency_ms for record in records]
    rag_compute = [record.rag_compute_ms for record in records]
    summary: dict[str, Any] = {
        "task_id": args.task_id.upper(),
        "repeats": args.repeats,
        "warmup": args.warmup,
        "top_k": args.top_k,
        "mcp_url": args.mcp_url,
        "mcp_tool": "search_strategy_atoms",
        "mcp_connection_initialize_ms": round(connection_ms, 3),
        "communication_scope": "serialized application payload; HTTP headers excluded",
        "rag_latency_ms": _metric_summary(rag_latency),
        "rag_compute_ms": _metric_summary(rag_compute),
        "rag_request_bytes_mean": round(
            mean(record.rag_request_bytes for record in records), 3
        ),
        "rag_response_bytes_mean": round(
            mean(record.rag_response_bytes for record in records), 3
        ),
    }
    edge_latency = [
        record.edge_llm_latency_ms
        for record in records
        if record.edge_llm_latency_ms is not None
    ]
    if edge_latency:
        end_to_end = [
            record.end_to_end_latency_ms
            for record in records
            if record.end_to_end_latency_ms is not None
        ]
        summary.update(
            {
                "edge_model": EDGE_MODEL_NAME,
                "edge_api_model": MODEL_PROFILES[EDGE_MODEL_NAME]["api_model"],
                "edge_llm_latency_ms": _metric_summary(edge_latency),
                "end_to_end_latency_ms": _metric_summary(end_to_end),
                "edge_prompt_tokens_mean": round(
                    mean(
                        record.edge_prompt_tokens
                        for record in records
                        if record.edge_prompt_tokens is not None
                    ),
                    3,
                ),
                "edge_completion_tokens_mean": round(
                    mean(
                        record.edge_completion_tokens
                        for record in records
                        if record.edge_completion_tokens is not None
                    ),
                    3,
                ),
                "edge_request_bytes_mean": round(
                    mean(
                        record.edge_request_bytes
                        for record in records
                        if record.edge_request_bytes is not None
                    ),
                    3,
                ),
                "edge_response_bytes_mean": round(
                    mean(
                        record.edge_response_bytes
                        for record in records
                        if record.edge_response_bytes is not None
                    ),
                    3,
                ),
            }
        )
    return summary


def _write_outputs(
    output_dir: Path,
    records: list[ProbeRecord],
    summary: dict[str, Any],
) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = output_dir / "request_latency.csv"
    json_path = output_dir / "overhead_summary.json"
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=tuple(asdict(records[0])))
        writer.writeheader()
        writer.writerows(asdict(record) for record in records)
    json_path.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return csv_path, json_path


def _validate_args(args: argparse.Namespace) -> AttackTask:
    if not 1 <= args.repeats <= 100:
        raise ValueError("--repeats must be between 1 and 100")
    if not 0 <= args.warmup <= 10:
        raise ValueError("--warmup must be between 0 and 10")
    if not 1 <= args.top_k <= 10:
        raise ValueError("--top-k must be between 1 and 10")
    task = _task_or_error(args.task_id)
    profile = MODEL_PROFILES[EDGE_MODEL_NAME]
    print("System-overhead benchmark configuration:")
    print(f"  task={task.task_id}, repeats={args.repeats}, warmup={args.warmup}")
    print(f"  MCP={args.mcp_url}, tool=search_strategy_atoms, top_k={args.top_k}")
    print(
        f"  edge_model={profile['api_model']}, "
        f"base_url={profile['base_url']}"
    )
    if not args.rag_only:
        key_env = str(profile["api_key_env"])
        print(f"  {key_env}={'set' if os.getenv(key_env) else 'missing'}")
        if not os.getenv(key_env):
            raise ValueError(f"{key_env} is required unless --rag-only is used")
    return task


def main() -> int:
    args = build_parser().parse_args()
    _validate_args(args)
    if args.dry_run:
        print("Dry run passed; no MCP or GPT-5.1 calls were made.")
        return 0
    try:
        records, connection_ms = asyncio.run(run_probe(args))
    except Exception as exc:
        pending = [exc]
        leaf_messages: list[str] = []
        while pending:
            current = pending.pop()
            children = getattr(current, "exceptions", None)
            if children:
                pending.extend(children)
            else:
                leaf_messages.append(str(current))
        detail = "; ".join(dict.fromkeys(leaf_messages))
        raise SystemExit(f"Benchmark failed: {detail}") from exc
    summary = _build_summary(args, records, connection_ms)
    csv_path, json_path = _write_outputs(
        args.output_dir.resolve(), records, summary
    )
    print("\nSummary")
    print(
        f"  MCP-RAG latency: {summary['rag_latency_ms']['mean']:.3f} ms "
        f"(P95={summary['rag_latency_ms']['p95']:.3f} ms)"
    )
    print(
        f"  Retrieval compute: {summary['rag_compute_ms']['mean']:.3f} ms"
    )
    if "edge_llm_latency_ms" in summary:
        print(
            f"  Edge GPT-5.1 latency: "
            f"{summary['edge_llm_latency_ms']['mean']:.3f} ms "
            f"(P95={summary['edge_llm_latency_ms']['p95']:.3f} ms)"
        )
        print(
            f"  End-to-end latency: "
            f"{summary['end_to_end_latency_ms']['mean']:.3f} ms"
        )
    print(f"  CSV:  {csv_path}")
    print(f"  JSON: {json_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
