"""Build stratified KB tiers (100% / 75% / 50%) for the quality-sensitivity experiment.

Deterministic: the same source file and fractions always yield the same subsets.
Stratified removal preserves both marginal distributions that the frozen manifest
tracks — ``category`` (5 buckets) and ``attack_type`` (10 buckets) — so a smaller
KB stays representative of the parent KB rather than dropping whole categories.

Offline only: this script never calls an LLM.  It writes the 75% and 50% subsets;
the 100% tier is the existing ``strategy_atoms.json``.
"""

from __future__ import annotations

from collections import defaultdict
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SOURCE_FILE = HERE / "strategy_atoms.json"
# label -> fraction of atoms to keep.  100% is the untouched parent KB.
TIERS = {"100": 1.0, "75": 0.75, "50": 0.50}


def largest_remainder(targets: dict[str, float], total: int) -> dict[str, int]:
    """Round float targets to int counts that sum exactly to ``total``."""
    floors = {key: int(value) for key, value in targets.items()}
    remainders = {key: value - floors[key] for key, value in targets.items()}
    assigned = sum(floors.values())
    for key in sorted(remainders, key=lambda key: -remainders[key]):
        if assigned >= total:
            break
        floors[key] += 1
        assigned += 1
    assert assigned == total
    return floors


def stratified_subset(atoms: list[dict], fraction: float) -> list[dict]:
    target_total = round(len(atoms) * fraction)

    # Stratify on the (category, attack_type) joint cells so that BOTH marginal
    # distributions tracked by the frozen manifest are preserved to rounding.
    cells: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for atom in atoms:
        cells[(atom["category"], atom["attack_type"])].append(atom)
    for cell in cells:
        cells[cell].sort(key=lambda atom: atom["atom_id"])
    cell_keep = largest_remainder(
        {cell: len(group) * fraction for cell, group in cells.items()},
        target_total,
    )

    kept: list[dict] = []
    for cell in sorted(cells):
        kept.extend(cells[cell][: cell_keep[cell]])
    kept.sort(key=lambda atom: atom["atom_id"])
    assert len(kept) == target_total, (len(kept), target_total)
    return kept


def _distributions(atoms: list[dict]) -> tuple[dict[str, int], dict[str, int]]:
    categories: dict[str, int] = defaultdict(int)
    attack_types: dict[str, int] = defaultdict(int)
    for atom in atoms:
        categories[atom["category"]] += 1
        attack_types[atom["attack_type"]] += 1
    return dict(categories), dict(attack_types)


def main() -> None:
    atoms = json.loads(SOURCE_FILE.read_text(encoding="utf-8"))
    print(f"source: {len(atoms)} atoms in {SOURCE_FILE.name}")

    for label, fraction in TIERS.items():
        if fraction == 1.0:
            subset = atoms
            output_path = SOURCE_FILE
        else:
            subset = stratified_subset(atoms, fraction)
            output_path = HERE / f"strategy_atoms_{label}.json"
            output_path.write_text(
                json.dumps(subset, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        categories, attack_types = _distributions(subset)
        print(f"\n{label}% -> {output_path.name} ({len(subset)} atoms)")
        print(f"  category:    {categories}")
        print(f"  attack_type: {attack_types}")


if __name__ == "__main__":
    main()
