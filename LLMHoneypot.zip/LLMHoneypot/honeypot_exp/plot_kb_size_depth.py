"""Bar chart comparing average attack depth across KB size (5 tiers).

Plots the five experiment outputs requested side by side, ordered by
knowledge-base size (atoms), with 95% CI error bars.  Frame / font / tick
style matches the paper's Figure 3-8 (Times New Roman, all four spines,
outward ticks, dashed y grid).
"""

from __future__ import annotations

import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
OUTPUT_DIR = HERE / "outputs"
OUTPUT_STEM = "kb_size_depth_comparison"

EDGE_COLOR = "#444444"

# (output dir, x-label) ordered by atom count descending.
TIERS = [
    ("kb_sensitivity_100", "120"),
    ("kb_sensitivity_75",  "90"),
    ("kb_coverage_60",     "60"),
    ("kb_coverage_30",     "30"),
    ("kb_coverage_5",      "5"),
]

TIER_STYLES = {
    "120": {"color": "#D2B86A", "hatch": "\\\\"},
    "90":  {"color": "#C58F7A", "hatch": "xxx"},
    "60":  {"color": "#8F79B7", "hatch": "oo"},
    "30":  {"color": "#6FAF9E", "hatch": "///"},
    "5":   {"color": "#A6A6A6", "hatch": "..."},
}


def configure_plot() -> None:
    """Global matplotlib style matching the paper's Figure 3-8."""

    plt.rcParams.update({
        "font.family": "Times New Roman",
        "font.size": 20,
        "axes.labelsize": 24,
        "axes.linewidth": 1.4,
        "axes.spines.top": True,
        "axes.spines.right": True,
        "axes.grid": True,
        "axes.axisbelow": True,
        "xtick.labelsize": 20,
        "ytick.labelsize": 20,
        "xtick.major.width": 1.2,
        "ytick.major.width": 1.2,
        "xtick.major.size": 7,
        "ytick.major.size": 7,
        "xtick.direction": "out",
        "ytick.direction": "out",
        "grid.linewidth": 0.9,
        "grid.linestyle": "--",
        "grid.alpha": 0.3,
        "figure.dpi": 150,
        "savefig.dpi": 600,
    })


def format_axes(ax) -> None:
    """Common spine / tick / grid formatting matching Figure 3-8."""

    for spine in ax.spines.values():
        spine.set_color(EDGE_COLOR)
        spine.set_linewidth(2.0)

    ax.tick_params(axis="both", which="both", direction="out", width=1.2, length=7, labelsize=22)

    for tick_label in (*ax.get_xticklabels(), *ax.get_yticklabels()):
        tick_label.set_fontname("Times New Roman")

    ax.grid(True, axis="y", linestyle="--", alpha=0.3)
    ax.grid(False, axis="x")


def _load(tier: str) -> tuple[float, float, int]:
    path = OUTPUT_DIR / tier / "summary.csv"
    with path.open(encoding="utf-8-sig", newline="") as handle:
        row = next(csv.DictReader(handle))
    depth = float(row["average_attack_depth"])
    std = float(row["attack_depth_std"])
    sessions = int(row["sessions"])
    return depth, std, sessions


def main() -> None:
    configure_plot()

    rows: list[tuple[str, float, float, str, str]] = []
    for tier, label in TIERS:
        depth, std, sessions = _load(tier)
        ci = 1.96 * std / (sessions ** 0.5)
        style = TIER_STYLES[label]
        rows.append((label, depth, ci, style["color"], style["hatch"]))

    labels = [r[0] for r in rows]
    depths = [r[1] for r in rows]
    ci95 = [r[2] for r in rows]
    colors = [r[3] for r in rows]
    hatches = [r[4] for r in rows]
    positions = list(range(len(rows)))

    fig, ax = plt.subplots(figsize=(10, 7))
    bars = ax.bar(
        positions,
        depths,
        width=0.36,
        color=colors,
        edgecolor=EDGE_COLOR,
        linewidth=1.2,
        yerr=ci95,
        capsize=5,
        error_kw={"ecolor": EDGE_COLOR, "elinewidth": 1.4, "capthick": 1.4},
    )
    for bar, hatch in zip(bars, hatches):
        bar.set_hatch(hatch)
    for position, value, error in zip(positions, depths, ci95):
        ax.text(
            position,
            value + error + 0.08,
            f"{value:.2f}",
            ha="center",
            va="bottom",
            fontsize=17,
            fontname="Times New Roman",
        )

    ax.set_xticks(positions, labels)
    ax.set_xlim(-0.5, len(rows) - 0.5)
    ax.set_ylim(0, 4)
    ax.set_yticks((0, 1, 2, 3, 4))
    ax.set_xlabel("Number of atoms", fontsize=24, fontname="Times New Roman")
    ax.set_ylabel("Completed attack stages", fontsize=26, fontname="Times New Roman")

    format_axes(ax)

    fig.tight_layout()
    for suffix in ("png", "pdf"):
        path = OUTPUT_DIR / f"{OUTPUT_STEM}.{suffix}"
        fig.savefig(path, bbox_inches="tight", facecolor="white", dpi=600)
        print(f"wrote {path}")
    plt.close(fig)


if __name__ == "__main__":
    main()
