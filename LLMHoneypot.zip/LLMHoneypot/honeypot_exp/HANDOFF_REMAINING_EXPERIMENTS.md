# 第三章补充实验交接（2026-10-14）

不熟悉目录时先看 [文件地图](FILE_GUIDE.md)，其中逐个解释脚本、知识库和输出文件。

## 目前状态与必须保留的证据

工作目录：`D:\studyPython2025\LLMHoneypot\honeypot_exp`。目前**尚未**取得可写入图 3-8、图 3-9 的新版 Proposed-2 / Proposed-5 完整 30 任务结果；此前的六任务配对运行仅用于代码验证，其输出已清理。

| 路径 | 用途 | 是否可当最终结果 |
|---|---|---|
| `outputs/3-8(9)/combined_checkpoint.jsonl` | 旧实验原始 checkpoint；供离线重评分审计 | 不可直接使用旧汇总数值 |
| `outputs/legacy_baselines_rescored_final/` | 旧 Baseline-2、Baseline-3、AdvancedShelLM 共 90 个会话的统一重评分；含 checkpoint、CSV、图和 `rescore_manifest.json` | 可用作新版比较的旧方法数据，须注明离线重评分 |
| `strategy_atoms.json`、`strategy_atoms_manifest.json` | 冻结的 120 条 clean 策略原子 | 运行输入，需保留 |
| `kb_sensitivity/` | clean、coverage_drop_25、noise_25、conflict_25 四个冻结条件 | 运行输入，需保留 |

已清除六任务验证包、多轮旧 smoke 输出、旧图表、四个不再使用或容易误导的历史脚本和 Python 缓存。当前目录下的 `.git` 为空，`git status` 不可用；发布前应在真实 Git 仓库中记录提交号，或对交付压缩包计算 SHA-256。

旧方法重评分结果：Baseline-2 平均深度 1.600、总 Token 26,406；Baseline-3 平均深度 0.667、总 Token 16,769；AdvancedShelLM 平均深度 1.767、总 Token 539,135（Worker 102,199、Manager 436,936）。以上是相同 `stage-evidence-v2` 规则下，保留首次失败回合并截断其后回合得到的结果。源 checkpoint 不可覆盖。具体来源和哈希见 `outputs/legacy_baselines_rescored_final/rescore_manifest.json`。

## 实验设计要点

- 固定种子 `20260721`、同一批 T01–T30、同一评价器与终止规则；新 Proposed-2 和 Proposed-5 各 30 个方法—任务会话。
- 两种 Proposed 方法共用端侧 **Qwen3-8B base checkpoint + 推理时终端提示词**。它不是已丢失的微调 checkpoint；论文不得将本轮结果称作“微调 Qwen3-8B”。Proposed-2 不接收诱捕策略；Proposed-5 在首个观测交互后才检索 Top-5 策略原子，并由 GPT-5.1 边缘模型生成跨层策略。
- 每个条件使用独立输出目录。`main.py` 默认会续跑；同目录中已有不同配置的 manifest/checkpoint 会触发哈希校验失败。不要删 checkpoint 来强行混用。
- `estimated_interaction_duration_min = session_rounds × 2.5`，只是按轮数推算的时长，并非真实驻留时间。Token 为模型 API 返回的用量，Worker 交互、Manager 监督、跨层协调分别报告。
- 与历史论文结果相比，模型 checkpoint、边缘模型与评价流程均有变更。图表和正文必须标明新版实验配置；旧 Proposed-2/5 数值不得与本轮重评分基线拼接。

## 0. 环境与预检

在 PowerShell 中进入 `honeypot_exp`，启用已有 Python 环境，安装 `requirements.txt`。环境变量只在本机设置，不写入仓库：

```powershell
Set-Location 'D:\studyPython2025\LLMHoneypot\honeypot_exp'
python -m pip install -r .\requirements.txt

$env:QWEN_EAS_TOKEN = '<PAI-EAS 服务 Token>'
$env:QWEN_EAS_BASE_URL = '<PAI-EAS 公网调用地址，补 /v1>'
$env:QWEN_EAS_MODEL = 'Qwen3-8B'
$env:OPENAI_API_KEY = '<GPT-5.1 路由服务 Key>'
```

PAI-EAS 的 Token 与阿里云百炼 API Key 不同；`QWEN_EAS_BASE_URL` 应形如 `http://.../api/predict/<服务名>/v1`，不能把主机名重复拼接。运行前确认 EAS 实例仍在线且返回 `Qwen3-8B`。边缘模型由 `run_kb_sensitivity.ps1` 配置为 GPT-5.1；如路由变更，应先核对脚本及输出 manifest。请勿将凭据、终端完整日志、真实地址中的敏感信息提交公开仓库。

```powershell
python .\validate_strategy_atoms.py
python .\main.py --tasks-only
python .\main.py --smoke-test
python .\main.py --experiment-smoke-test
python .\main.py --dry-run --methods Proposed-2 Proposed-5 --task-limit 30
```

`--dry-run` 不访问 API。它只检查当前 shell 的路由、密钥与配置；真正运行前还应以一条独立 smoke 验证服务可用。`--reporter-smoke-test` 会生成合成图表，勿作为论文结果。

## 1. 重新运行 Proposed-2 与 Proposed-5 Clean

建议先运行两方法同一批任务的配对实验。运行时在同一 PowerShell 会话中设置：

```powershell
$env:QWEN_PROVIDER = 'pai-eas'
$env:QWEN_BASE_URL = $env:QWEN_EAS_BASE_URL
$env:QWEN_MODEL_NAME = $env:QWEN_EAS_MODEL
$env:QWEN_API_KEY_ENV = 'QWEN_EAS_TOKEN'
$env:QWEN_AUTHORIZATION_SCHEME = 'raw'
$env:PROPOSED_MODEL_LABEL = 'Qwen3-8B-EAS-Base-PromptAligned'
$env:EDGE_MODEL_LABEL = 'GPT-5.1-Edge'
$env:EDGE_PROVIDER = 'crazyrouter'
$env:EDGE_BASE_URL = 'https://api.crazyrouter.com/v1'
$env:EDGE_MODEL_NAME = 'gpt-5.1'
$env:EDGE_API_KEY_ENV = 'OPENAI_API_KEY'
$env:STRATEGY_ATOM_FILE = (Resolve-Path .\kb_sensitivity\clean\strategy_atoms.json).Path

python .\main.py --run `
  --methods Proposed-2 Proposed-5 `
  --task-limit 30 `
  --output-dir .\outputs\proposed_pair_clean_30
```

中断后用完全相同的命令续跑。成功标准：`experiment_manifest.json` 的 `task_count=30`、`methods` 正确；`checkpoint.jsonl` 有 60 个不同 `(task_id, method)`；`summary.csv` 每方法 30 个会话；所有结果含 `run_config_sha256`，并与 manifest 一致；无未处理的失败。检查若干 `turn.csv`/checkpoint，确认 Proposed-2 没有策略注入，Proposed-5 只使用当前可观察到的证据，且失败后不继续计分。

## 2. 知识库质量敏感性

以 clean、均衡删除 25%、加入 25% 噪声、25% 冲突替换四个条件比较 Proposed-5。同一批 30 任务、同一模型设置和评价规则。`build_kb_sensitivity_variants.py` 使用固定种子生成输入；`kb_sensitivity/sensitivity_manifest.json` 与各条件的 `strategy_atoms_manifest.json` 记录选择和哈希。先验证生成后的哈希与冻结版本一致，再运行：

```powershell
.\run_kb_sensitivity.ps1 -TaskLimit 30 -OutputRoot 'outputs\kb_sensitivity_30'
```

脚本会逐条件写 `checkpoint.jsonl`、`summary.csv`、`experiment_manifest.json` 和 `run.log`。clean 条件可能与第 1 步重复收费；可先比较两次 clean 的配置哈希与实际输入，并决定只将一次 clean 运行作为主比较。**不能把不同模型、提示词或代码版本的 clean 和扰动结果作配对分析。** 每个条件均核对 `task_count=30`、30 条 checkpoint、原子数量与 SHA-256；按同一任务 ID 对比深度、成功率、Token 与检索命中情况。若中途变更代码或模型，四个条件应整套重跑。

## 3. 汇总、绘图和论文

先把第 1 步与第 2 步的完整 checkpoint/manifest 备份，再把新版 Proposed-2/5 与 `legacy_baselines_rescored_final` 的三种旧方法按 T01–T30 合并。`reporter.py` 的 `report()` 负责 CSV 与图 3-8/3-9 类图；合并前须逐条检查方法、任务、配置哈希、重复项和 Token 分项。当前仓库没有经验证的“最终五方法合并”一键命令，不能只复制旧 PDF 当新图。交接人应先实现或审查离线合并脚本，并用两份 checkpoint 生成统一报告。

论文中应分别说明：旧基线来自统一离线重评分；新 Proposed 来自 base Qwen3-8B 推理时提示词配置；边缘侧是 GPT-5.1；时长为轮数估算。AdvancedShelLM 的 Worker–Manager 使用 GPT-5.1，模型条件不同，不能把性能差异单独归因于架构。知识库敏感性属于 Proposed-5 的独立实验，不与四方法总体比较混为一项。

## 提交前检查

1. 保存代码版本、第三方 `AdvancedshelLM` commit、模型返回 ID、温度/Top-p/最大输出、任务种子及评价器版本。
2. 逐条件保存原始 checkpoint、manifest、汇总 CSV 和输入知识库哈希。排除空运行、重复会话及配置不一致的续跑。
3. 核对文本、图、表的每个数字都来自同一最终结果包；旧数值如 AdvancedShelLM 深度 3.333、Token 758,886 已失效。
4. 公共仓库发布前检查 checkpoint 和日志中的凭据、内部端点、诱饵账号及敏感路径。必要时仅公开脱敏数据和原始文件 SHA-256。
