"""Build extreme coverage ablations for the KB-sensitivity experiment.

* coverage_5: keep exactly five atoms -- a high-quality minimal sample of one
  atom per decoy-map field (host, service, credential, file, pivot).  The five
  atoms are drawn from five distinct attack-type families chosen for relevance
  to the six benchmark task families, and the value-bearing fields carry
  concrete decoy values rather than generic directives.  This keeps
  "coverage_5" a measure of KB sparsity, not of a single family's bias.
* coverage_5_mixed: five atoms again, but only two are high-quality; the other
  three are drawn from task-irrelevant attack families (man-in-the-middle, log
  deletion, backdoor).  Isolates atom *quality* at fixed sparsity (5 atoms).
* coverage_0: empty KB.  The endpoint keeps running; the edge model composes the
  decoy map from the task chain alone, with no retrieved atoms.

Both share the frozen clean parent (strategy_atoms.json) and are generated
deterministically for reproducibility.
"""

from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "strategy_atoms.json"
OUTPUT_ROOT = ROOT / "kb_sensitivity"
SEED = 20260721
VERSION = "sagvn-kb-sensitivity-v4.0.0"

CATEGORIES = ("host", "service", "credential", "file", "pivot")

# High-quality minimal KB: one atom per decoy-map field, five distinct attack
# families, concrete decoy values where the field is value-bearing.  Families
# are the ones most representative of the six benchmark task families
# (SSH / Web API / container / database / IoT / satellite).
_HIGH_QUALITY_ATOM_IDS = (
    "data_theft-01",           # host       (data theft spans web/db/iot)
    "brute_force-02",          # service    (SSH service; SSH family)
    "valid_account_abuse-03",  # credential (deploy/vehicle123; ssh/db reuse)
    "privilege_escalation-04", # file       (/etc/sudoers.d/deploy)
    "authorization_bypass-05", # pivot      (10.40.3.21:830)
)

# coverage_5_mixed: same five fields, but only two atoms stay high-quality
# (brute_force service, valid-account credential).  The other three come from
# families that never occur in the six benchmark task families, so they act as
# relevance noise while the KB size is held fixed at five atoms.
_MIXED_ATOM_IDS = (
    "man_in_the_middle-01",   # host       (poor: task-irrelevant family)
    "brute_force-02",         # service    (HIGH QUALITY)
    "valid_account_abuse-03", # credential (HIGH QUALITY)
    "log_deletion-04",        # file       (poor: task-irrelevant family)
    "backdoor-05",            # pivot      (poor: task-irrelevant family)
)

# coverage_5_1good4poor: one high-quality atom (the valid-account credential)
# plus four task-irrelevant atoms.  Final step of the quality-degradation
# series at fixed five-atom sparsity.
_ONE_GOOD_FOUR_POOR_ATOM_IDS = (
    "man_in_the_middle-01",   # host       (poor: task-irrelevant family)
    "log_deletion-02",        # service    (poor: task-irrelevant family)
    "valid_account_abuse-03", # credential (HIGH QUALITY)
    "log_deletion-04",        # file       (poor: task-irrelevant family)
    "backdoor-05",            # pivot      (poor: task-irrelevant family)
)


def _payload(atoms: list[dict[str, object]]) -> bytes:
    return (json.dumps(atoms, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _write(
    condition: str,
    atoms: list[dict[str, object]],
    operation: str,
    selection_audit: dict[str, object],
) -> dict[str, object]:
    directory = OUTPUT_ROOT / condition
    directory.mkdir(parents=True, exist_ok=True)
    payload = _payload(atoms)
    (directory / "strategy_atoms.json").write_bytes(payload)
    manifest = {
        "knowledge_base_version": f"{VERSION}-{condition}",
        "frozen_at": "2026-10-23",
        "condition": condition,
        "operation": operation,
        "seed": SEED,
        "parent_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "atom_file": "strategy_atoms.json",
        "sha256": hashlib.sha256(payload).hexdigest(),
        "atom_count": len(atoms),
        "attack_type_counts": dict(sorted(Counter(str(a["attack_type"]) for a in atoms).items())),
        "category_counts": dict(sorted(Counter(str(a["category"]) for a in atoms).items())),
        "selection_audit": selection_audit,
        "allowed_tiers": ["ground", "air", "space"],
        "allowed_stages": ["reconnaissance", "sensitive_information_theft", "privilege_escalation", "lateral_movement"],
    }
    (directory / "strategy_atoms_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(f"{condition}: atoms={len(atoms)} sha256={manifest['sha256'][:12]} cat={manifest['category_counts']}")
    return manifest


def _select_coverage_5(base: list[dict[str, object]]) -> list[dict[str, object]]:
    by_id = {str(a["atom_id"]): a for a in base}
    missing = [atom_id for atom_id in _HIGH_QUALITY_ATOM_IDS if atom_id not in by_id]
    if missing:
        raise ValueError(f"high-quality atom ids not found in parent KB: {missing}")
    keep = [by_id[atom_id] for atom_id in _HIGH_QUALITY_ATOM_IDS]
    # Guard against an accidental collapse into one family/field.
    assert len({str(a["attack_type"]) for a in keep}) == 5
    assert len({str(a["category"]) for a in keep}) == 5
    return keep


def build_coverage_5_mixed() -> dict[str, object]:
    """Write only the mixed-quality five-atom KB (2 high + 3 task-irrelevant)."""
    base = json.loads(SOURCE.read_text(encoding="utf-8"))
    if not isinstance(base, list) or len(base) != 120:
        raise ValueError("expected the frozen 120-atom parent knowledge base")
    by_id = {str(a["atom_id"]): a for a in base}
    missing = [atom_id for atom_id in _MIXED_ATOM_IDS if atom_id not in by_id]
    if missing:
        raise ValueError(f"mixed atom ids not found in parent KB: {missing}")
    keep = [by_id[atom_id] for atom_id in _MIXED_ATOM_IDS]
    assert len({str(a["category"]) for a in keep}) == 5
    return _write(
        "coverage_5_mixed",
        keep,
        "two high-quality atoms plus three task-irrelevant atoms (5 total)",
        {
            "selection_method": "mixed quality",
            "atom_ids": list(_MIXED_ATOM_IDS),
            "high_quality": ["brute_force-02", "valid_account_abuse-03"],
            "poor": ["man_in_the_middle-01", "log_deletion-04", "backdoor-05"],
            "fields": list(CATEGORIES),
        },
    )


def build_coverage_5_1good4poor() -> dict[str, object]:
    """Write only the 1-high-quality + 4-task-irrelevant five-atom KB."""
    base = json.loads(SOURCE.read_text(encoding="utf-8"))
    if not isinstance(base, list) or len(base) != 120:
        raise ValueError("expected the frozen 120-atom parent knowledge base")
    by_id = {str(a["atom_id"]): a for a in base}
    missing = [atom_id for atom_id in _ONE_GOOD_FOUR_POOR_ATOM_IDS if atom_id not in by_id]
    if missing:
        raise ValueError(f"one-good atom ids not found in parent KB: {missing}")
    keep = [by_id[atom_id] for atom_id in _ONE_GOOD_FOUR_POOR_ATOM_IDS]
    assert len({str(a["category"]) for a in keep}) == 5
    return _write(
        "coverage_5_1good4poor",
        keep,
        "one high-quality atom plus four task-irrelevant atoms (5 total)",
        {
            "selection_method": "mixed quality",
            "atom_ids": list(_ONE_GOOD_FOUR_POOR_ATOM_IDS),
            "high_quality": ["valid_account_abuse-03"],
            "poor": ["man_in_the_middle-01", "log_deletion-02", "log_deletion-04", "backdoor-05"],
            "fields": list(CATEGORIES),
        },
    )


def main() -> int:
    base = json.loads(SOURCE.read_text(encoding="utf-8"))
    if not isinstance(base, list) or len(base) != 120:
        raise ValueError("expected the frozen 120-atom parent knowledge base")

    # coverage_5: high-quality diverse five-atom sample.
    keep = _select_coverage_5(base)
    _write(
        "coverage_5",
        keep,
        "high-quality five-atom sample (one per decoy-map field)",
        {
            "selection_method": "high-quality minimal sample",
            "atom_ids": list(_HIGH_QUALITY_ATOM_IDS),
            "fields": list(CATEGORIES),
            "attack_families": sorted({str(a["attack_type"]) for a in keep}),
        },
    )

    # coverage_5_mixed: two high-quality atoms plus three task-irrelevant atoms.
    build_coverage_5_mixed()

    # coverage_5_1good4poor: one high-quality atom plus four task-irrelevant atoms.
    build_coverage_5_1good4poor()

    # coverage_0: empty KB (no retrieval content; edge composes from the chain).
    _write(
        "coverage_0",
        [],
        "empty knowledge base (0 atoms)",
        {"selection_method": "empty"},
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
