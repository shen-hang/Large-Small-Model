"""Build the 30-atom mixed-quality KB: 10 high-quality + 20 task-irrelevant atoms.

This is the "quality ratio at larger sparsity" condition.  At fixed 30 atoms we
keep one-third of the KB task-relevant (10 atoms, two per decoy-map field, drawn
from the seven task-relevant attack families) and two-thirds task-irrelevant
(20 atoms, four per field, drawn from man-in-the-middle / log-deletion /
backdoor).  It extends the coverage_5_* quality series (1 good / 2 good / all
good at 5 atoms) to a larger KB size, isolating *quality ratio* from *sparsity*.

Selection is deterministic (explicit atom ids, byte-identical to the frozen
120-atom parent) for reproducibility.
"""

from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "strategy_atoms.json"
OUTPUT_ROOT = ROOT / "kb_sensitivity"
SEED = 20260721
VERSION = "sagvn-kb-sensitivity-v4.0.0"
CONDITION = "coverage_30_10good20poor"

CATEGORIES = ("host", "service", "credential", "file", "pivot")

# Task-relevant families (map onto the six benchmark task families).
GOOD_FAMILIES = {
    "brute_force",
    "data_theft",
    "vulnerability_exploitation",
    "authorization_bypass",
    "privilege_escalation",
    "valid_account_abuse",
    "tunneling",
}
# Task-irrelevant families (never occur in the six benchmark task families).
POOR_FAMILIES = {"man_in_the_middle", "log_deletion", "backdoor"}

# 10 high-quality atoms: two per decoy-map field, spanning all seven
# task-relevant families.
_HIGH_QUALITY_10 = (
    "data_theft-01",               # host
    "vulnerability_exploitation-01",  # host
    "brute_force-02",              # service
    "vulnerability_exploitation-02",  # service
    "valid_account_abuse-03",      # credential
    "privilege_escalation-03",     # credential
    "privilege_escalation-04",     # file
    "data_theft-04",               # file
    "authorization_bypass-05",     # pivot
    "tunneling-05",                # pivot
)

# 20 task-irrelevant atoms: four per decoy-map field, drawn from the three
# poor families (man_in_the_middle / log_deletion / backdoor).
_POOR_20 = (
    # host (4)
    "man_in_the_middle-01",
    "log_deletion-01",
    "backdoor-01",
    "backdoor-09",
    # service (4)
    "man_in_the_middle-02",
    "log_deletion-02",
    "backdoor-02",
    "backdoor-06",
    # credential (4)
    "man_in_the_middle-03",
    "log_deletion-03",
    "backdoor-03",
    "backdoor-07",
    # file (4)
    "man_in_the_middle-04",
    "log_deletion-04",
    "backdoor-04",
    "man_in_the_middle-08",
    # pivot (4)
    "man_in_the_middle-05",
    "log_deletion-05",
    "backdoor-05",
    "man_in_the_middle-11",
)


def _payload(atoms: list[dict[str, object]]) -> bytes:
    return (json.dumps(atoms, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def main() -> int:
    base = json.loads(SOURCE.read_text(encoding="utf-8"))
    if not isinstance(base, list) or len(base) != 120:
        raise ValueError("expected the frozen 120-atom parent knowledge base")
    by_id = {str(a["atom_id"]): a for a in base}

    all_ids = list(_HIGH_QUALITY_10) + list(_POOR_20)
    missing = [i for i in all_ids if i not in by_id]
    if missing:
        raise ValueError(f"atom ids not found in parent KB: {missing}")
    if len(set(all_ids)) != 30:
        raise ValueError("atom id overlap between good and poor lists")

    good = [by_id[i] for i in _HIGH_QUALITY_10]
    poor = [by_id[i] for i in _POOR_20]

    # Guard the intended quality/category structure.
    for a in good:
        assert str(a["attack_type"]) in GOOD_FAMILIES, a["atom_id"]
    for a in poor:
        assert str(a["attack_type"]) in POOR_FAMILIES, a["atom_id"]
    assert Counter(str(a["category"]) for a in good) == Counter(
        {c: 2 for c in CATEGORIES}
    ), Counter(str(a["category"]) for a in good)
    assert Counter(str(a["category"]) for a in poor) == Counter(
        {c: 4 for c in CATEGORIES}
    ), Counter(str(a["category"]) for a in poor)

    atoms = good + poor
    directory = OUTPUT_ROOT / CONDITION
    directory.mkdir(parents=True, exist_ok=True)
    payload = _payload(atoms)
    (directory / "strategy_atoms.json").write_bytes(payload)

    manifest = {
        "knowledge_base_version": f"{VERSION}-{CONDITION}",
        "frozen_at": "2026-10-25",
        "condition": CONDITION,
        "operation": "10 high-quality atoms plus 20 task-irrelevant atoms (30 total)",
        "seed": SEED,
        "parent_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "atom_file": "strategy_atoms.json",
        "sha256": hashlib.sha256(payload).hexdigest(),
        "atom_count": len(atoms),
        "attack_type_counts": dict(sorted(Counter(str(a["attack_type"]) for a in atoms).items())),
        "category_counts": dict(sorted(Counter(str(a["category"]) for a in atoms).items())),
        "selection_audit": {
            "selection_method": "explicit atom ids (byte-identical parent copies)",
            "high_quality_atom_ids": list(_HIGH_QUALITY_10),
            "poor_atom_ids": list(_POOR_20),
            "high_quality_families": sorted(GOOD_FAMILIES),
            "poor_families": sorted(POOR_FAMILIES),
            "fields": list(CATEGORIES),
            "good_per_field": 2,
            "poor_per_field": 4,
        },
        "allowed_tiers": ["ground", "air", "space"],
        "allowed_stages": ["reconnaissance", "sensitive_information_theft", "privilege_escalation", "lateral_movement"],
    }
    (directory / "strategy_atoms_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(f"{CONDITION}: atoms={len(atoms)} sha256={manifest['sha256'][:12]}")
    print(f"  attack_type_counts={manifest['attack_type_counts']}")
    print(f"  category_counts={manifest['category_counts']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
