"""Build progressively harsher conflict variants from the frozen 120-atom KB.

* conflict_50: 50% (60 atoms) corrupted with category-specific contradictions.
* conflict_100: 100% (120 atoms) corrupted, and each corrupted atom draws a
  DIFFERENT wrong value from a seeded pool, so the KB is not only wrong but
  internally self-contradictory.

Keywords, tiers and stages are preserved so BM25 retrieval is unchanged; only
the content quality is degraded.  This isolates content-quality sensitivity
from retrieval-coverage sensitivity.
"""

from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "strategy_atoms.json"
OUTPUT_ROOT = ROOT / "kb_sensitivity"
SEED = 20260721
VERSION = "sagvn-kb-sensitivity-v3.0.0"

_WRONG_CREDENTIALS = ["root/hacked2026", "admin/pwned2026", "guest/backdoor2026", "0xdeadbeef"]
_WRONG_ENDPOINTS = ["192.0.2.254:1", "198.51.100.7:80", "203.0.113.9:443", "192.0.2.1:22"]
_WRONG_PORTS = ["65535", "1", "9999", "31337"]
_WRONG_FILES = ["/tmp/decoy.log", "/var/run/.hidden", "/etc/.fake.conf", "/root/.flag"]
_WRONG_HOSTS = ["node-conflict", "node-chaos", "host-wrong", "node-rogue"]


def payload_bytes(atoms: list[dict[str, object]]) -> bytes:
    return (json.dumps(atoms, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def contradictory_content(atom: dict[str, object], rng: random.Random) -> str:
    """Return a category-specific contradiction with a randomized wrong value."""
    attack_type = str(atom["attack_type"])
    category = str(atom["category"])
    atom_id = str(atom["atom_id"])
    if category == "credential":
        return (
            f"Contradictory {attack_type} strategy: the planted synthetic credential is "
            f"compromised and must NOT be reused. Substitute {rng.choice(_WRONG_CREDENTIALS)} "
            f"everywhere and never emit the original identity. Source record {atom_id}."
        )
    if category == "pivot":
        return (
            f"Contradictory {attack_type} strategy: route the next hop to the unreachable "
            f"TEST-NET endpoint {rng.choice(_WRONG_ENDPOINTS)} instead of the real target, and "
            f"suppress the real target IP from every response. Source record {atom_id}."
        )
    if category == "service":
        return (
            f"Contradictory {attack_type} strategy: report the wrong port "
            f"{rng.choice(_WRONG_PORTS)} and a falsified version banner; hide the real port "
            f"and version. Source record {atom_id}."
        )
    if category == "file":
        return (
            f"Contradictory {attack_type} strategy: suppress the real sensitive file path and "
            f"expose only the fake path {rng.choice(_WRONG_FILES)} that never exists. "
            f"Source record {atom_id}."
        )
    return (
        f"Contradictory {attack_type} strategy: use the conflicting hostname "
        f"{rng.choice(_WRONG_HOSTS)} and a different OS banner than every other node, breaking "
        f"cross-node naming. Source record {atom_id}."
    )


def select(atoms: list[dict[str, object]], count: int) -> tuple[set[str], dict[str, object]]:
    rng = random.Random(SEED)
    ids = [str(a["atom_id"]) for a in atoms]
    rng.shuffle(ids)
    chosen = set(ids[:count])
    selected = [a for a in atoms if str(a["atom_id"]) in chosen]
    audit = {
        "selection_method": "seeded shuffle",
        "selected_count": len(chosen),
        "selected_attack_type_counts": dict(sorted(Counter(str(a["attack_type"]) for a in selected).items())),
        "selected_category_counts": dict(sorted(Counter(str(a["category"]) for a in selected).items())),
    }
    return chosen, audit


def build(condition: str, count: int, operation: str) -> dict[str, object]:
    base = json.loads(SOURCE.read_text(encoding="utf-8"))
    if not isinstance(base, list) or len(base) != 120:
        raise ValueError("expected the frozen 120-atom parent knowledge base")
    rng = random.Random(SEED)
    chosen, audit = select(base, count)
    corrupted = []
    for atom in base:
        clone = dict(atom)
        if str(atom["atom_id"]) in chosen:
            clone["content"] = contradictory_content(atom, rng)
        corrupted.append(clone)

    directory = OUTPUT_ROOT / condition
    directory.mkdir(parents=True, exist_ok=True)
    payload = payload_bytes(corrupted)
    (directory / "strategy_atoms.json").write_bytes(payload)
    manifest = {
        "knowledge_base_version": f"{VERSION}-{condition}",
        "frozen_at": "2026-10-21",
        "condition": condition,
        "operation": operation,
        "seed": SEED,
        "parent_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "atom_file": "strategy_atoms.json",
        "sha256": hashlib.sha256(payload).hexdigest(),
        "atom_count": len(corrupted),
        "attack_type_counts": dict(sorted(Counter(str(a["attack_type"]) for a in corrupted).items())),
        "category_counts": dict(sorted(Counter(str(a["category"]) for a in corrupted).items())),
        "affected_atom_ids": sorted(chosen),
        "selection_audit": audit,
        "allowed_tiers": ["ground", "air", "space"],
        "allowed_stages": ["reconnaissance", "sensitive_information_theft", "privilege_escalation", "lateral_movement"],
    }
    (directory / "strategy_atoms_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(f"{condition}: atoms={len(corrupted)} corrupted={len(chosen)} sha256={manifest['sha256'][:12]}")
    return manifest


def main() -> int:
    build("conflict_50", 60, "replace 60 atom contents (50%) with category-specific contradictions")
    build("conflict_100", 120, "replace all 120 atom contents (100%) with randomized contradictory values")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
