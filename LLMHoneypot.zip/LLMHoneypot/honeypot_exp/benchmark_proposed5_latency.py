"""Measure Proposed-5 latency for one task without changing experiment results.

This is an isolated probe: it reuses the production Proposed-5 execution path,
but writes only to ``outputs/latency_probe`` and never touches checkpoints or
the CSV files used by the paper figures.
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import asdict, dataclass
import json
from pathlib import Path
from time import perf_counter_ns
from typing import Sequence

from config import OUTPUT_DIR, PROPOSED_MODEL_NAME, STRATEGY_MAX_TOKENS
from experiment import ExperimentRunner
from model import ChatResult, Message, chat
from tasks import TASK_COUNT, generate_tasks


DEFAULT_OUTPUT_DIR = OUTPUT_DIR / "latency_probe"


@dataclass(frozen=True)
class LatencyRecord:
    request_type: str
    request_number: int
    latency_ms: float
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class TimedChat:
    """Transparent chat wrapper that records end-to-end request latency."""

    def __init__(self) -> None:
        self.records: list[LatencyRecord] = []
        self._interaction_count = 0

    def __call__(
        self,
        messages: Sequence[Message],
        model_name: str,
        *,
        max_tokens: int | None = None,
    ) -> ChatResult:
        is_coordination = max_tokens == STRATEGY_MAX_TOKENS
        request_type = "coordination" if is_coordination else "interaction"
        if is_coordination:
            request_number = 1
        else:
            self._interaction_count += 1
            request_number = self._interaction_count

        started_ns = perf_counter_ns()
        result = chat(messages, model_name, max_tokens=max_tokens)
        elapsed_ms = (perf_counter_ns() - started_ns) / 1_000_000
        self.records.append(
            LatencyRecord(
                request_type=request_type,
                request_number=request_number,
                latency_ms=elapsed_ms,
                prompt_tokens=result.prompt_tokens,
                completion_tokens=result.completion_tokens,
                total_tokens=result.total_tokens,
            )
        )
        return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Measure coordination and interaction latency for one Proposed-5 task."
    )
    parser.add_argument(
        "--task-id",
        default="T04",
        help="one deterministic task ID from T01 to T30 (default: T04)",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help="isolated directory for latency JSON/CSV output",
    )
    return parser


def _mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def main() -> int:
    args = build_parser().parse_args()
    tasks = {task.task_id: task for task in generate_tasks(TASK_COUNT)}
    task_id = args.task_id.upper()
    if task_id not in tasks:
        raise SystemExit(f"unknown task ID {args.task_id!r}; choose T01 through T30")

    timed_chat = TimedChat()
    result = ExperimentRunner(chat_function=timed_chat).run(tasks[task_id], "Proposed-5")
    coordination = [r for r in timed_chat.records if r.request_type == "coordination"]
    interactions = [r for r in timed_chat.records if r.request_type == "interaction"]

    summary = {
        "task_id": task_id,
        "method": "Proposed-5",
        "model_name": PROPOSED_MODEL_NAME,
        "timing_scope": "client end-to-end wall-clock time",
        "completed": result.completed,
        "attack_depth": result.attack_depth,
        "session_rounds": result.session_rounds,
        "termination_reason": result.termination_reason,
        "coordination_requests": len(coordination),
        "coordination_strategy_generation_ms": round(
            _mean([r.latency_ms for r in coordination]), 3
        ),
        "interaction_requests": len(interactions),
        "mean_interaction_response_ms": round(
            _mean([r.latency_ms for r in interactions]), 3
        ),
        "total_interaction_response_ms": round(
            sum(r.latency_ms for r in interactions), 3
        ),
    }

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / f"{task_id.lower()}_proposed5_latency.json"
    csv_path = output_dir / f"{task_id.lower()}_proposed5_latency.csv"
    json_path.write_text(
        json.dumps(
            {"summary": summary, "requests": [asdict(r) for r in timed_chat.records]},
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=tuple(asdict(timed_chat.records[0])))
        writer.writeheader()
        writer.writerows(asdict(record) for record in timed_chat.records)

    print("Proposed-5 single-task latency probe")
    print(f"  task: {task_id}")
    print(f"  coordination strategy generation: "
          f"{summary['coordination_strategy_generation_ms']:.3f} ms")
    print(f"  mean interaction response: "
          f"{summary['mean_interaction_response_ms']:.3f} ms "
          f"({len(interactions)} command(s))")
    print(f"  session: depth={result.attack_depth}, rounds={result.session_rounds}, "
          f"stop={result.termination_reason}")
    print(f"  JSON: {json_path}")
    print(f"  CSV:  {csv_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
