"""CSV exports and publication-ready figures for experiment results."""

from __future__ import annotations

import csv
from dataclasses import asdict, dataclass
import math
from pathlib import Path
from statistics import mean, stdev
from typing import Iterable, Sequence

from config import METHODS, OUTPUT_DIR
from experiment import SessionResult


PLOT_SCALE = 1.2
REPORT_METHODS = (
    "Baseline-2", "Baseline-3", "Single-Agent-GPT-5.1", "AdvancedShelLM",
    "Proposed-2", "Proposed-5"
)
METHOD_COLORS = {
    "Baseline-1": "#d62728",
    "Baseline-2": "#ff7f0e",
    "Baseline-3": "#9467bd",
    "Single-Agent-GPT-5.1": "#8c564b",
    "AdvancedShelLM": "#17becf",
    "Proposed-2": "#1f77b4",
    "Proposed-5": "#2ca02c",
}
METHOD_MARKERS = {
    "Baseline-2": "o",
    "Baseline-3": "s",
    "Single-Agent-GPT-5.1": "P",
    "AdvancedShelLM": "D",
    "Proposed-2": "^",
    "Proposed-5": "v",
}
METHOD_LINESTYLES = {
    "Baseline-2": ":",
    "Baseline-3": "-",
    "Single-Agent-GPT-5.1": (0, (3, 1, 1, 1)),
    "AdvancedShelLM": (0, (5, 2)),
    "Proposed-2": "--",
    "Proposed-5": "-.",
}
ATTACK_DEPTH_COLORS = {
    "Baseline-1": "#7A8FA6",
    "Baseline-2": "#9BB7C9",
    "Baseline-3": "#89A99A",
    "Single-Agent-GPT-5.1": "#B89A88",
    "AdvancedShelLM": "#8F79B7",
    "Proposed-2": "#C58F7A",
    "Proposed-5": "#D2B86A",
}
ATTACK_DEPTH_PATTERNS = {
    "Baseline-1": "///",
    "Baseline-2": "...",
    "Baseline-3": "+++",
    "Single-Agent-GPT-5.1": "..",
    "AdvancedShelLM": "oo",
    "Proposed-2": "xxx",
    "Proposed-5": "\\\\",
}
ATTACK_DEPTH_EDGE_COLOR = "#444444"
SESSION_MINUTES_PER_ROUND = 2.5
DISPLAY_LABELS = {
    "AdvancedShelLM": "Advanced-\nShelLM",
    "Single-Agent-GPT-5.1": "Single-Agent\nGPT-5.1",
}


def _display_label(method: str) -> str:
    return DISPLAY_LABELS.get(method, method)


def _clean_log_ticks(axis, lower: float, upper: float) -> None:
    """Use sparse numeric labels on a log axis and suppress minor tick clutter."""

    from matplotlib.ticker import FixedLocator, FuncFormatter, NullLocator

    ticks: list[float] = []
    start = math.floor(math.log10(lower)) - 1
    stop = math.ceil(math.log10(upper)) + 1
    for exponent in range(start, stop + 1):
        for multiplier in (1, 3):
            value = multiplier * (10 ** exponent)
            if lower <= value <= upper:
                ticks.append(float(value))
    axis.set_major_locator(FixedLocator(ticks))
    axis.set_major_formatter(FuncFormatter(lambda value, _pos: f"{value:,.0f}"))
    axis.set_minor_locator(NullLocator())


@dataclass(frozen=True)
class MethodSummary:
    method: str
    sessions: int
    completed_sessions: int
    completion_rate: float
    average_attack_depth: float
    attack_depth_std: float
    average_session_rounds: float
    average_estimated_interaction_duration_min: float
    interaction_prompt_tokens: int
    interaction_completion_tokens: int
    interaction_tokens: int
    supervision_prompt_tokens: int
    supervision_completion_tokens: int
    supervision_tokens: int
    coordination_prompt_tokens: int
    coordination_completion_tokens: int
    coordination_tokens: int
    setup_prompt_tokens: int
    setup_completion_tokens: int
    setup_tokens: int
    overall_tokens: int
    average_overall_tokens: float


def _ordered(results: Iterable[SessionResult]) -> tuple[SessionResult, ...]:
    method_order = {method: index for index, method in enumerate(REPORT_METHODS)}
    rows = tuple(sorted(results, key=lambda item: (method_order[item.method], item.task_id)))
    if not rows:
        raise ValueError("at least one SessionResult is required")
    keys = [(row.task_id, row.method) for row in rows]
    if len(keys) != len(set(keys)):
        raise ValueError("duplicate task/method session results are not allowed")
    return rows


def summarize(results: Iterable[SessionResult]) -> tuple[MethodSummary, ...]:
    rows = _ordered(results)
    summaries: list[MethodSummary] = []
    for method in REPORT_METHODS:
        group = [row for row in rows if row.method == method]
        if not group:
            continue
        depths = [row.attack_depth for row in group]
        summaries.append(
            MethodSummary(
                method=method,
                sessions=len(group),
                completed_sessions=sum(row.completed for row in group),
                completion_rate=sum(row.completed for row in group) / len(group),
                average_attack_depth=mean(depths),
                attack_depth_std=stdev(depths) if len(depths) > 1 else 0.0,
                average_session_rounds=mean(row.session_rounds for row in group),
                average_estimated_interaction_duration_min=(
                    mean(row.session_rounds for row in group)
                    * SESSION_MINUTES_PER_ROUND
                ),
                interaction_prompt_tokens=sum(row.interaction_prompt_tokens for row in group),
                interaction_completion_tokens=sum(row.interaction_completion_tokens for row in group),
                interaction_tokens=sum(row.interaction_tokens for row in group),
                supervision_prompt_tokens=sum(
                    row.supervision_prompt_tokens for row in group
                ),
                supervision_completion_tokens=sum(
                    row.supervision_completion_tokens for row in group
                ),
                supervision_tokens=sum(row.supervision_tokens for row in group),
                coordination_prompt_tokens=sum(row.coordination_prompt_tokens for row in group),
                coordination_completion_tokens=sum(row.coordination_completion_tokens for row in group),
                coordination_tokens=sum(row.coordination_tokens for row in group),
                setup_prompt_tokens=sum(row.setup_prompt_tokens for row in group),
                setup_completion_tokens=sum(row.setup_completion_tokens for row in group),
                setup_tokens=sum(row.setup_tokens for row in group),
                overall_tokens=sum(row.overall_tokens for row in group),
                average_overall_tokens=mean(row.overall_tokens for row in group),
            )
        )
    return tuple(summaries)


def _write_csv(path: Path, fieldnames: Sequence[str], rows: Iterable[dict[str, object]]) -> None:
    # UTF-8 BOM keeps Chinese/Unicode content readable in Excel while remaining
    # compatible with pandas, R, and standard CSV readers.
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_csv_reports(
    results: Iterable[SessionResult], output_dir: Path = OUTPUT_DIR
) -> tuple[Path, Path, Path]:
    rows = _ordered(results)
    output_dir.mkdir(parents=True, exist_ok=True)

    session_fields = (
        "run_config_sha256", "task_id", "method", "model_name",
        "coordination_model_name", "attack_depth", "session_rounds",
        "estimated_interaction_duration_min",
        "completed", "termination_reason", "interaction_prompt_tokens",
        "interaction_completion_tokens", "interaction_tokens",
        "supervision_prompt_tokens", "supervision_completion_tokens",
        "supervision_tokens",
        "coordination_prompt_tokens", "coordination_completion_tokens",
        "coordination_tokens", "setup_prompt_tokens", "setup_completion_tokens",
        "setup_tokens", "overall_tokens", "strategy", "wall_clock_ms",
        "retrieved_atom_ids", "retrieval_scores", "retrieval_compute_ms",
        "knowledge_base_atoms", "knowledge_base_version",
        "knowledge_base_sha256", "retrieved_content_sha256",
        "strategy_validation_errors", "strategy_invalid_response",
    )
    session_path = output_dir / "session.csv"
    session_rows = []
    for session in rows:
        row = asdict(session)
        row["estimated_interaction_duration_min"] = (
            session.session_rounds * SESSION_MINUTES_PER_ROUND
        )
        row["retrieved_atom_ids"] = "|".join(session.retrieved_atom_ids)
        row["retrieval_scores"] = "|".join(
            f"{score:.6f}" for score in session.retrieval_scores
        )
        row["strategy_validation_errors"] = "|".join(
            session.strategy_validation_errors
        )
        session_rows.append(row)
    _write_csv(session_path, session_fields, session_rows)

    turn_fields = (
        "task_id", "method", "round_number", "stage", "tier", "command",
        "response", "command_valid", "ai_exposure", "evidence_matched",
        "success", "prompt_tokens", "completion_tokens", "total_tokens",
        "latency_ms", "worker_calls", "manager_calls", "reprompt_count",
        "worker_prompt_tokens", "worker_completion_tokens", "worker_tokens",
        "manager_prompt_tokens", "manager_completion_tokens", "manager_tokens",
        "response_scope_issues",
    )
    turn_rows = []
    for session in rows:
        for turn in session.turns:
            row = asdict(turn)
            row["evidence_matched"] = "|".join(turn.evidence_matched)
            row["response_scope_issues"] = "|".join(turn.response_scope_issues)
            turn_rows.append(row)
    turn_path = output_dir / "turn.csv"
    _write_csv(turn_path, turn_fields, turn_rows)

    summary_path = output_dir / "summary.csv"
    summary_rows = [asdict(item) for item in summarize(rows)]
    _write_csv(summary_path, tuple(MethodSummary.__dataclass_fields__), summary_rows)
    return session_path, turn_path, summary_path


def _pyplot():
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise RuntimeError("matplotlib is required to generate Phase-4 figures") from exc
    plt.rcParams.update(
        {
            "font.family": "Times New Roman",
            "font.size": 15,
            "axes.labelsize": 15,
            "axes.linewidth": 0.75 * PLOT_SCALE,
            "axes.spines.top": True,
            "axes.spines.right": True,
            "axes.grid": True,
            "axes.axisbelow": True,
            "xtick.labelsize": 15,
            "ytick.labelsize": 15,
            "xtick.major.width": 0.8 * PLOT_SCALE,
            "ytick.major.width": 0.8 * PLOT_SCALE,
            "xtick.major.size": 6.0 * PLOT_SCALE,
            "ytick.major.size": 6.0 * PLOT_SCALE,
            "xtick.direction": "out",
            "ytick.direction": "out",
            "grid.linewidth": 0.9 * PLOT_SCALE,
            "grid.linestyle": "--",
            "grid.alpha": 0.4,
            "legend.fontsize": 15,
            "figure.dpi": 150,
            "savefig.dpi": 300,
        }
    )
    return plt


def _save_figure(fig, path: Path) -> None:
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight", facecolor="white")
    # Keep a vector PDF beside every PNG for publication-quality export.
    if path.suffix.lower() == ".png":
        pdf_path = path.with_suffix(".pdf")
        try:
            fig.savefig(pdf_path, format="pdf", bbox_inches="tight", facecolor="white")
        except PermissionError:
            # Word/Acrobat may lock an embedded PDF on Windows. Preserve the
            # updated plot under a deterministic fallback name instead of
            # aborting the entire report after its CSVs were written.
            fallback = path.with_name(f"{path.stem}_updated.pdf")
            fig.savefig(fallback, format="pdf", bbox_inches="tight", facecolor="white")
            print(f"Warning: {pdf_path} is locked; wrote {fallback} instead.")
    fig.clear()


def plot_cumulative_tokens(results: Iterable[SessionResult], output_dir: Path) -> Path:
    rows = _ordered(results)
    plt = _pyplot()
    fig, ax = plt.subplots(figsize=(6.4, 3.8))
    for method in REPORT_METHODS:
        group = [row for row in rows if row.method == method]
        if not group:
            continue
        cumulative: list[int] = []
        running = 0
        for row in group:
            running += row.overall_tokens
            cumulative.append(running)
        ax.plot(
            range(1, len(group) + 1),
            cumulative,
            marker=METHOD_MARKERS[method],
            markersize=5.0,
            linestyle=METHOD_LINESTYLES[method],
            linewidth=1.5,
            label=method,
            color=METHOD_COLORS[method],
        )
    ax.set_xlabel("Completed task count")
    ax.set_ylabel("Cumulative tokens")
    ax.set_xlim(0.5, 30.5)
    ax.set_xticks((5, 10, 15, 20, 25, 30))
    totals = [sum(row.overall_tokens for row in rows if row.method == method)
              for method in REPORT_METHODS
              if any(row.method == method for row in rows)]
    if totals and max(totals) / min(totals) >= 8:
        ax.set_yscale("log")
        # Label the lower cumulative-token range as well as the final totals.
        # Using the smallest individual task cost prevents early curve points
        # from sitting beside unlabeled grid lines.
        lower = min(row.overall_tokens for row in rows) * 0.7
        upper = max(totals) * 1.4
        ax.set_ylim(lower, upper)
        _clean_log_ticks(ax.yaxis, lower, upper)
    ax.set_ylabel("Cumulative tokens")
    ax.legend()
    ax.grid(True, axis="both")
    path = output_dir / "cumulative_tokens.png"
    _save_figure(fig, path)
    plt.close(fig)
    return path


def plot_token_breakdown(results: Iterable[SessionResult], output_dir: Path) -> Path:
    summary_by_method = {item.method: item for item in summarize(results)}
    # Keep the original methods together and place the newly added cooperative
    # baseline at the far right in Figure 3-9(b).
    breakdown_order = (
        "Baseline-2", "Baseline-3", "Single-Agent-GPT-5.1", "Proposed-2",
        "Proposed-5", "AdvancedShelLM"
    )
    summaries = tuple(
        summary_by_method[method]
        for method in breakdown_order
        if method in summary_by_method
    )
    plt = _pyplot()
    fig, ax = plt.subplots(figsize=(8.2, 4.2))
    labels = [item.method for item in summaries]
    interaction = [item.interaction_tokens for item in summaries]
    supervision = [item.supervision_tokens for item in summaries]
    # Keep the original two-category visual definition.  AdvancedShelLM's
    # Manager supervision and Proposed-5's cross-tier orchestration remain
    # separately available in summary.csv, but both are cooperative overhead
    # in the publication figure.
    coordination = [
        item.supervision_tokens + item.coordination_tokens for item in summaries
    ]
    positions = range(len(labels))
    ax.bar(positions, interaction, width=0.58, color="#1f77b4", label="Interaction")
    ax.bar(
        positions, coordination, width=0.58, bottom=interaction,
        color="#2ca02c", label="Coordination",
    )
    totals = [
        interaction_tokens + coordination_tokens
        for interaction_tokens, coordination_tokens in zip(interaction, coordination)
    ]
    label_offset = max(totals) * 0.018
    for position, total in zip(positions, totals):
        ax.text(
            position,
            total + label_offset,
            f"{total:,}",
            ha="center",
            va="bottom",
            fontsize=11,
            fontname="Times New Roman",
        )
    ax.set_xticks(list(positions), [_display_label(label) for label in labels])
    ax.tick_params(axis="x", labelsize=12)
    use_log_scale = max(totals) / min(totals) >= 8
    if use_log_scale:
        ax.set_yscale("log")
        ax.set_ylim(min(totals) * 0.72, max(totals) * 1.35)
        _clean_log_ticks(ax.yaxis, min(totals) * 0.72, max(totals) * 1.35)
    else:
        ax.set_ylim(0, max(totals) * 1.12)
    ax.set_ylabel("Total tokens")
    ax.legend()
    ax.grid(True, axis="both")
    path = output_dir / "token_breakdown.png"
    _save_figure(fig, path)
    plt.close(fig)
    return path


def _plot_token_cost_tradeoff(
    labels: list[str],
    average_tokens: list[float],
    performance: list[float],
    ylabel: str,
    path: Path,
    annotate_values: bool = True,
) -> Path:
    """Draw the resource/performance trade-off without collapsing it to a ratio."""

    plt = _pyplot()
    fig, ax = plt.subplots(figsize=(7, 5))
    annotation_offsets = {
        "Baseline-2": (12, 8),
        "Baseline-3": (12, -23),
        "Single-Agent-GPT-5.1": (12, 8),
        "AdvancedShelLM": (-12, 8),
        "Proposed-2": (12, 8),
        "Proposed-5": (-12, 8),
    }
    for label, tokens, value in zip(labels, average_tokens, performance):
        ax.scatter(
            tokens,
            value,
            s=150,
            marker=METHOD_MARKERS[label],
            color=ATTACK_DEPTH_COLORS[label],
            edgecolor=ATTACK_DEPTH_EDGE_COLOR,
            linewidth=1.4,
            zorder=3,
        )
        dx, dy = annotation_offsets[label]
        annotation = f"{label} ({value:.2f})" if annotate_values else label
        ax.annotate(
            annotation,
            xy=(tokens, value),
            xytext=(dx, dy),
            textcoords="offset points",
            ha="right" if dx < 0 else "left",
            va="bottom" if dy > 0 else "top",
            fontsize=13,
            fontname="Times New Roman",
        )
    token_ratio = max(average_tokens) / min(average_tokens)
    x_padding = (max(average_tokens) - min(average_tokens)) * 0.12
    y_padding = (max(performance) - min(performance)) * 0.22
    if token_ratio >= 8:
        ax.set_xscale("log")
        ax.set_xlim(min(average_tokens) * 0.78, max(average_tokens) * 1.28)
        _clean_log_ticks(
            ax.xaxis,
            min(average_tokens) * 0.78,
            max(average_tokens) * 1.28,
        )
    else:
        ax.set_xlim(min(average_tokens) - x_padding, max(average_tokens) + x_padding)
    ax.set_ylim(min(performance) - y_padding, max(performance) + y_padding)
    ax.set_xlabel("Average tokens per task")
    ax.set_ylabel(ylabel)
    for spine in ax.spines.values():
        spine.set_color(ATTACK_DEPTH_EDGE_COLOR)
        spine.set_linewidth(2.0)
    ax.tick_params(
        axis="both", which="both", direction="out", width=2.0, length=7
    )
    ax.tick_params(axis="y", which="major", width=2.2, length=10)
    ax.grid(True, axis="both", linestyle="--", alpha=0.3)
    _save_figure(fig, path)
    plt.close(fig)
    return path


def plot_token_cost_vs_attack_depth(
    results: Iterable[SessionResult], output_dir: Path
) -> Path:
    """Plot per-task token cost against average completed attack stages."""

    summaries = summarize(results)
    return _plot_token_cost_tradeoff(
        [item.method for item in summaries],
        [item.average_overall_tokens for item in summaries],
        [item.average_attack_depth for item in summaries],
        "Average attack depth",
        output_dir / "token_cost_vs_attack_depth.png",
        annotate_values=False,
    )


def plot_token_cost_vs_estimated_interaction_duration(
    results: Iterable[SessionResult], output_dir: Path
) -> Path:
    """Plot token cost against round-derived estimated interaction duration."""

    summaries = summarize(results)
    return _plot_token_cost_tradeoff(
        [item.method for item in summaries],
        [item.average_overall_tokens for item in summaries],
        [
            item.average_session_rounds * SESSION_MINUTES_PER_ROUND
            for item in summaries
        ],
        "Estimated interaction duration (min)",
        output_dir / "token_cost_vs_estimated_interaction_duration.png",
        annotate_values=False,
    )


def plot_average_attack_depth(results: Iterable[SessionResult], output_dir: Path) -> Path:
    summaries = summarize(results)
    plt = _pyplot()
    fig, ax = plt.subplots(figsize=(10.5, 5))
    labels: list[str] = []
    means: list[float] = []
    ci95: list[float] = []

    baseline1_path = output_dir / "baseline1_session.csv"
    if baseline1_path.exists():
        with baseline1_path.open(encoding="utf-8-sig", newline="") as handle:
            baseline1_rows = list(csv.DictReader(handle))
        baseline1_depths = [float(row["attack_depth"]) for row in baseline1_rows]
        if len(baseline1_depths) != 30:
            raise ValueError("Baseline-1 replay must contain exactly 30 sessions")
        labels.append("Baseline-1")
        means.append(mean(baseline1_depths))
        baseline1_std = stdev(baseline1_depths)
        ci95.append(1.96 * baseline1_std / (len(baseline1_depths) ** 0.5))

    labels.extend(item.method for item in summaries)
    means.extend(item.average_attack_depth for item in summaries)
    ci95.extend(
        1.96 * item.attack_depth_std / (item.sessions ** 0.5)
        if item.sessions > 1 else 0.0
        for item in summaries
    )
    positions = range(len(labels))
    bars = ax.bar(
        positions, means, width=0.36,
        color=[ATTACK_DEPTH_COLORS[label] for label in labels],
        edgecolor=ATTACK_DEPTH_EDGE_COLOR,
        linewidth=1.2,
        yerr=ci95,
        capsize=4,
        error_kw={
            "ecolor": ATTACK_DEPTH_EDGE_COLOR,
            "elinewidth": 1.1,
            "capthick": 1.1,
        },
    )
    for bar, label in zip(bars, labels):
        bar.set_hatch(ATTACK_DEPTH_PATTERNS[label])
    for position, value, error in zip(positions, means, ci95):
        ax.text(
            position,
            value + error + 0.06,
            f"{value:.2f}",
            ha="center",
            va="bottom",
            fontsize=13,
            fontname="Times New Roman",
        )
    ax.set_xticks(list(positions), [_display_label(label) for label in labels])
    ax.set_xlim(-0.5, len(labels) - 0.5)
    ax.set_ylim(0, 4.25)
    ax.set_yticks((0, 1, 2, 3, 4))
    ax.set_ylabel(
        "Completed attack stages",
        fontsize=20,
        fontname="Times New Roman",
    )
    for spine in ax.spines.values():
        spine.set_color(ATTACK_DEPTH_EDGE_COLOR)
        spine.set_linewidth(2.0)
    ax.tick_params(
        axis="both", which="both", direction="out", width=2.0, length=7,
        labelsize=15,
    )
    ax.tick_params(axis="y", which="major", width=2.2, length=10)
    for tick_label in (*ax.get_xticklabels(), *ax.get_yticklabels()):
        tick_label.set_fontname("Times New Roman")
    ax.grid(True, axis="y", linestyle="--", alpha=0.3)
    ax.grid(False, axis="x")
    path = output_dir / "average_attack_depth.png"
    _save_figure(fig, path)
    plt.close(fig)
    return path


def plot_estimated_interaction_duration(
    results: Iterable[SessionResult], output_dir: Path
) -> Path:
    """Plot the round-derived interaction estimate, not measured dwell time."""

    rows = _ordered(results)
    summaries = summarize(rows)
    plt = _pyplot()
    fig, ax = plt.subplots(figsize=(10.5, 5))
    labels: list[str] = []
    means: list[float] = []
    ci95: list[float] = []

    baseline1_path = output_dir / "baseline1_session.csv"
    if baseline1_path.exists():
        with baseline1_path.open(encoding="utf-8-sig", newline="") as handle:
            baseline1_rows = list(csv.DictReader(handle))
        baseline1_rounds = [float(row["session_rounds"]) for row in baseline1_rows]
        if len(baseline1_rounds) != 30:
            raise ValueError("Baseline-1 replay must contain exactly 30 sessions")
        labels.append("Baseline-1")
        means.append(mean(baseline1_rounds) * SESSION_MINUTES_PER_ROUND)
        ci95.append(
            1.96 * stdev(baseline1_rounds)
            / (len(baseline1_rounds) ** 0.5)
            * SESSION_MINUTES_PER_ROUND
        )

    labels.extend(item.method for item in summaries)
    means.extend(
        item.average_session_rounds * SESSION_MINUTES_PER_ROUND
        for item in summaries
    )
    ci95.extend(
        1.96
        * stdev(row.session_rounds for row in rows if row.method == item.method)
        / (item.sessions ** 0.5)
        * SESSION_MINUTES_PER_ROUND
        if item.sessions > 1 else 0.0
        for item in summaries
    )

    positions = range(len(labels))
    bars = ax.bar(
        positions, means, width=0.36,
        color=[ATTACK_DEPTH_COLORS[label] for label in labels],
        edgecolor=ATTACK_DEPTH_EDGE_COLOR,
        linewidth=1.2,
        yerr=ci95,
        capsize=4,
        error_kw={
            "ecolor": ATTACK_DEPTH_EDGE_COLOR,
            "elinewidth": 1.1,
            "capthick": 1.1,
        },
    )
    for bar, label in zip(bars, labels):
        bar.set_hatch(ATTACK_DEPTH_PATTERNS[label])
    for position, value, error in zip(positions, means, ci95):
        ax.text(
            position, value + error + 0.12, f"{value:.2f}",
            ha="center", va="bottom", fontsize=13,
            fontname="Times New Roman",
        )
    ax.set_xticks(list(positions), [_display_label(label) for label in labels])
    ax.set_xlim(-0.5, len(labels) - 0.5)
    ax.set_ylim(0, 12.5)
    ax.set_yticks((0, 2.5, 5.0, 7.5, 10.0, 12.5))
    ax.set_ylabel("Estimated interaction duration (min)")
    for spine in ax.spines.values():
        spine.set_color(ATTACK_DEPTH_EDGE_COLOR)
        spine.set_linewidth(2.0)
    ax.tick_params(
        axis="both", which="both", direction="out", width=2.0, length=7
    )
    ax.tick_params(axis="y", which="major", width=2.2, length=10)
    ax.grid(True, axis="y", linestyle="--", alpha=0.3)
    ax.grid(False, axis="x")
    path = output_dir / "estimated_interaction_duration.png"
    _save_figure(fig, path)
    plt.close(fig)
    return path


def report(results: Iterable[SessionResult], output_dir: Path = OUTPUT_DIR) -> tuple[Path, ...]:
    """Generate the complete Phase-4 artifact set."""

    rows = _ordered(results)
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_paths = write_csv_reports(rows, output_dir)
    figure_paths = (
        plot_cumulative_tokens(rows, output_dir),
        plot_token_breakdown(rows, output_dir),
        plot_average_attack_depth(rows, output_dir),
        plot_estimated_interaction_duration(rows, output_dir),
        plot_token_cost_vs_attack_depth(rows, output_dir),
        plot_token_cost_vs_estimated_interaction_duration(rows, output_dir),
    )
    return (*csv_paths, *figure_paths)
