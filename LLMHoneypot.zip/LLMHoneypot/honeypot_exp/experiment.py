"""Core execution and evaluation for the paired honeypot experiment."""

from __future__ import annotations

from dataclasses import dataclass
import re
import shlex
from typing import Callable, Mapping, Sequence

from config import (
    BASELINE_MODEL_NAME,
    COORDINATION_PROMPT,
    EDGE_MODEL_NAME,
    HONEYPOT_SYSTEM_PROMPT,
    METHODS,
    PROPOSED_MODEL_NAME,
    STRATEGY_ATOM_FILE,
    STRATEGY_MAX_TOKENS,
    STRATEGY_SYSTEM_PROMPT,
    STRATEGY_TOP_K,
)
from model import ChatResult, Message, chat
from strategy_retrieval import AtomIndex, RetrievalResult
from tasks import AttackStep, AttackTask


ChatFunction = Callable[..., ChatResult]
INTERACTION_VALIDATION_ATTEMPTS = 3

METHOD_MODELS = {
    "Baseline-2": BASELINE_MODEL_NAME,
    "Baseline-3": "deepseek-v4-flash",
    "Single-Agent-GPT-5.1": "AdvancedShelLM-GPT-5.1",
    "AdvancedShelLM": "AdvancedShelLM-GPT-5.1",
    "Proposed-2": PROPOSED_MODEL_NAME,
    "Proposed-5": PROPOSED_MODEL_NAME,
}

_SHELL_PROGRAMS = {
    "cat", "curl", "docker", "find", "grep", "ip", "mosquitto_pub",
    "head", "mosquitto_sub", "mysql", "nc", "nmap", "ssh", "sudo", "uname",
}
_AI_EXPOSURE_MARKERS = (
    "as an ai", "language model", "i cannot assist", "i can't assist",
    "honeypot", "simulated response", "i cannot execute", "i can't execute",
)


@dataclass(frozen=True)
class TurnResult:
    task_id: str
    method: str
    round_number: int
    stage: str
    tier: str
    command: str
    response: str
    command_valid: bool
    ai_exposure: bool
    evidence_matched: tuple[str, ...]
    success: bool
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    latency_ms: float = 0.0
    worker_calls: int = 1
    manager_calls: int = 0
    reprompt_count: int = 0
    worker_prompt_tokens: int = 0
    worker_completion_tokens: int = 0
    worker_tokens: int = 0
    manager_prompt_tokens: int = 0
    manager_completion_tokens: int = 0
    manager_tokens: int = 0
    response_scope_issues: tuple[str, ...] = ()


@dataclass(frozen=True)
class SessionResult:
    task_id: str
    method: str
    model_name: str
    attack_depth: int
    session_rounds: int
    completed: bool
    termination_reason: str
    interaction_prompt_tokens: int
    interaction_completion_tokens: int
    interaction_tokens: int
    coordination_prompt_tokens: int
    coordination_completion_tokens: int
    coordination_tokens: int
    overall_tokens: int
    strategy: str | None
    turns: tuple[TurnResult, ...]
    wall_clock_ms: float = 0.0
    supervision_prompt_tokens: int = 0
    supervision_completion_tokens: int = 0
    supervision_tokens: int = 0
    setup_prompt_tokens: int = 0
    setup_completion_tokens: int = 0
    setup_tokens: int = 0
    retrieved_atom_ids: tuple[str, ...] = ()
    retrieval_scores: tuple[float, ...] = ()
    retrieval_compute_ms: float = 0.0
    knowledge_base_atoms: int = 0
    knowledge_base_version: str | None = None
    knowledge_base_sha256: str | None = None
    retrieved_content_sha256: str | None = None
    coordination_model_name: str | None = None
    strategy_validation_errors: tuple[str, ...] = ()
    strategy_invalid_response: str | None = None
    run_config_sha256: str | None = None

    def __post_init__(self) -> None:
        # Baseline-3 is an archived DeepSeek run reused for reporting only; it
        # is intentionally absent from METHODS so the CLI never calls it.
        if self.method not in (*METHODS, "Baseline-3"):
            raise ValueError(f"unknown method: {self.method}")
        if self.session_rounds != len(self.turns):
            raise ValueError("session_rounds must equal the number of turns")
        if self.overall_tokens != (
            self.interaction_tokens
            + self.supervision_tokens
            + self.coordination_tokens
        ):
            raise ValueError("overall token accounting is inconsistent")
        if self.method != "Proposed-5" and self.coordination_tokens != 0:
            raise ValueError("only Proposed-5 may consume coordination tokens")
        if self.method != "Proposed-5" and self.retrieved_atom_ids:
            raise ValueError("only Proposed-5 may record retrieved strategy atoms")
        if len(self.retrieved_atom_ids) != len(self.retrieval_scores):
            raise ValueError("retrieved atom IDs and scores must have equal length")


def is_valid_shell_command(command: str) -> bool:
    """Conservatively validate syntax without ever executing the command."""

    if not command or len(command) > 1000 or any(char in command for char in "\x00\r\n"):
        return False
    try:
        lexer = shlex.shlex(command, posix=True, punctuation_chars=";&|")
        lexer.whitespace_split = True
        lexer.commenters = ""
        tokens = list(lexer)
    except ValueError:
        return False
    if not tokens:
        return False

    expecting_executable = True
    index = 0
    while index < len(tokens):
        token = tokens[index]
        if token in {";", "&&", "|"}:
            if expecting_executable:
                return False
            expecting_executable = True
            index += 1
            continue
        if expecting_executable:
            executable = token
            if executable == "sudo":
                nested_index = index + 1
                while nested_index < len(tokens) and tokens[nested_index].startswith("-"):
                    nested_index += 1
                # `sudo -l` and similar inspection commands are complete
                # without a nested executable.
                if nested_index < len(tokens) and tokens[nested_index] not in {";", "&&", "|"}:
                    executable = tokens[nested_index]
                    index = nested_index
            if executable not in _SHELL_PROGRAMS:
                return False
            expecting_executable = False
        index += 1
    return not expecting_executable


def detects_ai_exposure(response: str) -> bool:
    lowered = response.casefold()
    return any(marker in lowered for marker in _AI_EXPOSURE_MARKERS)


def validate_command_response_scope(command: str, response: str) -> tuple[str, ...]:
    """Validate command semantics without consulting evaluator evidence labels."""

    issues: list[str] = []
    stripped = response.strip()
    if not stripped:
        issues.append("response is empty")

    # Failure-looking decoy text ("403 forbidden", "command not found", a
    # structured {"error": ...}) is legitimate honeypot output, not a refusal to
    # engage, so it is intentionally not treated as a scope violation here.
    # Only structural plausibility (roots, ports) is enforced below.

    try:
        tokens = shlex.split(command)
    except ValueError:
        return tuple((*issues, "command cannot be parsed for response validation"))

    if "find" in tokens:
        find_index = tokens.index("find")
        roots: list[str] = []
        for token in tokens[find_index + 1:]:
            if token.startswith("-") or token in {"(", ")", "2>/dev/null"}:
                break
            if token.startswith("/"):
                roots.append(token.rstrip("/") or "/")
        paths = [line.strip().split()[0] for line in stripped.splitlines()
                 if line.strip().startswith("/")]
        if not paths:
            issues.append("find response contains no absolute result paths")
        for path in paths:
            if roots and not any(path == root or path.startswith(root + "/") for root in roots):
                issues.append(f"path outside requested find roots: {path}")
                break

    port_match = re.search(r"(?:^|\s)-p\s+([0-9,\-]+)", command)
    if command.lstrip().startswith("nmap ") and port_match:
        requested = [part for part in port_match.group(1).split(",") if part.isdigit()]
        missing = [
            port for port in requested
            if not (
                re.search(rf"\b{re.escape(port)}\s*/\s*(?:tcp|udp)\b", stripped, re.IGNORECASE)
                or re.search(rf"\b(?:on\s+)?port\s+{re.escape(port)}\b", stripped, re.IGNORECASE)
            )
        ]
        if missing:
            issues.append("nmap response omits requested ports: " + ",".join(missing))
    return tuple(dict.fromkeys(issues))


def _matched_evidence(response: str, step: AttackStep) -> tuple[str, ...]:
    """Return positive evidence terms present in a generated shell response."""

    lowered = response.casefold()
    return tuple(item for item in step.success_evidence if item.casefold() in lowered)


def _local_context(task: AttackTask, step: AttackStep) -> str:
    # Identical for Proposed-2 and Proposed-5.  No cross-tier observations or
    # strategy atoms are included here, preventing an initial-config confound.
    return (
        f"Local node profile: tier={step.tier}; task_family={task.family}; "
        f"attacker_profile={task.attacker_profile}. Preserve only this node's "
        "conversation state and return realistic command output."
    )


class ExperimentRunner:
    def __init__(
        self,
        chat_function: ChatFunction = chat,
        atom_index: AtomIndex | None = None,
    ) -> None:
        self._chat = chat_function
        self._atom_index = atom_index
        # The ablation pair reuses the exact same observed first response.  The
        # cache stores usage as well as text so each hypothetical method retains
        # comparable per-session cost accounting.
        self._paired_first_turns: dict[
            tuple[str, str], tuple[ChatResult, int, tuple[str, ...]]
        ] = {}

    def seed_paired_first_turn(self, result: SessionResult) -> None:
        """Restore the paired observation from a validated checkpoint result."""

        if result.method not in {"Proposed-2", "Proposed-5"} or not result.turns:
            return
        turn = result.turns[0]
        key = (result.task_id, result.model_name)
        restored = (
            ChatResult(
                content=turn.response,
                prompt_tokens=turn.prompt_tokens,
                completion_tokens=turn.completion_tokens,
                total_tokens=turn.total_tokens,
                model=result.model_name,
                provider="checkpoint",
                latency_ms=turn.latency_ms,
            ),
            turn.reprompt_count,
            turn.response_scope_issues,
        )
        existing = self._paired_first_turns.get(key)
        if existing is not None and (
            existing[0].content != restored[0].content
            or existing[0].total_tokens != restored[0].total_tokens
        ):
            raise ValueError(
                f"checkpoint contains conflicting paired first turns for {result.task_id}"
            )
        self._paired_first_turns[key] = restored

    def _generate_interaction(
        self,
        messages: Sequence[Message],
        model_name: str,
        command: str,
    ) -> tuple[ChatResult, int, tuple[str, ...]]:
        working_messages = [dict(message) for message in messages]
        prompt_tokens = completion_tokens = total_tokens = 0
        latency_ms = 0.0
        last: ChatResult | None = None
        reprompts = 0
        final_issues: tuple[str, ...] = ()
        for attempt in range(INTERACTION_VALIDATION_ATTEMPTS):
            result = self._chat(working_messages, model_name)
            last = result
            prompt_tokens += result.prompt_tokens
            completion_tokens += result.completion_tokens
            total_tokens += result.total_tokens
            latency_ms += result.latency_ms
            issues = validate_command_response_scope(command, result.content)
            final_issues = issues
            if not issues:
                break
            if attempt + 1 < INTERACTION_VALIDATION_ATTEMPTS:
                reprompts += 1
                working_messages.extend((
                    {"role": "assistant", "content": result.content},
                    {
                        "role": "user",
                        "content": (
                            "The preceding simulated command output violates the command "
                            "scope: " + "; ".join(issues) + ". Regenerate only corrected "
                            "stdout/stderr. Keep all data fictional, sustain the deception "
                            "interaction, and obey the original command exactly."
                        ),
                    },
                ))
        assert last is not None
        return (
            ChatResult(
                content=last.content,
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=total_tokens,
                model=last.model,
                provider=last.provider,
                latency_ms=latency_ms,
            ),
            reprompts,
            final_issues,
        )

    def retrieve_strategy_atoms(
        self,
        task: AttackTask,
        observed_step: AttackStep,
        observed_response: str,
    ) -> RetrievalResult:
        if self._atom_index is None:
            self._atom_index = AtomIndex(STRATEGY_ATOM_FILE)
        # Causal retrieval: only the already observed first interaction is
        # available.  Future commands and evaluator success labels are excluded.
        threat_summary = " ".join(
            (
                task.family,
                task.attacker_profile,
                observed_step.stage,
                observed_step.command,
                observed_response,
            )
        )
        return self._atom_index.retrieve(
            threat_summary=threat_summary,
            attack_stage=observed_step.stage,
            source_tier=observed_step.tier,
            target_tiers=list(task.target_tiers),
            top_k=STRATEGY_TOP_K,
        )

    def generate_strategy(
        self,
        task: AttackTask,
        observed_step: AttackStep,
        observed_response: str,
    ) -> tuple[ChatResult, RetrievalResult]:
        retrieval = self.retrieve_strategy_atoms(task, observed_step, observed_response)
        if retrieval.atoms:
            retrieved_context = "\n".join(
                f"- [{atom['atom_id']}] {atom['attack_type']}/{atom['category']}: {atom['content']}"
                for atom in retrieval.atoms
            )
        else:
            retrieved_context = "(no strategy atoms retrieved)"
        route = " -> ".join(step.tier for step in task.steps)
        chain = "\n".join(
            f"{index}. {step.stage} at {step.tier}: {step.command}"
            for index, step in enumerate(task.steps, start=1)
        )
        messages = [
            {"role": "system", "content": STRATEGY_SYSTEM_PROMPT},
            {
                "role": "user",
                "content": (
                    f"Task {task.task_id}; family={task.family}; route={route}.\n"
                    f"Attack chain:\n{chain}\n"
                    f"Retrieved strategy atoms (use only when applicable):\n"
                    f"{retrieved_context}"
                ),
            },
        ]
        result = self._chat(
            messages,
            EDGE_MODEL_NAME,
            max_tokens=STRATEGY_MAX_TOKENS,
        )
        return result, retrieval

    def run(self, task: AttackTask, method: str) -> SessionResult:
        if method not in METHOD_MODELS:
            raise ValueError(f"method must be one of {', '.join(METHODS)}")
        model_name = METHOD_MODELS[method]
        if method == "Single-Agent-GPT-5.1":
            return self._run_single_agent(task)
        if method == "AdvancedShelLM":
            return self._run_advanced_shellm(task)
        strategy_result: ChatResult | None = None
        retrieval_result: RetrievalResult | None = None
        # Each tier represents a separate node.  Local history is not silently
        # shared across nodes; Proposed-5 coordinates them only via strategy.
        node_histories: dict[str, list[dict[str, str]]] = {}
        turns: list[TurnResult] = []
        interaction_prompt = 0
        interaction_completion = 0
        interaction_total = 0
        wall_clock_ms = 0.0
        attack_depth = 0
        termination_reason = "completed"

        for round_number, step in enumerate(task.steps, start=1):
            command_valid = is_valid_shell_command(step.command)
            if not command_valid:
                termination_reason = "invalid_attack_command"
                break

            history = node_histories.setdefault(step.tier, [])
            messages: list[dict[str, str]] = [
                {"role": "system", "content": HONEYPOT_SYSTEM_PROMPT},
                {"role": "system", "content": _local_context(task, step)},
            ]
            if strategy_result is not None:
                messages.append(
                    {
                        "role": "system",
                        "content": COORDINATION_PROMPT.format(strategy=strategy_result.content),
                    }
                )
            messages.extend(history)
            messages.append({"role": "user", "content": step.command})
            first_turn_key = (task.task_id, model_name)
            if method in {"Proposed-2", "Proposed-5"} and round_number == 1:
                cached = self._paired_first_turns.get(first_turn_key)
                if cached is None:
                    cached = self._generate_interaction(messages, model_name, step.command)
                    self._paired_first_turns[first_turn_key] = cached
                response, reprompt_count, response_scope_issues = cached
            else:
                response, reprompt_count, response_scope_issues = self._generate_interaction(
                    messages, model_name, step.command
                )
            interaction_prompt += response.prompt_tokens
            interaction_completion += response.completion_tokens
            interaction_total += response.total_tokens
            wall_clock_ms += response.latency_ms

            exposed = detects_ai_exposure(response.content)
            evidence = _matched_evidence(response.content, step)
            success = (
                command_valid
                and not response_scope_issues
                and not exposed
                and len(evidence) >= step.required_evidence_count
            )
            turns.append(
                TurnResult(
                    task_id=task.task_id,
                    method=method,
                    round_number=round_number,
                    stage=step.stage,
                    tier=step.tier,
                    command=step.command,
                    response=response.content,
                    command_valid=command_valid,
                    ai_exposure=exposed,
                    evidence_matched=evidence,
                    success=success,
                    prompt_tokens=response.prompt_tokens,
                    completion_tokens=response.completion_tokens,
                    total_tokens=response.total_tokens,
                    latency_ms=response.latency_ms,
                    reprompt_count=reprompt_count,
                    response_scope_issues=response_scope_issues,
                )
            )
            history.extend(
                [
                    {"role": "user", "content": step.command},
                    {"role": "assistant", "content": response.content},
                ]
            )
            if not success:
                if response_scope_issues:
                    termination_reason = "response_scope_validation_failed"
                else:
                    termination_reason = "ai_exposure" if exposed else "missing_stage_evidence"
                break
            attack_depth = round_number
            # Proposed-5 observes exactly the same first interaction as
            # Proposed-2.  Only after it succeeds may the edge LLM retrieve and
            # orchestrate a shared strategy for later rounds.
            if method == "Proposed-5" and round_number == 1:
                strategy_result, retrieval_result = self.generate_strategy(
                    task, step, response.content
                )
                wall_clock_ms += strategy_result.latency_ms

        coordination_prompt = strategy_result.prompt_tokens if strategy_result else 0
        coordination_completion = strategy_result.completion_tokens if strategy_result else 0
        coordination_total = strategy_result.total_tokens if strategy_result else 0
        return SessionResult(
            task_id=task.task_id,
            method=method,
            model_name=model_name,
            attack_depth=attack_depth,
            session_rounds=len(turns),
            completed=attack_depth == len(task.steps),
            termination_reason=termination_reason,
            interaction_prompt_tokens=interaction_prompt,
            interaction_completion_tokens=interaction_completion,
            interaction_tokens=interaction_total,
            coordination_prompt_tokens=coordination_prompt,
            coordination_completion_tokens=coordination_completion,
            coordination_tokens=coordination_total,
            overall_tokens=interaction_total + coordination_total,
            strategy=(strategy_result.content or None) if strategy_result else None,
            turns=tuple(turns),
            wall_clock_ms=wall_clock_ms,
            retrieved_atom_ids=(
                tuple(str(atom["atom_id"]) for atom in retrieval_result.atoms)
                if retrieval_result else ()
            ),
            retrieval_scores=(
                tuple(float(atom["score"]) for atom in retrieval_result.atoms)
                if retrieval_result else ()
            ),
            retrieval_compute_ms=(retrieval_result.compute_ms if retrieval_result else 0.0),
            knowledge_base_atoms=(
                retrieval_result.knowledge_base_atoms if retrieval_result else 0
            ),
            knowledge_base_version=(
                retrieval_result.knowledge_base_version if retrieval_result else None
            ),
            knowledge_base_sha256=(
                retrieval_result.knowledge_base_sha256 if retrieval_result else None
            ),
            retrieved_content_sha256=(
                retrieval_result.retrieved_content_sha256
                if retrieval_result else None
            ),
            coordination_model_name=(EDGE_MODEL_NAME if strategy_result else None),
        )

    def _run_single_agent(self, task: AttackTask) -> SessionResult:
        """Run the AdvancedShelLM Worker unchanged, with Manager removed."""

        from advanced_shellm_adapter import SingleAgentShelLMSession

        session = SingleAgentShelLMSession(self._chat, task)
        turns: list[TurnResult] = []
        prompt_tokens = completion_tokens = total_tokens = 0
        wall_clock_ms = 0.0
        attack_depth = 0
        termination_reason = "completed"
        method = "Single-Agent-GPT-5.1"
        for round_number, step in enumerate(task.steps, start=1):
            command_valid = is_valid_shell_command(step.command)
            if not command_valid:
                termination_reason = "invalid_attack_command"
                break
            response = session.turn(step.tier, step.command)
            prompt_tokens += response.worker_prompt_tokens
            completion_tokens += response.worker_completion_tokens
            total_tokens += response.worker_tokens
            wall_clock_ms += response.latency_ms
            exposed = detects_ai_exposure(response.content)
            evidence = _matched_evidence(response.content, step)
            success = (
                command_valid
                and not exposed
                and len(evidence) >= step.required_evidence_count
            )
            turns.append(
                TurnResult(
                    task_id=task.task_id,
                    method=method,
                    round_number=round_number,
                    stage=step.stage,
                    tier=step.tier,
                    command=step.command,
                    response=response.content,
                    command_valid=command_valid,
                    ai_exposure=exposed,
                    evidence_matched=evidence,
                    success=success,
                    prompt_tokens=response.worker_prompt_tokens,
                    completion_tokens=response.worker_completion_tokens,
                    total_tokens=response.worker_tokens,
                    latency_ms=response.latency_ms,
                    worker_calls=1,
                    worker_prompt_tokens=response.worker_prompt_tokens,
                    worker_completion_tokens=response.worker_completion_tokens,
                    worker_tokens=response.worker_tokens,
                )
            )
            if not success:
                termination_reason = "ai_exposure" if exposed else "missing_stage_evidence"
                break
            attack_depth = round_number
        return SessionResult(
            task_id=task.task_id,
            method=method,
            model_name=METHOD_MODELS[method],
            attack_depth=attack_depth,
            session_rounds=len(turns),
            completed=attack_depth == len(task.steps),
            termination_reason=termination_reason,
            interaction_prompt_tokens=prompt_tokens,
            interaction_completion_tokens=completion_tokens,
            interaction_tokens=total_tokens,
            coordination_prompt_tokens=0,
            coordination_completion_tokens=0,
            coordination_tokens=0,
            overall_tokens=total_tokens,
            strategy=None,
            turns=tuple(turns),
            wall_clock_ms=wall_clock_ms,
        )

    def _run_advanced_shellm(self, task: AttackTask) -> SessionResult:
        """Run the unchanged Manager–Worker architecture on the shared task suite."""

        from advanced_shellm_adapter import AdvancedShelLMSession

        session = AdvancedShelLMSession(self._chat, task)
        turns: list[TurnResult] = []
        worker_prompt = worker_completion = worker_total = 0
        manager_prompt = manager_completion = manager_total = 0
        wall_clock_ms = 0.0
        attack_depth = 0
        termination_reason = "completed"
        for round_number, step in enumerate(task.steps, start=1):
            command_valid = is_valid_shell_command(step.command)
            if not command_valid:
                termination_reason = "invalid_attack_command"
                break
            response = session.turn(step.tier, step.command)
            worker_prompt += response.worker_prompt_tokens
            worker_completion += response.worker_completion_tokens
            worker_total += response.worker_tokens
            manager_prompt += response.manager_prompt_tokens
            manager_completion += response.manager_completion_tokens
            manager_total += response.manager_tokens
            wall_clock_ms += response.latency_ms
            exposed = detects_ai_exposure(response.content)
            evidence = _matched_evidence(response.content, step)
            success = (
                command_valid
                and not exposed
                and len(evidence) >= step.required_evidence_count
            )
            turns.append(
                TurnResult(
                    task_id=task.task_id,
                    method="AdvancedShelLM",
                    round_number=round_number,
                    stage=step.stage,
                    tier=step.tier,
                    command=step.command,
                    response=response.content,
                    command_valid=command_valid,
                    ai_exposure=exposed,
                    evidence_matched=evidence,
                    success=success,
                    prompt_tokens=(
                        response.worker_prompt_tokens + response.manager_prompt_tokens
                    ),
                    completion_tokens=(
                        response.worker_completion_tokens
                        + response.manager_completion_tokens
                    ),
                    total_tokens=response.worker_tokens + response.manager_tokens,
                    latency_ms=response.latency_ms,
                    worker_calls=response.worker_calls,
                    manager_calls=response.manager_calls,
                    reprompt_count=response.reprompts,
                    worker_prompt_tokens=response.worker_prompt_tokens,
                    worker_completion_tokens=response.worker_completion_tokens,
                    worker_tokens=response.worker_tokens,
                    manager_prompt_tokens=response.manager_prompt_tokens,
                    manager_completion_tokens=response.manager_completion_tokens,
                    manager_tokens=response.manager_tokens,
                )
            )
            if not success:
                termination_reason = "ai_exposure" if exposed else "missing_stage_evidence"
                break
            attack_depth = round_number
        return SessionResult(
            task_id=task.task_id,
            method="AdvancedShelLM",
            model_name=METHOD_MODELS["AdvancedShelLM"],
            attack_depth=attack_depth,
            session_rounds=len(turns),
            completed=attack_depth == len(task.steps),
            termination_reason=termination_reason,
            interaction_prompt_tokens=worker_prompt,
            interaction_completion_tokens=worker_completion,
            interaction_tokens=worker_total,
            coordination_prompt_tokens=0,
            coordination_completion_tokens=0,
            coordination_tokens=0,
            overall_tokens=worker_total + manager_total,
            strategy=None,
            turns=tuple(turns),
            wall_clock_ms=wall_clock_ms,
            supervision_prompt_tokens=manager_prompt,
            supervision_completion_tokens=manager_completion,
            supervision_tokens=manager_total,
        )


def run(task: AttackTask, method: str) -> SessionResult:
    """Public execution-plan interface using the configured model client."""

    return ExperimentRunner().run(task, method)


def experiment_smoke_test() -> Mapping[str, SessionResult]:
    """Exercise all Phase-3 branches with a deterministic fake model."""

    from tasks import generate_tasks

    assert not validate_command_response_scope(
        "find /home -type f -name '*.conf' -o -name '*.key'",
        "/home/deploy/app.conf\n/home/deploy/deploy.key",
    )
    # A honeypot may return files that do not match the requested -name globs;
    # only the requested root directory is enforced.
    assert not validate_command_response_scope(
        "find /home -type f -name '*.conf' -o -name '*.key'",
        "/home/deploy/.ssh/id_rsa\n/home/deploy/.ssh/config",
    )
    assert validate_command_response_scope(
        "find /home -type f -name '*.conf' -o -name '*.key'",
        "/var/lib/space/creds/config.json",
    )
    # Failure-looking decoy responses (403, structured errors) are legitimate
    # honeypot output, not scope violations.
    assert not validate_command_response_scope(
        "curl -ks https://192.0.2.10/backup/.env",
        '{"error":"403 Forbidden"}',
    )
    assert not validate_command_response_scope(
        "nmap -sV -p 22,80,443 192.0.2.10",
        "22/tcp open ssh\n80/tcp open http\n443/tcp open https",
    )
    assert not validate_command_response_scope(
        "nmap -sV -p 22,80,443 192.0.2.10",
        "OpenSSH on port 22\nHTTP on port 80\nHTTPS on port 443",
    )
    assert validate_command_response_scope(
        "nmap -sV -p 22,80,443 192.0.2.10",
        "22/tcp open ssh\n443/tcp open https",
    )
    assert not validate_command_response_scope(
        "docker inspect telemetry-agent",
        '[{"State":{"Status":"running","Error":""}}]',
    )

    calls: list[tuple[str, Sequence[Message]]] = []

    strategy_options: list[dict[str, object]] = []

    def fake_chat(
        messages: Sequence[Message],
        model_name: str,
        **options: object,
    ) -> ChatResult:
        calls.append((model_name, messages))
        last = messages[-1]["content"]
        if "--- WORKER DRAFT RESPONSE ---" in last:
            content = "APPROVED"
        elif last.startswith("Task "):
            strategy_options.append(options)
            content = (
                "HOSTS: ground=10.20.1.10; space=10.40.3.32. "
                "SERVICES: 22/tcp=OpenSSH; 80/tcp=http. "
                "CREDENTIALS: deploy=vehicle123. "
                "FILES: /home/deploy/.ssh/id_rsa. "
                "PIVOTS: 10.40.3.32:22."
            )
        elif last.startswith("nmap"):
            content = (
                "22/tcp open ssh OpenSSH_8.9p1\n"
                "80/tcp open http Apache\n443/tcp open https Apache"
            )
        elif last.startswith("find"):
            content = "/home/deploy/app.conf\n/home/deploy/.ssh/id_rsa.key"
        elif last.startswith("sudo"):
            content = "User deploy may run sudo /usr/bin/find as root\n/root/.ssh/config"
        else:
            content = "Last login: Mon Jul 20 09:14:00 from 10.20.1.32\nPassword:"
        return ChatResult(content, 10, 5, 15, model_name, "fake")

    task = generate_tasks(count=1)[0]
    runner = ExperimentRunner(fake_chat)
    results = {method: runner.run(task, method) for method in METHODS}
    assert all(result.attack_depth == 4 for result in results.values()), {
        method: (result.attack_depth, result.termination_reason)
        for method, result in results.items()
    }
    assert results["Proposed-2"].model_name == results["Proposed-5"].model_name
    assert results["Proposed-2"].coordination_tokens == 0
    assert results["Proposed-5"].coordination_tokens == 15
    assert results["Proposed-5"].overall_tokens == 75
    assert len(results["Proposed-5"].retrieved_atom_ids) == STRATEGY_TOP_K
    # Baseline-2: 4; Single-Agent: 4; AdvancedShelLM: 4 Worker + 4 Manager;
    # Proposed-2: 4; Proposed-5 reuses the paired first turn, then makes one
    # strategy call plus three later interactions.
    assert len(calls) == 24
    assert strategy_options == [{"max_tokens": STRATEGY_MAX_TOKENS}]
    assert all(model == BASELINE_MODEL_NAME for model, _ in calls[:4])
    # Both ablation and full architecture call the exact same Worker profile.
    assert all(model == "AdvancedShelLM-GPT-5.1" for model, _ in calls[4:16])
    advanced_worker_calls = [calls[index] for index in (8, 10, 12, 14)]
    assert [messages for _, messages in calls[4:8]] == [
        messages for _, messages in advanced_worker_calls
    ]
    assert all(model == PROPOSED_MODEL_NAME for model, _ in calls[16:20])
    assert calls[20][0] == EDGE_MODEL_NAME
    assert all(model == PROPOSED_MODEL_NAME for model, _ in calls[21:])
    edge_user_prompt = calls[20][1][-1]["content"]
    assert "Attack chain:" in edge_user_prompt
    assert all(step.command in edge_user_prompt for step in task.steps)
    assert results["Proposed-2"].turns[0].response == results["Proposed-5"].turns[0].response
    assert results["Proposed-2"].turns[0].total_tokens == results["Proposed-5"].turns[0].total_tokens
    proposed_2_calls = calls[16:20]
    proposed_5_later_interactions = calls[21:24]
    for (_, messages_2), (_, messages_5) in zip(
        proposed_2_calls[1:], proposed_5_later_interactions
    ):
        without_coordination = [
            message
            for message in messages_5
            if not message["content"].startswith("Use the shared cross-tier strategy")
        ]
        assert without_coordination == list(messages_2)
    # T01 pivots from ground to space in round four.  Proposed-2's new node
    # receives no ground-node history, proving histories are node-local.
    assert len(proposed_2_calls[3][1]) == 3

    resumed_start = len(calls)
    resumed_runner = ExperimentRunner(fake_chat)
    resumed_runner.seed_paired_first_turn(results["Proposed-2"])
    resumed = resumed_runner.run(task, "Proposed-5")
    assert resumed.turns[0].response == results["Proposed-2"].turns[0].response
    assert calls[resumed_start][0] == EDGE_MODEL_NAME

    def persistent_scope_failure_chat(
        messages: Sequence[Message],
        model_name: str,
        **options: object,
    ) -> ChatResult:
        del messages, options
        return ChatResult("", 10, 5, 15, model_name, "fake")

    scope_failed = ExperimentRunner(persistent_scope_failure_chat).run(
        generate_tasks(count=2)[1], "Proposed-2"
    )
    assert scope_failed.termination_reason == "response_scope_validation_failed"
    assert scope_failed.turns[0].reprompt_count == INTERACTION_VALIDATION_ATTEMPTS - 1
    assert scope_failed.turns[0].response_scope_issues
    assert scope_failed.interaction_tokens == 45
    return results
