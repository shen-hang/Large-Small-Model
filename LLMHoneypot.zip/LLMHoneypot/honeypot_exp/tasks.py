"""Deterministic four-stage attack-task generation.

The task suite is generated without model calls.  Every method receives the
same immutable task instances, enabling paired comparisons across methods.
"""

from __future__ import annotations

from dataclasses import dataclass
import random
from typing import Iterable

from config import ATTACK_STAGES, NETWORK_TIERS, RANDOM_SEED, TASK_COUNT


EVALUATOR_VERSION = "enriched-evidence-threshold"


@dataclass(frozen=True)
class AttackStep:
    stage: str
    tier: str
    command: str
    success_evidence: tuple[str, ...]
    required_evidence_count: int = 2


@dataclass(frozen=True)
class AttackTask:
    task_id: str
    family: str
    entry_tier: str
    target_tiers: tuple[str, ...]
    attacker_profile: str
    deployment_window: str
    steps: tuple[AttackStep, ...]

    def __post_init__(self) -> None:
        stages = tuple(step.stage for step in self.steps)
        if stages != ATTACK_STAGES:
            raise ValueError(f"{self.task_id} has invalid stage order: {stages}")
        if not set(self.target_tiers).issubset(NETWORK_TIERS):
            raise ValueError(f"{self.task_id} contains an unknown network tier")


SCENARIOS = (
    {
        "family": "ssh_credential_pivot",
        "profile": "credential-focused operator",
        "commands": (
            "nmap -sV -p 22,80,443 {host}",
            "find /home -maxdepth 3 -type f -name '*.conf' -o -name '*.key'",
            "sudo -l && sudo find /root -maxdepth 2 -type f 2>/dev/null",
            "ssh -i /home/deploy/.ssh/id_rsa deploy@{pivot}",
        ),
        "evidence": (("OpenSSH", "22/tcp", "http", "Apache"), (".conf", ".key", "id_rsa", "/home/deploy"), ("root", "sudo", "NOPASSWD", "sudoers"), ("Last login", "password", "deploy@", "id_rsa")),
    },
    {
        "family": "web_api_token_pivot",
        "profile": "web application intruder",
        "commands": (
            "curl -ks https://{host}/api/health && curl -ks https://{host}/robots.txt",
            "curl -ks https://{host}/backup/.env",
            "curl -ks -H 'Authorization: Bearer $TOKEN' https://{host}/api/admin/config",
            "curl -ks -H 'Authorization: Bearer $TOKEN' https://{pivot}/telemetry",
        ),
        "evidence": (("status", "Disallow", "User-agent"), ("TOKEN", "DB_", "API_KEY", "PASSWORD"), ("admin", "config", "debug"), ("telemetry", "vehicle", "sensor", "altitude")),
    },
    {
        "family": "container_escape_pivot",
        "profile": "cloud-native exploitation operator",
        "commands": (
            "uname -a; cat /proc/1/cgroup; ip route",
            "find /run /var/run -iname '*token*' -o -name 'config.json' 2>/dev/null",
            "docker ps && docker inspect telemetry-agent",
            "ssh ops@{pivot} -i /run/secrets/ops_key",
        ),
        "evidence": (("Linux", "docker", "x86_64", "cgroup"), ("token", "config", "secrets", "/run"), ("telemetry-agent", "Privileged", "CONTAINER", "IMAGE"), ("ops@", "Last login", "password", "secrets")),
    },
    {
        "family": "database_credential_pivot",
        "profile": "data-exfiltration operator",
        "commands": (
            "nc -zv {host} 22 3306 5432 6379",
            "grep -RniE 'password|secret|dsn' /opt/app /etc 2>/dev/null | head",
            "mysql -h 127.0.0.1 -u telemetry -pvehicle123 -e 'show databases;'",
            "ssh -L 15432:{pivot}:5432 deploy@{pivot} -N -f",
        ),
        "evidence": (("succeeded", "open", "3306", "5432"), ("password", "dsn", "vehicle123", "config.json"), ("Database", "telemetry", "information_schema"), ("Backgrounding", "15432", "deploy@", "5432")),
    },
    {
        "family": "iot_service_pivot",
        "profile": "embedded-service attacker",
        "commands": (
            "nmap -sV -p 1883,5683,8080 {host}",
            "mosquitto_sub -h {host} -t 'vehicle/+/status' -C 3",
            "curl -s http://{host}:8080/debug/config",
            "mosquitto_pub -h {pivot} -t 'drone/control/sync' -m '{{\"mode\":\"diagnostic\"}}'",
        ),
        "evidence": (("mqtt", "http", "1883", "8080"), ("vehicle", "status", "speed", "sensor"), ("debug", "config", "version", "password"), ("drone", "diagnostic", "published")),
    },
    {
        "family": "satellite_management_pivot",
        "profile": "cross-tier infrastructure attacker",
        "commands": (
            "nmap -sV -p 22,443,830 {host}",
            "curl -ks https://{host}/management/export",
            "ssh maint@{host} 'sudo /usr/local/bin/diag --dump-config'",
            "ssh maint@{pivot} 'netconf-console --get-config running'",
        ),
        "evidence": (("netconf", "OpenSSH", "830", "443"), ("management", "export", "acl", "diagpass"), ("sudo", "config", "maint@", "diag"), ("running", "data", "netconf", "maint@")),
    },
)


HOSTS = {
    "ground": ("10.20.1.10", "10.20.1.21", "10.20.1.32"),
    "air": ("10.30.2.10", "10.30.2.21", "10.30.2.32"),
    "space": ("10.40.3.10", "10.40.3.21", "10.40.3.32"),
}


def _tier_route(index: int) -> tuple[str, str, str, str]:
    """Return stage tiers; later stages cross tiers by construction."""

    entry = NETWORK_TIERS[index % len(NETWORK_TIERS)]
    second = NETWORK_TIERS[(index + 1) % len(NETWORK_TIERS)]
    third = second if index % 2 else entry
    destination = NETWORK_TIERS[(index + 2) % len(NETWORK_TIERS)]
    return entry, entry, third, destination


def generate_tasks(count: int = TASK_COUNT, seed: int = RANDOM_SEED) -> tuple[AttackTask, ...]:
    """Generate a reproducible, balanced suite of multi-stage attack chains."""

    if count < 1:
        raise ValueError("count must be positive")
    rng = random.Random(seed)
    tasks: list[AttackTask] = []
    for index in range(count):
        scenario = SCENARIOS[index % len(SCENARIOS)]
        stage_tiers = _tier_route(index)
        hosts = [rng.choice(HOSTS[tier]) for tier in stage_tiers]
        pivot_host = hosts[-1]
        steps = tuple(
            AttackStep(
                stage=stage,
                tier=tier,
                command=command.format(host=host, pivot=pivot_host),
                success_evidence=tuple(evidence),
            )
            for stage, tier, host, command, evidence in zip(
                ATTACK_STAGES,
                stage_tiers,
                hosts,
                scenario["commands"],
                scenario["evidence"],
            )
        )
        task_number = index + 1
        tasks.append(
            AttackTask(
                task_id=f"T{task_number:02d}",
                family=str(scenario["family"]),
                entry_tier=stage_tiers[0],
                target_tiers=tuple(dict.fromkeys(stage_tiers)),
                attacker_profile=str(scenario["profile"]),
                deployment_window=f"day-{((task_number - 1) // 3) + 1:02d}",
                steps=steps,
            )
        )
    return tuple(tasks)


def validate_task_suite(tasks: Iterable[AttackTask], expected_count: int = TASK_COUNT) -> None:
    """Fail fast if task generation would weaken the paired experiment."""

    suite = tuple(tasks)
    if len(suite) != expected_count:
        raise ValueError(f"expected {expected_count} tasks, got {len(suite)}")
    if len({task.task_id for task in suite}) != len(suite):
        raise ValueError("task IDs must be unique")
    if set(task.entry_tier for task in suite) != set(NETWORK_TIERS):
        raise ValueError("all three network tiers must be represented")
    if len({task.family for task in suite}) < len(SCENARIOS):
        raise ValueError("the suite does not cover every attack family")
    if not all(len(task.target_tiers) >= 2 for task in suite):
        raise ValueError("every task must exercise cross-tier movement")
