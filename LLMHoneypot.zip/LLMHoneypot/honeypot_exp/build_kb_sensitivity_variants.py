"""Build deterministic sensitivity variants from the frozen 120-atom KB."""

from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path
import random
from itertools import product

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "strategy_atoms.json"
OUTPUT_ROOT = ROOT / "kb_sensitivity"
SEED = 20260721
VERSION = "sagvn-kb-sensitivity-v3.0.0"
PERTURBATION_COUNT = 30


def payload_bytes(atoms: list[dict[str, object]]) -> bytes:
    return (json.dumps(atoms, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _largest_remainder_quota(counts: Counter[str], total: int) -> dict[str, int]:
    exact = {key: value * total / sum(counts.values()) for key, value in counts.items()}
    quota = {key: int(value) for key, value in exact.items()}
    remaining = total - sum(quota.values())
    # When fractional remainders tie, prefer the larger parent stratum; this
    # minimizes percentage-point distortion (e.g. 4/14 rather than 3/10).
    order = sorted(
        counts,
        key=lambda key: (-(exact[key] - quota[key]), -counts[key], key),
    )
    for key in order[:remaining]:
        quota[key] += 1
    return quota


def _bounded_allocations(
    categories: list[str], capacities: dict[str, int], limits: dict[str, int], total: int
) -> list[dict[str, int]]:
    ranges = [range(min(capacities.get(key, 0), limits[key], total) + 1) for key in categories]
    return [
        dict(zip(categories, values))
        for values in product(*ranges)
        if sum(values) == total
    ]


def choose(atoms: list[dict[str, object]]) -> tuple[set[str], dict[str, object]]:
    """Select 25% while matching attack-type and strategy-role quotas exactly."""

    rng = random.Random(SEED)
    attack_counts = Counter(str(atom["attack_type"]) for atom in atoms)
    category_counts = Counter(str(atom["category"]) for atom in atoms)
    attack_quota = _largest_remainder_quota(attack_counts, PERTURBATION_COUNT)
    category_quota = _largest_remainder_quota(category_counts, PERTURBATION_COUNT)
    attack_types = sorted(attack_counts)
    categories = sorted(category_counts)
    cells: dict[tuple[str, str], list[str]] = {}
    for attack_type in attack_types:
        for category in categories:
            ids = sorted(
                str(atom["atom_id"])
                for atom in atoms
                if atom["attack_type"] == attack_type and atom["category"] == category
            )
            rng.shuffle(ids)
            cells[(attack_type, category)] = ids

    allocation: dict[tuple[str, str], int] = {}

    def solve(row: int, remaining: dict[str, int]) -> bool:
        if row == len(attack_types):
            return all(value == 0 for value in remaining.values())
        attack_type = attack_types[row]
        capacities = {
            category: len(cells[(attack_type, category)]) for category in categories
        }
        candidates = _bounded_allocations(
            categories, capacities, remaining, attack_quota[attack_type]
        )
        rng.shuffle(candidates)
        for candidate in candidates:
            updated = {
                category: remaining[category] - candidate[category]
                for category in categories
            }
            if any(value < 0 for value in updated.values()):
                continue
            rows_left = attack_types[row + 1 :]
            if any(
                updated[category]
                > sum(len(cells[(later, category)]) for later in rows_left)
                for category in categories
            ):
                continue
            for category, value in candidate.items():
                allocation[(attack_type, category)] = value
            if solve(row + 1, updated):
                return True
        return False

    if not solve(0, dict(category_quota)):
        raise RuntimeError("unable to construct balanced attack-type/category perturbation")
    chosen = {
        atom_id
        for cell, count in allocation.items()
        for atom_id in cells[cell][:count]
    }
    if len(chosen) != PERTURBATION_COUNT:
        raise RuntimeError("balanced perturbation must select exactly 30 atoms")
    selected_atoms = [atom for atom in atoms if str(atom["atom_id"]) in chosen]
    audit = {
        "selection_method": "largest-remainder quotas with exact attack-type/category allocation",
        "selected_count": len(chosen),
        "attack_type_quota": dict(sorted(attack_quota.items())),
        "category_quota": dict(sorted(category_quota.items())),
        "selected_attack_type_counts": dict(sorted(Counter(str(a["attack_type"]) for a in selected_atoms).items())),
        "selected_category_counts": dict(sorted(Counter(str(a["category"]) for a in selected_atoms).items())),
    }
    return chosen, audit


def write(condition: str, atoms: list[dict[str, object]], operation: str, affected: list[str], selection_audit: dict[str, object]) -> dict[str, object]:
    directory = OUTPUT_ROOT / condition
    directory.mkdir(parents=True, exist_ok=True)
    payload = payload_bytes(atoms)
    atom_path = directory / "strategy_atoms.json"
    atom_path.write_bytes(payload)
    manifest = {
        "knowledge_base_version": f"{VERSION}-{condition}",
        "frozen_at": "2026-10-13",
        "condition": condition,
        "operation": operation,
        "seed": SEED,
        "parent_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "atom_file": atom_path.name,
        "sha256": hashlib.sha256(payload).hexdigest(),
        "atom_count": len(atoms),
        "attack_type_counts": dict(sorted(Counter(str(a["attack_type"]) for a in atoms).items())),
        "category_counts": dict(sorted(Counter(str(a["category"]) for a in atoms).items())),
        "affected_atom_ids": affected,
        "selection_audit": selection_audit,
        "allowed_tiers": ["ground", "air", "space"],
        "allowed_stages": ["reconnaissance", "sensitive_information_theft", "privilege_escalation", "lateral_movement"],
    }
    (directory / "strategy_atoms_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return manifest


def main() -> int:
    base = json.loads(SOURCE.read_text(encoding="utf-8"))
    if not isinstance(base, list) or len(base) != 120:
        raise ValueError("expected the frozen 120-atom parent knowledge base")
    selected, selection_audit = choose(base)
    ids = sorted(selected)
    manifests = [write("clean", [dict(a) for a in base], "unchanged 120-atom parent", [], selection_audit)]
    manifests.append(write(
        "coverage_drop_25",
        [dict(a) for a in base if str(a["atom_id"]) not in selected],
        "remove 30 atoms using exact attack-type and strategy-role quotas", ids, selection_audit,
    ))
    noisy = [dict(a) for a in base]
    for atom in base:
        if str(atom["atom_id"]) in selected:
            clone = dict(atom)
            clone["atom_id"] = f"noise-{atom['atom_id']}"
            clone["content"] = f"Irrelevant archival note {atom['atom_id']} with no actionable deception strategy."
            noisy.append(clone)
    manifests.append(write(
        "noise_25", noisy,
        "add 30 keyword-overlapping irrelevant atoms using the balanced selection",
        [f"noise-{item}" for item in ids], selection_audit,
    ))
    conflict = []
    for atom in base:
        clone = dict(atom)
        if str(atom["atom_id"]) in selected:
            clone["content"] = (
                f"Contradictory strategy for {atom['attack_type']}: route the decoy to "
                f"unreachable TEST-NET endpoint 192.0.2.254:1 and suppress "
                f"{atom['category']} evidence. Source record {atom['atom_id']}."
            )
        conflict.append(clone)
    manifests.append(write(
        "conflict_25", conflict,
        "replace 30 atom contents using the balanced selection", ids, selection_audit,
    ))
    (OUTPUT_ROOT / "sensitivity_manifest.json").write_text(
        json.dumps({"version": VERSION, "seed": SEED, "conditions": manifests}, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    for item in manifests:
        print(f"{item['condition']}: atoms={item['atom_count']} sha256={item['sha256']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
