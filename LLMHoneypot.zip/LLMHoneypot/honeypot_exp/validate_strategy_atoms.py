"""Offline validation for the frozen strategy-atom knowledge base."""

from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path

from strategy_retrieval import AtomIndex


REQUIRED_FIELDS = {
    "atom_id", "attack_type", "category", "content", "keywords", "tiers", "stages",
    "source", "construction_method", "review_status", "review_version",
}
ALLOWED_CATEGORIES = {"host", "service", "credential", "file", "pivot"}
ALLOWED_ATTACK_TYPES = {
    "brute_force", "data_theft", "vulnerability_exploitation",
    "authorization_bypass", "privilege_escalation", "man_in_the_middle",
    "valid_account_abuse", "tunneling", "backdoor", "log_deletion",
}
ALLOWED_TIERS = {"ground", "air", "space"}
ALLOWED_STAGES = {
    "reconnaissance",
    "sensitive_information_theft",
    "privilege_escalation",
    "lateral_movement",
}
EXPECTED_ATTACK_TYPE_COUNTS = {
    "brute_force": 12,
    "data_theft": 14,
    "vulnerability_exploitation": 14,
    "authorization_bypass": 10,
    "privilege_escalation": 14,
    "man_in_the_middle": 12,
    "valid_account_abuse": 12,
    "tunneling": 10,
    "backdoor": 12,
    "log_deletion": 10,
}


def validate(path: Path) -> AtomIndex:
    index = AtomIndex(path)
    ids: list[str] = []
    normalized_content: list[str] = []
    for position, atom in enumerate(index.atoms, start=1):
        fields = set(atom)
        if fields != REQUIRED_FIELDS:
            raise ValueError(
                f"atom {position} fields mismatch: expected {sorted(REQUIRED_FIELDS)}, "
                f"got {sorted(fields)}"
            )
        atom_id = str(atom["atom_id"])
        ids.append(atom_id)
        if atom["category"] not in ALLOWED_CATEGORIES:
            raise ValueError(f"{atom_id}: invalid category {atom['category']}")
        if atom["attack_type"] not in ALLOWED_ATTACK_TYPES:
            raise ValueError(f"{atom_id}: invalid attack type {atom['attack_type']}")
        if not isinstance(atom["content"], str) or not atom["content"].strip():
            raise ValueError(f"{atom_id}: content must be a non-empty string")
        normalized_content.append(" ".join(atom["content"].casefold().split()))
        for field in ("keywords", "tiers", "stages"):
            if not isinstance(atom[field], list) or not atom[field]:
                raise ValueError(f"{atom_id}: {field} must be a non-empty list")
        if not set(atom["tiers"]).issubset(ALLOWED_TIERS):
            raise ValueError(f"{atom_id}: unknown tier")
        if not set(atom["stages"]).issubset(ALLOWED_STAGES):
            raise ValueError(f"{atom_id}: unknown attack stage")
        source = atom["source"]
        if not isinstance(source, dict) or set(source) != {
            "framework", "technique_id", "technique_name", "url"
        }:
            raise ValueError(f"{atom_id}: source provenance is incomplete")
        if source["framework"] != "MITRE ATT&CK Enterprise":
            raise ValueError(f"{atom_id}: unsupported source framework")
        if not str(source["technique_id"]).startswith("T"):
            raise ValueError(f"{atom_id}: invalid MITRE technique ID")
        if not str(source["url"]).startswith("https://attack.mitre.org/techniques/"):
            raise ValueError(f"{atom_id}: invalid MITRE technique URL")
        if atom["construction_method"] != "manual deception abstraction and semantic role expansion":
            raise ValueError(f"{atom_id}: unexpected construction method")
        if atom["review_status"] not in {"human-review-required", "human-reviewed"}:
            raise ValueError(f"{atom_id}: invalid review status")
        if not isinstance(atom["review_version"], str) or not atom["review_version"]:
            raise ValueError(f"{atom_id}: review_version must be non-empty")
    if len(ids) != len(set(ids)):
        duplicates = [item for item, count in Counter(ids).items() if count > 1]
        raise ValueError(f"duplicate atom IDs: {duplicates}")
    if len(normalized_content) != len(set(normalized_content)):
        raise ValueError("duplicate normalized atom content detected")
    observed_counts = Counter(str(atom["attack_type"]) for atom in index.atoms)
    if observed_counts != Counter(EXPECTED_ATTACK_TYPE_COUNTS):
        raise ValueError(
            "attack-type distribution does not match Table III: "
            f"expected {EXPECTED_ATTACK_TYPE_COUNTS}, got {dict(observed_counts)}"
        )
    return index


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--atom-file",
        type=Path,
        default=Path(__file__).resolve().parent / "strategy_atoms.json",
    )
    args = parser.parse_args()
    index = validate(args.atom_file.resolve())
    categories = Counter(str(atom["category"]) for atom in index.atoms)
    attack_types = Counter(str(atom["attack_type"]) for atom in index.atoms)
    print(f"Knowledge base: {index.path}")
    print(f"Version: {index.version}")
    print(f"SHA-256: {index.sha256}")
    print(f"Atoms: {len(index.atoms)}")
    print("Categories: " + json.dumps(dict(sorted(categories.items()))))
    print("Attack types: " + json.dumps(dict(sorted(attack_types.items()))))
    print("Frozen knowledge-base validation passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
