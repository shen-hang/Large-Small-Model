# 模型部署环境（Proposed-5 延迟相关）

> 用途：论文中报告延迟/时长时必须交代的部署环境。实测延迟（`latency_ms`、`wall_clock_ms`）
> 与本机硬件强相关；「会话时长(min)」列是轮数 × 2.5 的固定估计，与硬件无关。

## 端点模型（Proposed-5 / Fine-Qwen3-8B）

| 项 | 值 |
|---|---|
| 模型 | Fine-Qwen3-8B |
| 服务方式 | vLLM（OpenAI 兼容接口） |
| 端点地址 | `http://10.3.89.105:8000/v1`（无鉴权，thinking 关闭） |
| GPU | 2× NVIDIA GeForce RTX 4090（24 GB / 卡） |
| 驱动 / CUDA | 580.173.02 / CUDA 13.0 |
| 实际占用 | GPU 0 ≈ 18.4 GB（vLLM 进程 `opencood4090/bin/python`），GPU 1 空闲 |
| 运行环境 | Linux（服务器 `10.3.89.105`） |

## 边缘编排（GPT-5.1 Edge）

| 项 | 值 |
|---|---|
| 模型 | gpt-5.1 |
| 提供方 | crazyrouter 云 API |
| 地址 | `https://api.crazyrouter.com/v1` |

## 运行平台（发起实验的机器）

| 项 | 值 |
|---|---|
| Python | 3.11.5 |
| OS | Windows 10（10.0.19045） |
| 检索 | BM25 top-5，本地确定性索引 |

## 延迟口径说明

- `estimated_interaction_duration_min`（= 平均轮数 × 2.5）：**轮数派生估计**，manifest 明确标注
  `"not a measured attacker dwell time"`，与部署硬件无关。
- `latency_ms`（每轮 API 延迟）与 `wall_clock_ms`（每会话墙钟）：**实测值**，受上述
  2× RTX 4090 + vLLM 环境直接影响；论文若报告该值，需同时引用本表硬件配置。
