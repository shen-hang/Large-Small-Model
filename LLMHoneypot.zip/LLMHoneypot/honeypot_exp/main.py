"""Command-line entry point for the supplementary experiment."""

from __future__ import annotations

import argparse
from dataclasses import asdict, replace
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
from typing import Iterable

from config import (
    EDGE_MODEL_NAME,
    ENDPOINT_PROMPT_PROTOCOL,
    HONEYPOT_SYSTEM_PROMPT,
    METHODS,
    MODEL_PROFILES,
    OUTPUT_DIR,
    RANDOM_SEED,
    REAL_OUTPUT_DIR,
    TASK_COUNT,
    STRATEGY_ATOM_FILE,
    STRATEGY_MAX_TOKENS,
    STRATEGY_TOP_K,
    TEMPERATURE,
    TOP_P,
    MAX_TOKENS,
)
from experiment import (
    METHOD_MODELS,
    ExperimentRunner,
    SessionResult,
    TurnResult,
    experiment_smoke_test,
)
from model import smoke_test
from reporter import report
from tasks import EVALUATOR_VERSION, AttackTask, generate_tasks, validate_task_suite


def _print_task(task: AttackTask) -> None:
    route = " -> ".join(step.tier for step in task.steps)
    print(
        f"{task.task_id} | {task.family} | {task.deployment_window} | "
        f"route: {route} | attacker: {task.attacker_profile}"
    )
    for number, step in enumerate(task.steps, start=1):
        evidence = ", ".join(step.success_evidence)
        print(f"  {number}. {step.stage} [{step.tier}]: {step.command}")
        print(f"     expected evidence: {evidence}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="LLM honeypot supplementary experiment")
    parser.add_argument(
        "--tasks-only",
        action="store_true",
        help="generate, validate, and print the fixed attack-task suite",
    )
    parser.add_argument(
        "--smoke-test",
        action="store_true",
        help="test the model interface locally without contacting an API",
    )
    parser.add_argument(
        "--experiment-smoke-test",
        action="store_true",
        help="test all Phase-3 experiment branches without contacting an API",
    )
    parser.add_argument(
        "--reporter-smoke-test",
        action="store_true",
        help="generate Phase-4 CSVs and figures from deterministic offline data",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="validate a real-run configuration without calling any API",
    )
    parser.add_argument(
        "--run",
        action="store_true",
        help="execute the selected real experiment methods using configured APIs",
    )
    parser.add_argument(
        "--methods",
        nargs="+",
        choices=METHODS,
        default=list(METHODS),
        help="methods included in --run/--dry-run (default: all)",
    )
    parser.add_argument(
        "--task-limit",
        type=int,
        default=TASK_COUNT,
        help="number of deterministic tasks to run (1-30)",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=REAL_OUTPUT_DIR,
        help="directory for real results and checkpoint",
    )
    parser.add_argument(
        "--no-resume",
        action="store_true",
        help="ignore an existing checkpoint (fails if it already exists)",
    )
    parser.add_argument("--seed", type=int, default=RANDOM_SEED, help="task generation seed")
    return parser


def _required_profiles(methods: Iterable[str]) -> tuple[tuple[str, dict[str, str]], ...]:
    seen: set[str] = set()
    profiles = []
    for method in methods:
        model_names = [METHOD_MODELS[method]]
        if method == "Proposed-5":
            model_names.append(EDGE_MODEL_NAME)
        for model_name in model_names:
            if model_name not in seen:
                seen.add(model_name)
                profiles.append((model_name, MODEL_PROFILES[model_name]))
    return tuple(profiles)


def _preflight(methods: tuple[str, ...], task_limit: int) -> list[str]:
    if not 1 <= task_limit <= TASK_COUNT:
        raise ValueError(f"--task-limit must be between 1 and {TASK_COUNT}")
    problems: list[str] = []
    print("Real-run preflight (no API calls):")
    print(f"  tasks={task_limit}, methods={', '.join(methods)}")
    per_task_maximum = {
        # Worker and Manager each have their own bounded repair loop.
        "AdvancedShelLM": 24,
        "Single-Agent-GPT-5.1": 4,
        # Every ordinary interaction can require one method-independent repair.
        "Baseline-2": 12,
        "Baseline-3": 12,
        "Proposed-2": 12,
        # Twelve endpoint calls plus three structured-strategy attempts. When the
        # paired ablation is present, its first endpoint result is reused, so
        # this remains a conservative upper bound rather than an underestimate.
        "Proposed-5": 15,
    }
    maximum_calls = task_limit * sum(per_task_maximum[method] for method in methods)
    print(f"  maximum API calls={maximum_calls} (early termination may reduce this)")
    for model_name, profile in _required_profiles(methods):
        provider = str(profile["provider"])
        key_env = str(profile["api_key_env"])
        key_required = provider != "vllm"
        key_present = bool(os.getenv(key_env))
        print(
            f"  {model_name}: provider={provider}, api_model={profile['api_model']}, "
            f"base_url={profile['base_url']}, {key_env}={'set' if key_present else 'missing'}"
        )
        if key_required and not key_present:
            problems.append(f"{key_env} is required for {model_name}")
    if problems:
        print("Preflight failed:")
        for problem in problems:
            print(f"  - {problem}")
    else:
        print("Preflight passed.")
    return problems


def _session_from_dict(data: dict[str, object]) -> SessionResult:
    turn_data = data.pop("turns")
    if not isinstance(turn_data, list):
        raise ValueError("checkpoint turns must be a list")
    turns = []
    for raw_turn in turn_data:
        if not isinstance(raw_turn, dict):
            raise ValueError("checkpoint turn must be an object")
        raw_turn["evidence_matched"] = tuple(raw_turn["evidence_matched"])
        if "response_scope_issues" in raw_turn:
            raw_turn["response_scope_issues"] = tuple(raw_turn["response_scope_issues"])
        turns.append(TurnResult(**raw_turn))
    data["turns"] = tuple(turns)
    if "retrieved_atom_ids" in data:
        data["retrieved_atom_ids"] = tuple(data["retrieved_atom_ids"])
    if "retrieval_scores" in data:
        data["retrieval_scores"] = tuple(data["retrieval_scores"])
    if "strategy_validation_errors" in data:
        data["strategy_validation_errors"] = tuple(data["strategy_validation_errors"])
    return SessionResult(**data)


def _load_checkpoint(
    path: Path, expected_run_config_sha256: str | None = None
) -> dict[tuple[str, str], SessionResult]:
    completed: dict[tuple[str, str], SessionResult] = {}
    if not path.exists():
        return completed
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                result = _session_from_dict(json.loads(line))
            except (json.JSONDecodeError, TypeError, ValueError, KeyError) as exc:
                raise ValueError(f"invalid checkpoint line {line_number}: {exc}") from exc
            key = (result.task_id, result.method)
            if (
                expected_run_config_sha256 is not None
                and result.run_config_sha256 != expected_run_config_sha256
            ):
                observed = result.run_config_sha256 or "legacy/unset"
                raise ValueError(
                    f"checkpoint run hash mismatch on line {line_number}: "
                    f"expected {expected_run_config_sha256}, got {observed}"
                )
            if key in completed:
                raise ValueError(f"duplicate checkpoint result: {key}")
            completed[key] = result
    return completed


def _append_checkpoint(path: Path, result: SessionResult) -> None:
    if not result.run_config_sha256:
        raise ValueError("real-run checkpoint result is missing run_config_sha256")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(asdict(result), ensure_ascii=False) + "\n")
        handle.flush()


def _write_experiment_manifest(
    output_dir: Path,
    tasks: tuple[AttackTask, ...],
    methods: tuple[str, ...],
    seed: int,
) -> tuple[Path, str]:
    """Record a secret-free, machine-readable description of a real run."""

    profiles = {}
    for method in methods:
        model_name = METHOD_MODELS[method]
        profile = MODEL_PROFILES[model_name]
        profiles[method] = {
            "configured_model": model_name,
            "provider": profile["provider"],
            "api_model": profile["api_model"],
            "base_url": profile["base_url"],
            "api_key_environment_variable": profile["api_key_env"],
            "authorization_scheme": profile.get("authorization_scheme", "bearer"),
            "reasoning_effort": profile.get("reasoning_effort"),
            "enable_thinking": profile.get("enable_thinking"),
            "chat_template_kwargs": profile.get("chat_template_kwargs"),
        }
    task_payload = [asdict(task) for task in tasks]
    task_suite_sha256 = hashlib.sha256(
        json.dumps(task_payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    implementation_files = (
        "config.py", "experiment.py", "tasks.py", "strategy_retrieval.py",
        "model.py", "main.py", "reporter.py",
    )
    implementation_sha256 = {
        name: hashlib.sha256((Path(__file__).resolve().parent / name).read_bytes()).hexdigest()
        for name in implementation_files
    }
    run_config = {
        "seed": seed,
        "task_suite_sha256": task_suite_sha256,
        "task_ids": [task.task_id for task in tasks],
        "methods": list(methods),
        "model_profiles": profiles,
        "edge_orchestrator": (
            {
                "configured_model": EDGE_MODEL_NAME,
                "provider": MODEL_PROFILES[EDGE_MODEL_NAME]["provider"],
                "api_model": MODEL_PROFILES[EDGE_MODEL_NAME]["api_model"],
                "base_url": MODEL_PROFILES[EDGE_MODEL_NAME]["base_url"],
                "authorization_scheme": MODEL_PROFILES[EDGE_MODEL_NAME].get("authorization_scheme", "bearer"),
                "reasoning_effort": MODEL_PROFILES[EDGE_MODEL_NAME].get("reasoning_effort"),
            }
            if "Proposed-5" in methods else None
        ),
        "evaluator_version": EVALUATOR_VERSION,
        "strategy_top_k": STRATEGY_TOP_K,
        "temperature": TEMPERATURE,
        "top_p": TOP_P,
        "max_tokens": MAX_TOKENS,
        "endpoint_prompt_alignment": {
            "protocol": ENDPOINT_PROMPT_PROTOCOL,
            "prompt_sha256": hashlib.sha256(
                HONEYPOT_SYSTEM_PROMPT.encode("utf-8")
            ).hexdigest(),
            "checkpoint_kind": "base",
            "fine_tuned_checkpoint_claimed": False,
        },
        "strategy_max_tokens": STRATEGY_MAX_TOKENS,
        "strategy_atom_sha256": hashlib.sha256(STRATEGY_ATOM_FILE.read_bytes()).hexdigest(),
        "implementation_sha256": implementation_sha256,
        "estimated_interaction_minutes_per_round": 2.5,
    }
    run_config_sha256 = hashlib.sha256(
        json.dumps(run_config, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    manifest = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "seed": seed,
        "task_count": len(tasks),
        "task_ids": [task.task_id for task in tasks],
        "methods": list(methods),
        "run_config_sha256": run_config_sha256,
        "run_config": run_config,
        "task_suite_sha256": task_suite_sha256,
        "model_profiles": profiles,
        "edge_orchestrator": (
            {
                "configured_model": EDGE_MODEL_NAME,
                "provider": MODEL_PROFILES[EDGE_MODEL_NAME]["provider"],
                "api_model": MODEL_PROFILES[EDGE_MODEL_NAME]["api_model"],
                "base_url": MODEL_PROFILES[EDGE_MODEL_NAME]["base_url"],
                "api_key_environment_variable": MODEL_PROFILES[EDGE_MODEL_NAME]["api_key_env"],
            }
            if "Proposed-5" in methods else None
        ),
        "evaluator_version": EVALUATOR_VERSION,
        "endpoint_prompt_alignment": run_config["endpoint_prompt_alignment"],
        "strategy_retrieval": {
            "enabled_for": [method for method in methods if method == "Proposed-5"],
            "atom_file": str(STRATEGY_ATOM_FILE.resolve()),
            "top_k": STRATEGY_TOP_K,
            "atom_file_sha256": hashlib.sha256(
                STRATEGY_ATOM_FILE.read_bytes()
            ).hexdigest(),
            "implementation": "shared deterministic BM25 index used by MCP and runner",
        },
        "stage_success_rule": (
            "at least required_evidence_count of the step's positive evidence "
            "terms must be present"
        ),
        "estimated_interaction_duration_policy": {
            "kind": "round-derived estimate",
            "minutes_per_round": 2.5,
            "warning": "not a measured attacker dwell time",
        },
        "credentials_recorded": False,
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / "experiment_manifest.json"
    if path.exists():
        existing = json.loads(path.read_text(encoding="utf-8"))
        observed_hash = existing.get("run_config_sha256")
        if observed_hash != run_config_sha256:
            raise RuntimeError(
                "output directory contains a manifest for a different run "
                f"configuration: expected {run_config_sha256}, got "
                f"{observed_hash or 'legacy/unset'}; use a new output directory"
            )
        return path, run_config_sha256
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(manifest, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    return path, run_config_sha256


def _run_real_experiment(
    tasks: tuple[AttackTask, ...],
    methods: tuple[str, ...],
    output_dir: Path,
    resume: bool,
    run_config_sha256: str,
    runner: ExperimentRunner | None = None,
) -> tuple[SessionResult, ...]:
    checkpoint_path = output_dir / "checkpoint.jsonl"
    if not resume and checkpoint_path.exists():
        raise FileExistsError(
            f"{checkpoint_path} already exists; remove/move it or omit --no-resume"
        )
    completed = (
        _load_checkpoint(checkpoint_path, run_config_sha256) if resume else {}
    )
    requested = {(task.task_id, method) for task in tasks for method in methods}
    results = {key: value for key, value in completed.items() if key in requested}
    runner = runner or ExperimentRunner()
    for checkpoint_result in results.values():
        runner.seed_paired_first_turn(checkpoint_result)
    total = len(requested)
    print(f"Starting/resuming real experiment: {len(results)}/{total} sessions complete.")

    for task in tasks:
        for method in methods:
            key = (task.task_id, method)
            if key in results:
                print(f"[{len(results):03d}/{total:03d}] skip {task.task_id} {method}")
                continue
            print(f"[{len(results) + 1:03d}/{total:03d}] run  {task.task_id} {method}")
            result = runner.run(task, method)
            result = replace(result, run_config_sha256=run_config_sha256)
            _append_checkpoint(checkpoint_path, result)
            results[key] = result
            print(
                f"    depth={result.attack_depth}, rounds={result.session_rounds}, "
                f"tokens={result.overall_tokens}, stop={result.termination_reason}"
            )

    ordered = tuple(results[(task.task_id, method)] for task in tasks for method in methods)
    paths = report(ordered, output_dir)
    print("Real experiment complete. Generated:")
    for path in paths:
        print(f"  {path}")
    return ordered


def main() -> int:
    args = build_parser().parse_args()
    selected = sum(
        (
            args.tasks_only,
            args.smoke_test,
            args.experiment_smoke_test,
            args.reporter_smoke_test,
            args.dry_run,
            args.run,
        )
    )
    if selected != 1:
        build_parser().error(
            "choose exactly one of --tasks-only, --smoke-test, "
            "--experiment-smoke-test, --reporter-smoke-test, --dry-run, or --run"
        )

    methods = tuple(args.methods)
    if args.dry_run or args.run:
        try:
            problems = _preflight(methods, args.task_limit)
        except ValueError as exc:
            build_parser().error(str(exc))
        if problems:
            return 2
        if args.dry_run:
            return 0
        tasks = generate_tasks(count=TASK_COUNT, seed=args.seed)[: args.task_limit]
        validate_task_suite(generate_tasks(count=TASK_COUNT, seed=args.seed))
        _, run_config_sha256 = _write_experiment_manifest(
            args.output_dir.resolve(), tasks, methods, args.seed
        )
        _run_real_experiment(
            tasks, methods, args.output_dir.resolve(), not args.no_resume,
            run_config_sha256,
        )
        return 0

    if args.reporter_smoke_test:
        tasks = generate_tasks(count=TASK_COUNT, seed=args.seed)
        synthetic = []
        target_depth = {
            "Baseline-2": 2,
            "Single-Agent-GPT-5.1": 3,
            "AdvancedShelLM": 3,
            "Proposed-2": 3,
            "Proposed-5": 4,
        }
        for method in METHODS:
            for index, task in enumerate(tasks):
                depth = min(4, target_depth[method] + (1 if index % 5 == 0 else 0))
                turns = tuple(
                    TurnResult(
                        task_id=task.task_id, method=method, round_number=number,
                        stage=step.stage, tier=step.tier, command=step.command,
                        response=step.success_evidence[0], command_valid=True,
                        ai_exposure=False, evidence_matched=(step.success_evidence[0],),
                        success=True, prompt_tokens=20, completion_tokens=10,
                        total_tokens=30,
                    )
                    for number, step in enumerate(task.steps[:depth], start=1)
                )
                coordination = 18 if method == "Proposed-5" else 0
                interaction = 30 * depth
                synthetic.append(
                    SessionResult(
                        task_id=task.task_id, method=method,
                        model_name=METHOD_MODELS[method],
                        attack_depth=depth, session_rounds=depth, completed=depth == 4,
                        termination_reason="completed" if depth == 4 else "missing_stage_evidence",
                        interaction_prompt_tokens=20 * depth,
                        interaction_completion_tokens=10 * depth,
                        interaction_tokens=interaction,
                        coordination_prompt_tokens=12 if coordination else 0,
                        coordination_completion_tokens=6 if coordination else 0,
                        coordination_tokens=coordination,
                        overall_tokens=interaction + coordination,
                        strategy="offline shared strategy" if coordination else None,
                        turns=turns,
                    )
                )
        paths = report(synthetic, OUTPUT_DIR / "smoke_test")
        for path in paths:
            print(path)
        print("Reporter smoke test passed.")
        return 0

    if args.experiment_smoke_test:
        results = experiment_smoke_test()
        for method, result in results.items():
            print(
                f"{method}: depth={result.attack_depth}, rounds={result.session_rounds}, "
                f"interaction_tokens={result.interaction_tokens}, "
                f"coordination_tokens={result.coordination_tokens}, "
                f"overall_tokens={result.overall_tokens}"
            )
        print("Experiment smoke test passed.")
        return 0

    if args.smoke_test:
        result = smoke_test()
        print(
            "Model smoke test passed: "
            f"provider={result.provider}, model={result.model}, "
            f"prompt_tokens={result.prompt_tokens}, "
            f"completion_tokens={result.completion_tokens}, "
            f"total_tokens={result.total_tokens}"
        )
        return 0

    tasks = generate_tasks(count=TASK_COUNT, seed=args.seed)
    validate_task_suite(tasks)
    for task in tasks:
        _print_task(task)
    print(f"Generated and validated {len(tasks)} tasks (seed={args.seed}).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
