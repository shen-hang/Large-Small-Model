param(
    [ValidateRange(1, 30)]
    [int]$TaskLimit = 30,
    [ValidateSet("clean", "coverage_drop_25", "noise_25", "conflict_25")]
    [string[]]$Conditions = @(
        "clean", "coverage_drop_25", "noise_25", "conflict_25"
    ),
    [string]$OutputRoot = "outputs\kb_sensitivity"
)

$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot

foreach ($name in @("QWEN_EAS_TOKEN", "QWEN_EAS_BASE_URL", "QWEN_EAS_MODEL")) {
    if (-not (Get-Item -Path "Env:$name" -ErrorAction SilentlyContinue).Value) {
        throw "$name is missing. Open a new PowerShell after setx, or set it in this session."
    }
}
if (-not $env:OPENAI_API_KEY) {
    throw "OPENAI_API_KEY is missing; it is required for GPT-5.1 edge orchestration."
}

$env:QWEN_PROVIDER = "pai-eas"
$env:QWEN_BASE_URL = $env:QWEN_EAS_BASE_URL
$env:QWEN_MODEL_NAME = $env:QWEN_EAS_MODEL
$env:QWEN_API_KEY_ENV = "QWEN_EAS_TOKEN"
$env:QWEN_AUTHORIZATION_SCHEME = "raw"
$env:PROPOSED_MODEL_LABEL = "Qwen3-8B-EAS-Base-PromptAligned"
$env:EDGE_MODEL_LABEL = "GPT-5.1-Edge"
$env:EDGE_PROVIDER = "crazyrouter"
$env:EDGE_BASE_URL = "https://api.crazyrouter.com/v1"
$env:EDGE_MODEL_NAME = "gpt-5.1"
$env:EDGE_API_KEY_ENV = "OPENAI_API_KEY"

python .\build_kb_sensitivity_variants.py
if ($LASTEXITCODE -ne 0) { throw "Knowledge-base variant generation failed." }

foreach ($condition in $Conditions) {
    $env:STRATEGY_ATOM_FILE = Join-Path $PSScriptRoot "kb_sensitivity\$condition\strategy_atoms.json"
    $output = Join-Path $PSScriptRoot "$OutputRoot\$condition"
    New-Item -ItemType Directory -Force -Path $output | Out-Null
    $log = Join-Path $output "run.log"
    Write-Host "Running condition=$condition tasks=$TaskLimit"
    # Native Python writes tracebacks to stderr.  Temporarily keep PowerShell
    # from converting the first stderr line into a terminating RemoteException,
    # so Tee-Object can persist the complete traceback and Python exit code.
    $previousErrorActionPreference = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    python .\main.py --run `
        --methods Proposed-5 `
        --task-limit $TaskLimit `
        --output-dir $output 2>&1 | Tee-Object -FilePath $log
    $pythonExitCode = $LASTEXITCODE
    $ErrorActionPreference = $previousErrorActionPreference
    if ($pythonExitCode -ne 0) {
        throw "Condition $condition failed. Full Python output: $log"
    }
}

Write-Host "Knowledge-base sensitivity runs completed."
