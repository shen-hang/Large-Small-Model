"""Static configuration for the supplementary honeypot experiment.

Proposed-2 and Proposed-5 deliberately share every endpoint-model setting.
They first execute the same observed interaction; only then may Proposed-5
retrieve atoms and load a validated edge-generated coordination strategy.
"""

from __future__ import annotations

from pathlib import Path
import os


PROJECT_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = PROJECT_DIR / "outputs"
REAL_OUTPUT_DIR = OUTPUT_DIR / "real_run_compact_strategy"

TASK_COUNT = 30
RANDOM_SEED = 20260721

METHODS = (
    "Baseline-2",
    "Baseline-3",
    "Single-Agent-GPT-5.1",
    "AdvancedShelLM",
    "Proposed-2",
    "Proposed-5",
)
ATTACK_STAGES = (
    "reconnaissance",
    "sensitive_information_theft",
    "privilege_escalation",
    "lateral_movement",
)
NETWORK_TIERS = ("ground", "air", "space")

# This is an unfine-tuned base checkpoint constrained at inference time with the
# original SFT task instruction.  The label deliberately prevents it from being
# reported as the unavailable fine-tuned checkpoint.
ENDPOINT_PROMPT_PROTOCOL = "linux-terminal-sft-aligned-v1"
PROPOSED_MODEL_NAME = os.getenv(
    "PROPOSED_MODEL_LABEL", "Qwen3-8B-Base-PromptAligned"
)
EDGE_MODEL_NAME = os.getenv("EDGE_MODEL_LABEL", "GPT-5.1-Edge")
# Baseline-2 is the GPT-4o foundation-model baseline used in the paper.
# DeepSeek-V4-Flash is Baseline-3 and must never be selected implicitly under
# the Baseline-2 label.
BASELINE_MODEL_NAME = os.getenv("BASELINE_MODEL_NAME", "gpt-4o")
TEMPERATURE = 0.2
TOP_P = 0.9
MAX_TOKENS = 512
# Compact five-label text strategy; 150 tokens matches the paper's per-round
# coordination budget and the legacy prompt's output ceiling.
STRATEGY_MAX_TOKENS = 150
STRATEGY_TOP_K = int(os.getenv("STRATEGY_TOP_K", "5"))
STRATEGY_ATOM_FILE = Path(os.getenv(
    "STRATEGY_ATOM_FILE", str(PROJECT_DIR / "strategy_atoms.json")
))
REQUEST_TIMEOUT_SECONDS = 60.0

# AdvancedShelLM is deployed as three independent local SSH honeypots (one per
# tier).  The upstream checkout is imported read-only; its source is not edited.
ADVANCED_SHELLM_ROOT = Path(os.getenv(
    "ADVANCED_SHELLM_ROOT",
    str(PROJECT_DIR.parent.parent / "shelLM" / "AdvancedshelLM"),
))
ADVANCED_SHELLM_PERSONALITY = Path(os.getenv(
    "ADVANCED_SHELLM_PERSONALITY",
    str(
        ADVANCED_SHELLM_ROOT
        / "codebase"
        / "LLM_Plugins"
        / "personalities"
        / "baseline.yml"
    ),
))
ADVANCED_SHELLM_WORKER_MODEL = "AdvancedShelLM-GPT-5.1"
ADVANCED_SHELLM_MANAGER_MODEL = "AdvancedShelLM-GPT-5.1"
ADVANCED_SHELLM_MAX_ATTEMPTS = 3
ADVANCED_SHELLM_MAX_TOKENS = 512

# All providers expose OpenAI-compatible /chat/completions endpoints.  Values
# can be overridden without editing code, which keeps experiment manifests
# portable between hosted APIs and a local vLLM deployment.
MODEL_PROFILES = {
    "gpt-4o": {
        "provider": "openai",
        "api_model": os.getenv("OPENAI_MODEL_NAME", "gpt-4o"),
        "base_url": os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1"),
        "api_key_env": "OPENAI_API_KEY",
    },
    "deepseek-v4-flash": {
        "provider": "deepseek",
        "api_model": os.getenv("DEEPSEEK_MODEL_NAME", "deepseek-v4-flash"),
        "base_url": os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com"),
        "api_key_env": "DEEPSEEK_API_KEY",
        # Match Qwen's non-thinking setting and avoid hidden reasoning overhead.
        "thinking": {"type": "disabled"},
    },
    PROPOSED_MODEL_NAME: {
        "provider": os.getenv("QWEN_PROVIDER", "dashscope"),
        "api_model": os.getenv("QWEN_MODEL_NAME", "qwen3-8b"),
        # Honeypot shell emulation and compact coordination mapping do not
        # require hidden chain-of-thought. Disabling it controls cost/variance.
        "enable_thinking": False,
        "base_url": os.getenv(
            "QWEN_BASE_URL",
            "https://llm-1o1wa4mb09e84wgu.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
        ),
        "api_key_env": os.getenv("QWEN_API_KEY_ENV", "DASHSCOPE_API_KEY"),
        # DashScope uses Bearer authentication. PAI-EAS shared gateways expect
        # the service token verbatim in the Authorization header.
        "authorization_scheme": os.getenv(
            "QWEN_AUTHORIZATION_SCHEME", "bearer"
        ),
        # vLLM/SGLang Qwen3 deployments consume this nested field.  Keep the
        # legacy top-level flag above for hosted OpenAI-compatible providers.
        "chat_template_kwargs": {"enable_thinking": False},
    },
    EDGE_MODEL_NAME: {
        "provider": os.getenv("EDGE_PROVIDER", "crazyrouter"),
        "api_model": os.getenv("EDGE_MODEL_NAME", "gpt-5.1"),
        "base_url": os.getenv("EDGE_BASE_URL", "https://api.crazyrouter.com/v1"),
        "api_key_env": os.getenv("EDGE_API_KEY_ENV", "OPENAI_API_KEY"),
        "authorization_scheme": "bearer",
        "reasoning_effort": "none",
    },
    "AdvancedShelLM-GPT-5.1": {
        "provider": "crazyrouter",
        "api_model": os.getenv("ADVANCED_SHELLM_MODEL_NAME", "gpt-5.1"),
        "base_url": os.getenv(
            "ADVANCED_SHELLM_BASE_URL", "https://api.crazyrouter.com/v1"
        ),
        "api_key_env": "OPENAI_API_KEY",
    },
    "vllm-local": {
        "provider": "vllm",
        "api_model": os.getenv("VLLM_MODEL_NAME", "Qwen3-8B"),
        "base_url": os.getenv("VLLM_BASE_URL", "http://127.0.0.1:8000/v1"),
        "api_key_env": "VLLM_API_KEY",
        # vLLM/SGLang Qwen3 defaults to thinking mode; disable it so the
        # endpoint emits direct terminal output instead of a <think> block
        # that leaks reasoning and trips the AI-exposure detector.
        "chat_template_kwargs": {"enable_thinking": False},
    },
}

HONEYPOT_SYSTEM_PROMPT = """You are a low/medium-interaction Linux honeypot.
Return only a plausible response to the attacker's latest command. Maintain
session state, do not reveal that you are an AI or honeypot, and never execute
real commands. Use the supplied node profile and local session history.
"""

# This shared plan is injected only after the first observed interaction.  It is
# never generated from future attack commands or evaluator evidence labels.
COORDINATION_PROMPT = """Use the shared cross-tier strategy below to keep node
identities, credentials, services, paths, and pivot clues mutually consistent.
Do not mention the strategy or the coordinating node in your response.

Shared strategy:
{strategy}
"""

STRATEGY_SYSTEM_PROMPT = """Create a compact cross-tier decoy map for ground,
air, and space nodes. Output at most 150 tokens using only these five labeled
fields: HOSTS, SERVICES, CREDENTIALS, FILES, PIVOTS. Include only concrete
host/IP mappings, service/port mappings, shared decoy credentials, sensitive
file paths, and lateral-movement targets required by the supplied attack chain.
Use semicolon-separated key=value items. No explanation, prose, commands,
reasoning, markdown, or security commentary.
"""


def ensure_output_dir() -> Path:
    """Create and return the directory reserved for later experiment outputs."""

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    return OUTPUT_DIR
