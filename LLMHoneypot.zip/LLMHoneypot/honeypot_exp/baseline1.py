
from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from pathlib import Path
import re

from config import RANDOM_SEED
from tasks import AttackStep, AttackTask, generate_tasks


DEFAULT_SERVICE_DIR = (
    Path(__file__).resolve().parent
    / "third_party"
    / "beelzebub"
    / "configurations"
    / "services"
)


@dataclass(frozen=True)
class StaticService:
    port: int
    protocol: str
    description: str
    server_version: str


@dataclass(frozen=True)
class Baseline1Session:
    task_id: str
    family: str
    attack_depth: int
    session_rounds: int
    termination_reason: str


def _quoted_value(text: str, key: str) -> str:
    match = re.search(rf'(?m)^{re.escape(key)}:\s*"([^"]*)"\s*$', text)
    return match.group(1) if match else ""


def load_static_services(service_dir: Path) -> tuple[StaticService, ...]:
    services: list[StaticService] = []
    for path in sorted(service_dir.glob("*.yaml")):
        text = path.read_text(encoding="utf-8")
        protocol = _quoted_value(text, "protocol")
        address = _quoted_value(text, "address")
        port_match = re.fullmatch(r":(\d+)", address)
        if not protocol or not port_match:
            continue

        # The SSH service on 2222 delegates every command to an LLM.  It is
        # Proposed/Baseline-2 behavior, not part of the static Baseline-1.
        if protocol == "ssh" and "commands:" in text and "plugin: \"LLMHoneypot\"" in text:
            static_handlers = re.findall(r"(?m)^\s+handler:", text)
            if not static_handlers:
                continue

        services.append(
            StaticService(
                port=int(port_match.group(1)),
                protocol=protocol,
                description=_quoted_value(text, "description"),
                server_version=_quoted_value(text, "serverVersion"),
            )
        )
    if not services:
        raise ValueError(f"no static services found in {service_dir}")
    return tuple(services)


def _recon_response(command: str, services: tuple[StaticService, ...]) -> str:
    requested = {int(item) for item in re.findall(r"(?<![\d.])\d{2,5}(?![\d.])", command)}
    available = [service for service in services if service.port in requested]
    if command.startswith("nmap "):
        lines = []
        for service in available:
            name = "http" if service.protocol == "http" else service.protocol
            banner = service.server_version or service.description
            lines.append(f"{service.port}/tcp open {name} {banner}".strip())
        return "\n".join(lines)
    if command.startswith("nc "):
        return "\n".join(
            f"Connection to target {service.port} port [tcp/*] succeeded! open"
            for service in available
        )
    # No HTTPS :443 service is configured, so the API reconnaissance commands
    # receive no useful application response.
    if command.startswith("curl "):
        return ""
    return ""


def _static_shell_response(command: str) -> str:
    exact_handlers = {
        "ls": "Documents Images Desktop Downloads .m2 .kube .ssh .docker",
        "pwd": "/home/",
        "uname -m": "x86_64",
        "docker ps": "CONTAINER ID IMAGE COMMAND CREATED STATUS PORTS NAMES",
        "uname": "Linux",
        "ps": "PID TTY TIME CMD\n21642 ttys000 0:00.07 /bin/dockerd",
    }
    if command in exact_handlers:
        return exact_handlers[command]
    if re.fullmatch(r"docker .*", command):
        return "Error response from daemon: connect: connection refused"
    return "command not found"


def _matched(response: str, step: AttackStep) -> bool:
    lowered = response.casefold()
    matched = sum(item.casefold() in lowered for item in step.success_evidence)
    return matched >= step.required_evidence_count


def replay_task(task: AttackTask, services: tuple[StaticService, ...]) -> Baseline1Session:
    depth = 0
    rounds = 0
    for rounds, step in enumerate(task.steps, start=1):
        response = (
            _recon_response(step.command, services)
            if step.stage == "reconnaissance"
            else _static_shell_response(step.command)
        )
        if not _matched(response, step):
            return Baseline1Session(
                task.task_id, task.family, depth, rounds, "missing_stage_evidence"
            )
        depth = rounds
    return Baseline1Session(task.task_id, task.family, depth, rounds, "completed")


def run_replay(service_dir: Path = DEFAULT_SERVICE_DIR) -> tuple[Baseline1Session, ...]:
    services = load_static_services(service_dir)
    return tuple(replay_task(task, services) for task in generate_tasks(seed=RANDOM_SEED))


def write_results(results: tuple[Baseline1Session, ...], output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=tuple(Baseline1Session.__dataclass_fields__))
        writer.writeheader()
        writer.writerows(result.__dict__ for result in results)


def main() -> int:
    parser = argparse.ArgumentParser(description="Replay static Beelzebub Baseline-1")
    parser.add_argument("--service-dir", type=Path, default=DEFAULT_SERVICE_DIR)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    results = run_replay(args.service_dir)
    write_results(results, args.output)
    average_depth = sum(item.attack_depth for item in results) / len(results)
    average_rounds = sum(item.session_rounds for item in results) / len(results)
    print(f"sessions={len(results)}, mean_depth={average_depth:.3f}, mean_rounds={average_rounds:.3f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
