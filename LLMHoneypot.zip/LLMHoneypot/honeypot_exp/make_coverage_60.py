"""Build the 60-atom mixed-quality KB: 30 high-quality + 30 task-irrelevant atoms.

This is the balanced-quality condition at 60 atoms (50/50 ratio).  It pairs with
coverage_30_10good20poor (10 good + 20 poor) and the coverage_5_* series to sweep
the *quality ratio* while holding sparsity fixed at the chosen KB size.  Here the
good half is two atoms per field is NOT the rule -- it is six atoms per field,
spanning all seven task-relevant families; the poor half is drawn from the three
task-irrelevant families (man-in-the-middle / log-deletion / backdoor).

Field balance note: the parent KB has only five task-irrelevant *pivot* atoms, so
the poor half uses all five pivots and puts the extra atom into *file* (7 file /
5 pivot), keeping the 60-atom total while staying as field-balanced as possible.

Selection is deterministic (explicit atom ids, byte-identical to the frozen
120-atom parent) for reproducibility.
"""

from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "strategy_atoms.json"
OUTPUT_ROOT = ROOT / "kb_sensitivity"
SEED = 20260721
VERSION = "sagvn-kb-sensitivity-v4.0.0"
CONDITION = "coverage_60_30good30poor"

CATEGORIES = ("host", "service", "credential", "file", "pivot")

# Task-relevant families (map onto the six benchmark task families).
GOOD_FAMILIES = {
    "brute_force",
    "data_theft",
    "vulnerability_exploitation",
    "authorization_bypass",
    "privilege_escalation",
    "valid_account_abuse",
    "tunneling",
}
# Task-irrelevant families (never occur in the six benchmark task families).
POOR_FAMILIES = {"man_in_the_middle", "log_deletion", "backdoor"}

# 30 high-quality atoms: six per decoy-map field, spanning all seven
# task-relevant families (each family contributes one -01..-05 per field where
# present, with tunneling/authorization_bypass rotated across fields).
_HIGH_QUALITY_30 = (
    # host (6)
    "data_theft-01",
    "brute_force-01",
    "vulnerability_exploitation-01",
    "privilege_escalation-01",
    "valid_account_abuse-01",
    "authorization_bypass-01",
    # service (6)
    "data_theft-02",
    "brute_force-02",
    "vulnerability_exploitation-02",
    "privilege_escalation-02",
    "valid_account_abuse-02",
    "tunneling-02",
    # credential (6)
    "data_theft-03",
    "brute_force-03",
    "vulnerability_exploitation-03",
    "privilege_escalation-03",
    "valid_account_abuse-03",
    "tunneling-03",
    # file (6)
    "data_theft-04",
    "brute_force-04",
    "vulnerability_exploitation-04",
    "privilege_escalation-04",
    "valid_account_abuse-04",
    "tunneling-04",
    # pivot (6)
    "data_theft-05",
    "brute_force-05",
    "vulnerability_exploitation-05",
    "privilege_escalation-05",
    "valid_account_abuse-05",
    "authorization_bypass-05",
)

# 30 task-irrelevant atoms from the three poor families.  The parent KB has only
# five poor *pivot* atoms, so the poor half is field-balanced as 6 host / 6
# service / 6 credential / 7 file / 5 pivot.
_POOR_30 = (
    # host (6)
    "man_in_the_middle-01",
    "man_in_the_middle-09",
    "log_deletion-01",
    "log_deletion-09",
    "backdoor-01",
    "backdoor-09",
    # service (6)
    "man_in_the_middle-02",
    "man_in_the_middle-06",
    "log_deletion-02",
    "log_deletion-06",
    "backdoor-02",
    "backdoor-06",
    # credential (6)
    "man_in_the_middle-03",
    "man_in_the_middle-07",
    "log_deletion-03",
    "log_deletion-07",
    "backdoor-03",
    "backdoor-07",
    # file (7)
    "man_in_the_middle-04",
    "man_in_the_middle-08",
    "man_in_the_middle-12",
    "log_deletion-04",
    "log_deletion-08",
    "backdoor-04",
    "backdoor-08",
    # pivot (5)
    "man_in_the_middle-05",
    "man_in_the_middle-11",
    "log_deletion-05",
    "backdoor-05",
    "backdoor-11",
)


def _payload(atoms: list[dict[str, object]]) -> bytes:
    return (json.dumps(atoms, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def main() -> int:
    base = json.loads(SOURCE.read_text(encoding="utf-8"))
    if not isinstance(base, list) or len(base) != 120:
        raise ValueError("expected the frozen 120-atom parent knowledge base")
    by_id = {str(a["atom_id"]): a for a in base}

    all_ids = list(_HIGH_QUALITY_30) + list(_POOR_30)
    missing = [i for i in all_ids if i not in by_id]
    if missing:
        raise ValueError(f"atom ids not found in parent KB: {missing}")
    if len(set(all_ids)) != 60:
        raise ValueError("atom id overlap between good and poor lists")

    good = [by_id[i] for i in _HIGH_QUALITY_30]
    poor = [by_id[i] for i in _POOR_30]

    # Guard the intended quality/category structure.
    for a in good:
        assert str(a["attack_type"]) in GOOD_FAMILIES, a["atom_id"]
    for a in poor:
        assert str(a["attack_type"]) in POOR_FAMILIES, a["atom_id"]
    assert Counter(str(a["category"]) for a in good) == Counter(
        {c: 6 for c in CATEGORIES}
    ), Counter(str(a["category"]) for a in good)
    assert Counter(str(a["category"]) for a in poor) == Counter(
        {"host": 6, "service": 6, "credential": 6, "file": 7, "pivot": 5}
    ), Counter(str(a["category"]) for a in poor)

    atoms = good + poor
    directory = OUTPUT_ROOT / CONDITION
    directory.mkdir(parents=True, exist_ok=True)
    payload = _payload(atoms)
    (directory / "strategy_atoms.json").write_bytes(payload)

    manifest = {
        "knowledge_base_version": f"{VERSION}-{CONDITION}",
        "frozen_at": "2026-10-25",
        "condition": CONDITION,
        "operation": "30 high-quality atoms plus 30 task-irrelevant atoms (60 total)",
        "seed": SEED,
        "parent_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "atom_file": "strategy_atoms.json",
        "sha256": hashlib.sha256(payload).hexdigest(),
        "atom_count": len(atoms),
        "attack_type_counts": dict(sorted(Counter(str(a["attack_type"]) for a in atoms).items())),
        "category_counts": dict(sorted(Counter(str(a["category"]) for a in atoms).items())),
        "selection_audit": {
            "selection_method": "explicit atom ids (byte-identical parent copies)",
            "high_quality_atom_ids": list(_HIGH_QUALITY_30),
            "poor_atom_ids": list(_POOR_30),
            "high_quality_families": sorted(GOOD_FAMILIES),
            "poor_families": sorted(POOR_FAMILIES),
            "fields": list(CATEGORIES),
            "good_per_field": 6,
            "poor_field_breakdown": {"host": 6, "service": 6, "credential": 6, "file": 7, "pivot": 5},
            "poor_pivot_note": "parent KB has only 5 task-irrelevant pivot atoms",
        },
        "allowed_tiers": ["ground", "air", "space"],
        "allowed_stages": ["reconnaissance", "sensitive_information_theft", "privilege_escalation", "lateral_movement"],
    }
    (directory / "strategy_atoms_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(f"{CONDITION}: atoms={len(atoms)} sha256={manifest['sha256'][:12]}")
    print(f"  attack_type_counts={manifest['attack_type_counts']}")
    print(f"  category_counts={manifest['category_counts']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
