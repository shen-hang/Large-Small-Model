# `honeypot_exp` 文件地图

先读 [交接文档](HANDOFF_REMAINING_EXPERIMENTS.md)，再按下面的地图找文件。完成剩余实验时，日常使用的入口是 `main.py` 和 `run_kb_sensitivity.ps1`；其余文件大多被入口自动调用。**不要为了“整理”直接修改任务、评价器或知识库**，这些内容会影响已有结果的比较口径。

## 主实验代码

| 文件 | 作用 | 学弟是否需要直接运行/修改 |
|---|---|---|
| `main.py` | 命令行入口；生成固定任务、预检环境、执行方法、续跑 checkpoint、写运行 manifest、调用报告器。 | **运行**；不要在正式实验中途改代码。 |
| `config.py` | 方法名、模型路由、提示词、采样参数、知识库路径等配置；可由环境变量覆盖。 | **核对**模型与端点；通常通过环境变量配置。 |
| `tasks.py` | 固定种子生成 T01–T30，定义四阶段命令和成功证据、失败判定。 | 阅读；正式实验前冻结。 |
| `experiment.py` | Proposed-2/5 与其他方法的会话执行、策略生成和校验、响应范围检查、阶段计分、Token 分项。 | 阅读关键逻辑；运行中不要修改。 |
| `model.py` | OpenAI 兼容 API 请求、鉴权、重试、模型响应与 Token 用量解析；含离线 smoke test。 | 遇到接口故障时检查；不要把真实密钥写进文件。 |
| `reporter.py` | 从 `SessionResult` 生成 `summary.csv`、逐会话/逐轮 CSV 和图 3-8/3-9 所需的指标图。 | 合并最终结果时使用；图表只认最终 checkpoint。 |
| `advanced_shellm_adapter.py` | 将第三方 AdvancedShelLM 的 Worker–Manager 与分节点会话状态接入本基准。 | 旧方法结果已离线重评分；本轮无需重跑。 |
| `baseline1.py` | 静态蜜罐 Baseline-1 的离线回放与 CSV 输出。 | 当前重跑 Proposed 无需调用；涉及 Baseline-1 图表时核对。 |

## 知识库与检索

| 文件/目录 | 作用 | 操作提示 |
|---|---|---|
| `strategy_atoms.json` | 冻结的 clean 知识库，共 120 条策略原子。 | **输入数据**；不要手工编辑。 |
| `strategy_atoms_manifest.json` | clean 知识库版本、数量、分类和 SHA-256。 | 校验依据；随结果一同保存。 |
| `strategy_retrieval.py` | 主实验和 MCP 共用的确定性 BM25/Top-5 检索。 | Proposed-5 会自动调用。 |
| `validate_strategy_atoms.py` | 离线检查原子结构、分布、哈希和检索可用性。 | 正式运行前执行一次。 |
| `build_strategy_atoms_120.py` | 构建最初的 120 条知识库及 manifest。 | **冻结后不要重建**，除非明确开启新实验版本。 |
| `build_kb_sensitivity_variants.py` | 固定种子生成 clean、均衡删减、噪声、冲突四个知识库条件与审计 manifest。 | `run_kb_sensitivity.ps1` 会调用；生成后核对哈希。 |
| `kb_sensitivity/` | 四个条件的 `strategy_atoms.json` 和 manifest；根目录 `sensitivity_manifest.json` 记录扰动选择。 | **实验输入**；不得当作运行结果删除。 |
| `run_kb_sensitivity.ps1` | 逐条件调用 `main.py` 跑 Proposed-5，并保存日志与结果。 | **第二阶段运行入口**；先完成 clean 配对主实验。 |

## 重评分、旧结果与专项测量

| 文件 | 作用 | 当前用途 |
|---|---|---|
| `rescore_checkpoint.py` | 从旧 checkpoint 离线重算阶段成功、终止点和 Token 截断，并写来源哈希与规则。 | 已生成 `legacy_baselines_rescored_final`；只在审计时重跑到新目录。 |
| `benchmark_proposed5_latency.py` | 单任务 Proposed-5 延迟专项探针，写独立输出。 | 可选成本分析；不是攻击深度主实验。 |
| `mcp_rag_server.py` | 对外提供策略原子检索的 MCP HTTP 服务，用于 MCP 开销测量。 | 主实验内部检索不必启动它。 |
| `benchmark_system_overhead.py` | 测量 MCP 检索、边缘 GPT-5.1 编排时延与请求大小。 | 仅专项开销实验；不改变主 checkpoint。 |
| `SYSTEM_OVERHEAD_README.md` | 上述 MCP/边缘开销实验的运行说明。 | 做系统开销复测时阅读。 |
| `requirements_overhead.txt` | 额外的 MCP SDK 依赖。 | 仅运行 MCP 开销探针时安装。 |

## 文档、依赖与诊断脚本

| 文件 | 作用 | 当前用途 |
|---|---|---|
| `HANDOFF_REMAINING_EXPERIMENTS.md` | 剩余实验步骤、完整命令、验收和论文口径。 | **首先阅读**。 |
| `FILE_GUIDE.md` | 本文件：目录和文件职责。 | 找代码时查阅。 |
| `README.md` | 项目总体方法、配置和入口说明。 | 看整体架构；具体后续步骤以交接文档为准。 |
| `PROMPTS.md` | 边缘模型、端侧模型与 RAG 提示词披露。 | 写论文“实验设置”与审计提示词时使用。 |
| `requirements.txt` | 主实验依赖（matplotlib、PyYAML）。 | 新环境安装。 |

## `outputs/` 当前保留的目录

| 目录 | 文件作用 | 使用原则 |
|---|---|---|
| `3-8(9)/` | 仅保留旧 `combined_checkpoint.jsonl` 源数据与 `baseline1_session.csv`。 | 审计来源；旧数值和旧图已移除。 |
| `legacy_baselines_rescored_final/` | `checkpoint.jsonl` 是 90 会话最终旧基线数据；`rescore_manifest.json` 是来源/规则/哈希；`summary.csv`、`session.csv`、`turn.csv` 是汇总、逐会话、逐轮数据；PDF/PNG 为对应图。 | 旧三方法可复用结果；不要覆盖。 |

新实验输出目录由运行命令创建。一个标准目录通常含 `experiment_manifest.json`（参数、任务与代码哈希）、`checkpoint.jsonl`（可续跑的逐会话原始记录）、`summary.csv`（按方法汇总）、`session.csv`（逐任务）、`turn.csv`（逐命令）及 PDF/PNG 图。`run.log` 只用于故障排查。先检查 checkpoint 和 manifest，再引用 CSV/图；图可以重建，checkpoint 与 manifest 必须保留。
