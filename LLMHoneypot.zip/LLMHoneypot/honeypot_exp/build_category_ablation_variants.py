"""Build category-ablation KB variants for the knowledge-base quality-sensitivity study.

Removes one or more ``category`` roles (host/service/credential/file/pivot) in
their entirety.  This is a sharper ablation than removing a single attack_type
role because the BM25 retrieval load is concentrated in the generic host/service
templates, not in the attack-type-specific credential/file/pivot atoms.
"""

from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "strategy_atoms.json"
OUTPUT_ROOT = ROOT / "kb_sensitivity"
SEED = 20260721
VERSION = "sagvn-kb-category-ablation-v1.0.0"
FROZEN_AT = "2026-10-20"

# condition directory name -> category role(s) removed.
ABLATIONS = {
    "ablate_service": ("service",),
    "ablate_service_host": ("service", "host"),
}


def payload_bytes(atoms: list[dict[str, object]]) -> bytes:
    return (json.dumps(atoms, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def write(
    condition: str,
    atoms: list[dict[str, object]],
    removed_categories: tuple[str, ...],
    affected: list[str],
) -> dict[str, object]:
    directory = OUTPUT_ROOT / condition
    directory.mkdir(parents=True, exist_ok=True)
    payload = payload_bytes(atoms)
    atom_path = directory / "strategy_atoms.json"
    atom_path.write_bytes(payload)
    selection_audit = {
        "selection_method": "remove entire category role(s) (deterministic ablation)",
        "removed_categories": sorted(removed_categories),
        "removed_count": len(affected),
    }
    manifest = {
        "knowledge_base_version": f"{VERSION}-{condition}",
        "frozen_at": FROZEN_AT,
        "condition": condition,
        "operation": "remove category role(s): " + ", ".join(sorted(removed_categories)),
        "seed": SEED,
        "parent_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "atom_file": atom_path.name,
        "sha256": hashlib.sha256(payload).hexdigest(),
        "atom_count": len(atoms),
        "attack_type_counts": dict(
            sorted(Counter(str(a["attack_type"]) for a in atoms).items())
        ),
        "category_counts": dict(
            sorted(Counter(str(a["category"]) for a in atoms).items())
        ),
        "affected_atom_ids": affected,
        "selection_audit": selection_audit,
        "allowed_tiers": ["ground", "air", "space"],
        "allowed_stages": [
            "reconnaissance",
            "sensitive_information_theft",
            "privilege_escalation",
            "lateral_movement",
        ],
    }
    (directory / "strategy_atoms_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return manifest


def main() -> int:
    base = json.loads(SOURCE.read_text(encoding="utf-8"))
    if not isinstance(base, list) or len(base) != 120:
        raise ValueError("expected the frozen 120-atom parent knowledge base")

    manifests: list[dict[str, object]] = []
    for condition, removed_categories in ABLATIONS.items():
        removed = set(removed_categories)
        affected = sorted(
            str(a["atom_id"]) for a in base if str(a["category"]) in removed
        )
        kept = [dict(a) for a in base if str(a["category"]) not in removed]
        if not affected:
            raise ValueError(
                f"no atoms matched category {removed_categories} for {condition}"
            )
        manifests.append(write(condition, kept, removed_categories, affected))

    (OUTPUT_ROOT / "category_ablation_manifest.json").write_text(
        json.dumps(
            {"version": VERSION, "seed": SEED, "frozen_at": FROZEN_AT, "conditions": manifests},
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    for item in manifests:
        print(
            f"{item['condition']}: atoms={item['atom_count']} "
            f"removed={item['selection_audit']['removed_count']} sha256={item['sha256']}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
