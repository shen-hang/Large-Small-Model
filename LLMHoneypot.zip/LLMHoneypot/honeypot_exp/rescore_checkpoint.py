"""Re-score stored model responses with the current stage evaluator.

This command performs no API calls.  It truncates each stored session at the
first turn rejected by the current evaluator and recalculates token totals from
the retained prefix.  The source checkpoint is never modified.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict, replace
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

from experiment import (
    SessionResult,
    detects_ai_exposure,
    validate_command_response_scope,
)
from main import _load_checkpoint
from reporter import report
from tasks import (
    EVALUATOR_VERSION,
    generate_tasks,
)


def rescore_session(session: SessionResult) -> SessionResult:
    task = next(task for task in generate_tasks() if task.task_id == session.task_id)
    retained = []
    depth = 0
    termination = "completed"
    for turn, step in zip(session.turns, task.steps):
        evidence = tuple(
            item for item in step.success_evidence
            if item.casefold() in turn.response.casefold()
        )
        scope_issues = validate_command_response_scope(step.command, turn.response)
        exposed = detects_ai_exposure(turn.response)
        success = (
            turn.command_valid
            and not scope_issues
            and not exposed
            and len(evidence) >= step.required_evidence_count
        )
        retained.append(replace(
            turn,
            ai_exposure=exposed,
            evidence_matched=evidence,
            response_scope_issues=scope_issues,
            success=success,
        ))
        if not success:
            if not turn.command_valid:
                termination = "invalid_attack_command"
            elif scope_issues:
                termination = "response_scope_validation_failed"
            elif exposed:
                termination = "ai_exposure"
            else:
                termination = "insufficient_stage_evidence"
            break
        depth += 1

    if session.method == "AdvancedShelLM":
        interaction_prompt = sum(turn.worker_prompt_tokens for turn in retained)
        interaction_completion = sum(turn.worker_completion_tokens for turn in retained)
        interaction_tokens = sum(turn.worker_tokens for turn in retained)
        supervision_prompt = sum(turn.manager_prompt_tokens for turn in retained)
        supervision_completion = sum(turn.manager_completion_tokens for turn in retained)
        supervision_tokens = sum(turn.manager_tokens for turn in retained)
        wall_clock_ms = sum(turn.latency_ms for turn in retained)
    else:
        interaction_prompt = sum(turn.prompt_tokens for turn in retained)
        interaction_completion = sum(turn.completion_tokens for turn in retained)
        interaction_tokens = sum(turn.total_tokens for turn in retained)
        supervision_prompt = supervision_completion = supervision_tokens = 0
        wall_clock_ms = session.wall_clock_ms

    completed = depth == len(task.steps)
    return replace(
        session,
        attack_depth=depth,
        session_rounds=len(retained),
        completed=completed,
        termination_reason="completed" if completed else termination,
        interaction_prompt_tokens=interaction_prompt,
        interaction_completion_tokens=interaction_completion,
        interaction_tokens=interaction_tokens,
        supervision_prompt_tokens=supervision_prompt,
        supervision_completion_tokens=supervision_completion,
        supervision_tokens=supervision_tokens,
        overall_tokens=(
            interaction_tokens + supervision_tokens + session.coordination_tokens
        ),
        turns=tuple(retained),
        wall_clock_ms=wall_clock_ms,
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument(
        "--exclude-methods",
        nargs="*",
        default=[],
        help="method labels to omit, e.g. an obsolete AdvancedShelLM run",
    )
    args = parser.parse_args()
    source = _load_checkpoint(args.input)
    if not source:
        raise ValueError(f"checkpoint contains no sessions: {args.input}")
    excluded = set(args.exclude_methods)
    rescored = tuple(
        rescore_session(row)
        for row in source.values()
        if row.method not in excluded
    )
    if not rescored:
        raise ValueError("all checkpoint sessions were excluded")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    checkpoint = args.output_dir / "checkpoint.jsonl"
    with checkpoint.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rescored:
            handle.write(json.dumps(asdict(row), ensure_ascii=False) + "\n")
    source_sha256 = hashlib.sha256(args.input.read_bytes()).hexdigest()
    script_path = Path(__file__).resolve()
    manifest = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "kind": "offline-rescore-with-token-prefix-truncation",
        "source_checkpoint": str(args.input.resolve()),
        "source_checkpoint_sha256": source_sha256,
        "rescore_script_sha256": hashlib.sha256(script_path.read_bytes()).hexdigest(),
        "evaluator_version": EVALUATOR_VERSION,
        "scope_validator": "validate_command_response_scope",
        "retention_policy": (
            "retain turns through and including the first rejected response; "
            "discard all later turns and their tokens"
        ),
        "included_methods": sorted({row.method for row in rescored}),
        "excluded_methods": sorted(excluded),
        "session_count": len(rescored),
        "api_calls": 0,
    }
    with (args.output_dir / "rescore_manifest.json").open(
        "w", encoding="utf-8", newline="\n"
    ) as handle:
        json.dump(manifest, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    baseline1 = args.input.parent / "baseline1_session.csv"
    if baseline1.is_file():
        shutil.copy2(baseline1, args.output_dir / baseline1.name)
    report(rescored, args.output_dir)
    print(f"Re-scored {len(rescored)} sessions without API calls.")
    print(f"Output: {args.output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
