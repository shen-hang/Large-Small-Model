"""Stateful AdvancedShelLM adapter for the four-stage honeypot benchmark.

This module reuses the upstream ManagerAgent without modifying the shelLM
checkout.  One independent Worker/Manager state is maintained per network
tier; no history or filesystem state is shared between tiers.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import re
import time
from typing import Any, Callable, Mapping, Sequence

import yaml

from config import (
    ADVANCED_SHELLM_MANAGER_MODEL,
    ADVANCED_SHELLM_MAX_ATTEMPTS,
    ADVANCED_SHELLM_MAX_TOKENS,
    ADVANCED_SHELLM_PERSONALITY,
    ADVANCED_SHELLM_ROOT,
    ADVANCED_SHELLM_WORKER_MODEL,
)
from model import ChatResult, Message


ChatFunction = Callable[..., ChatResult]


@dataclass
class NodeState:
    prompt: str
    history: list[dict[str, str]] = field(default_factory=list)


@dataclass(frozen=True)
class AdvancedTurn:
    content: str
    worker_prompt_tokens: int
    worker_completion_tokens: int
    worker_tokens: int
    manager_prompt_tokens: int
    manager_completion_tokens: int
    manager_tokens: int
    worker_calls: int
    manager_calls: int
    reprompts: int
    latency_ms: float


class _ManagerClient:
    """Adapter for the send_chat interface expected by ManagerAgent."""

    def __init__(self, chat_function: ChatFunction, calls: list[ChatResult]) -> None:
        self._chat = chat_function
        self._calls = calls

    def send_chat(self, model: str, messages: Sequence[Message]) -> str:
        result = self._chat(
            messages,
            model,
            max_tokens=ADVANCED_SHELLM_MAX_TOKENS,
            temperature=0.0,
            top_p=1.0,
        )
        self._calls.append(result)
        return result.content


def _load_manager_class():
    path = ADVANCED_SHELLM_ROOT / "codebase" / "LLM_Plugins" / "manager_agent.py"
    if not path.is_file():
        raise FileNotFoundError(f"AdvancedShelLM ManagerAgent not found: {path}")
    spec = importlib.util.spec_from_file_location("benchmark_advanced_shellm_manager", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import ManagerAgent from {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.ManagerAgent


def _load_prompt() -> str:
    with ADVANCED_SHELLM_PERSONALITY.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle)
    try:
        prompt = data["personality"]["prompt"]
    except (KeyError, TypeError) as exc:
        raise ValueError(
            f"personality.prompt is missing from {ADVANCED_SHELLM_PERSONALITY}"
        ) from exc
    if not isinstance(prompt, str) or not prompt.strip():
        raise ValueError("AdvancedShelLM personality prompt is empty")
    return prompt


def _clean(text: str) -> str:
    value = (text or "").split("<|end|>", 1)[0]
    value = re.sub(r"<think>.*?</think>", "", value, flags=re.DOTALL | re.I)
    value = re.sub(r"<analysis>.*?</analysis>", "", value, flags=re.DOTALL | re.I)
    return value.strip()


def _apply_fs_patch(prompt: str, additions: list[str], removals: list[str]) -> str:
    if not additions and not removals:
        return prompt
    removal_set = set(removals)
    lines: list[str] = []
    for line in prompt.splitlines():
        try:
            obj = json.loads(line.strip()) if line.strip().startswith("{") else {}
        except json.JSONDecodeError:
            obj = {}
        if obj.get("p") not in removal_set:
            lines.append(line)

    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    parsed: list[tuple[str, str]] = []
    for entry in additions:
        try:
            obj = json.loads(entry.strip())
        except json.JSONDecodeError:
            continue
        if "p" not in obj or "k" not in obj:
            continue
        obj.setdefault("ctime", now)
        obj.setdefault("mtime", now)
        parsed.append((str(obj["p"]), json.dumps(obj, ensure_ascii=False)))
    replace_paths = {path for path, _ in parsed}
    if replace_paths:
        kept = []
        for line in lines:
            try:
                obj = json.loads(line.strip()) if line.strip().startswith("{") else {}
            except json.JSONDecodeError:
                obj = {}
            if obj.get("p") not in replace_paths:
                kept.append(line)
        lines = kept + [entry for _, entry in parsed]
    return "\n".join(lines)


def _filesystem_entries(prompt: str) -> list[str]:
    entries = []
    for line in prompt.splitlines():
        stripped = line.strip()
        if not stripped.startswith("{"):
            continue
        try:
            obj = json.loads(stripped)
        except json.JSONDecodeError:
            continue
        if "p" in obj and "k" in obj:
            entries.append(stripped)
    return entries


def _build_node_states(task: Any) -> dict[str, NodeState]:
    """Build identical initial Worker state for ablation and full architecture."""

    base = _load_prompt()
    states: dict[str, NodeState] = {}
    for tier in {step.tier for step in task.steps}:
        hosts = sorted(
            {
                token
                for step in task.steps
                if step.tier == tier
                for token in re.findall(
                    r"\b(?:\d{1,3}\.){3}\d{1,3}\b", step.command
                )
            }
        )
        hostname = f"{tier}-{task.task_id.lower()}"
        context = (
            "\n\nBENCHMARK LOCAL NODE CONTEXT:\n"
            f"- hostname: {hostname}\n"
            f"- network tier: {tier}\n"
            f"- task family: {task.family}\n"
            f"- attacker profile: {task.attacker_profile}\n"
            f"- local benchmark addresses: {', '.join(hosts) if hosts else 'unspecified'}\n"
            "- Maintain only this node's local state. Do not assume access to "
            "another tier's conversation, filesystem, route, credentials, or "
            "runtime state. Produce normal command-specific output only.\n"
        )
        states[tier] = NodeState(base.replace("{hostname}", hostname) + context)
    return states


class SingleAgentShelLMSession:
    """AdvancedShelLM Worker-only ablation with no Manager calls or feedback."""

    def __init__(self, chat_function: ChatFunction, task: Any) -> None:
        self._chat = chat_function
        self._states = _build_node_states(task)

    def turn(self, tier: str, command: str) -> AdvancedTurn:
        state = self._states[tier]
        messages = [
            {"role": "system", "content": state.prompt},
            *state.history,
            {"role": "user", "content": command},
        ]
        started = time.perf_counter_ns()
        result = self._chat(
            messages,
            ADVANCED_SHELLM_WORKER_MODEL,
            max_tokens=ADVANCED_SHELLM_MAX_TOKENS,
            temperature=0.0,
            top_p=1.0,
        )
        content = _clean(result.content)
        state.history.extend(
            [
                {"role": "user", "content": command},
                {"role": "assistant", "content": content},
            ]
        )
        return AdvancedTurn(
            content=content,
            worker_prompt_tokens=result.prompt_tokens,
            worker_completion_tokens=result.completion_tokens,
            worker_tokens=result.total_tokens,
            manager_prompt_tokens=0,
            manager_completion_tokens=0,
            manager_tokens=0,
            worker_calls=1,
            manager_calls=0,
            reprompts=0,
            latency_ms=(time.perf_counter_ns() - started) / 1_000_000,
        )


class AdvancedShelLMSession:
    """Manager–Worker session with independent persistent state per tier."""

    def __init__(self, chat_function: ChatFunction, task: Any) -> None:
        self._chat = chat_function
        self._manager_class = _load_manager_class()
        self._states = _build_node_states(task)

    def turn(self, tier: str, command: str) -> AdvancedTurn:
        state = self._states[tier]
        worker_calls: list[ChatResult] = []
        manager_calls: list[ChatResult] = []
        manager_client = _ManagerClient(self._chat, manager_calls)
        manager = self._manager_class(
            manager_client, ADVANCED_SHELLM_MANAGER_MODEL, logger=None
        )
        messages = [
            {"role": "system", "content": state.prompt},
            *state.history,
            {"role": "user", "content": command},
        ]
        started = time.perf_counter_ns()
        result = self._chat(
            messages,
            ADVANCED_SHELLM_WORKER_MODEL,
            max_tokens=ADVANCED_SHELLM_MAX_TOKENS,
            temperature=0.0,
            top_p=1.0,
        )
        worker_calls.append(result)
        draft = _clean(result.content)
        reprompts = 0

        for attempt in range(1, ADVANCED_SHELLM_MAX_ATTEMPTS + 1):
            approved, feedback, additions, removals = manager.review_response(
                command,
                draft,
                state.prompt,
                conversation_history=messages,
            )
            state.prompt = _apply_fs_patch(state.prompt, additions, removals)
            if approved or attempt >= ADVANCED_SHELLM_MAX_ATTEMPTS:
                break
            reprompts += 1
            entries = _filesystem_entries(state.prompt)
            reminder = ""
            if entries:
                reminder = (
                    "FILESYSTEM STATE REMINDER (authoritative):\n"
                    + "\n".join(entries)
                    + "\n\n"
                )
            scratch = messages + [
                {"role": "assistant", "content": draft},
                {
                    "role": "user",
                    "content": (
                        f"{reminder}SUPERVISOR INSTRUCTION: {feedback} "
                        "Rewrite the previous response and output only the corrected "
                        "shell response."
                    ),
                },
            ]
            result = self._chat(
                scratch,
                ADVANCED_SHELLM_WORKER_MODEL,
                max_tokens=ADVANCED_SHELLM_MAX_TOKENS,
                temperature=0.0,
                top_p=1.0,
            )
            worker_calls.append(result)
            draft = _clean(result.content)

        state.history.extend(
            [
                {"role": "user", "content": command},
                {"role": "assistant", "content": draft},
            ]
        )
        return AdvancedTurn(
            content=draft,
            worker_prompt_tokens=sum(call.prompt_tokens for call in worker_calls),
            worker_completion_tokens=sum(call.completion_tokens for call in worker_calls),
            worker_tokens=sum(call.total_tokens for call in worker_calls),
            manager_prompt_tokens=sum(call.prompt_tokens for call in manager_calls),
            manager_completion_tokens=sum(call.completion_tokens for call in manager_calls),
            manager_tokens=sum(call.total_tokens for call in manager_calls),
            worker_calls=len(worker_calls),
            manager_calls=len(manager_calls),
            reprompts=reprompts,
            latency_ms=(time.perf_counter_ns() - started) / 1_000_000,
        )
