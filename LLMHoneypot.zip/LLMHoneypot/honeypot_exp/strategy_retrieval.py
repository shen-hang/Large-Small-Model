"""Deterministic strategy-atom retrieval shared by experiments and MCP."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import re
from time import perf_counter_ns
from typing import Any


TOKEN_PATTERN = re.compile(r"[a-z0-9_.-]+")


def _tokenize(value: str) -> list[str]:
    return TOKEN_PATTERN.findall(value.casefold())


@dataclass(frozen=True)
class RetrievalResult:
    atoms: tuple[dict[str, Any], ...]
    compute_ms: float
    knowledge_base_atoms: int
    knowledge_base_version: str
    knowledge_base_sha256: str
    retrieved_content_sha256: str


class AtomIndex:
    """Small deterministic BM25 index used by both the runner and MCP tool."""

    def __init__(self, path: Path) -> None:
        payload = path.read_bytes()
        raw = json.loads(payload.decode("utf-8"))
        if not isinstance(raw, list):
            raise ValueError("strategy atom file must contain a JSON list")
        self.path = path.resolve()
        self.sha256 = hashlib.sha256(payload).hexdigest()
        self.atoms: list[dict[str, Any]] = raw
        self.version = f"strategy-atoms-{self.sha256[:12]}"
        manifest_path = self.path.with_name("strategy_atoms_manifest.json")
        if manifest_path.is_file():
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            if manifest.get("atom_file") == self.path.name:
                expected_hash = str(manifest.get("sha256", ""))
                if self.sha256 != expected_hash:
                    raise ValueError(
                        "frozen strategy atom SHA-256 mismatch: "
                        f"expected {expected_hash}, got {self.sha256}"
                    )
                expected_count = int(manifest.get("atom_count", -1))
                if len(self.atoms) != expected_count:
                    raise ValueError(
                        "frozen strategy atom count mismatch: "
                        f"expected {expected_count}, got {len(self.atoms)}"
                    )
                observed_categories = Counter(
                    str(atom.get("category", "")) for atom in self.atoms
                )
                expected_categories = Counter(
                    {
                        str(key): int(value)
                        for key, value in manifest.get("category_counts", {}).items()
                    }
                )
                if observed_categories != expected_categories:
                    raise ValueError(
                        "frozen strategy atom category distribution mismatch: "
                        f"expected {dict(expected_categories)}, "
                        f"got {dict(observed_categories)}"
                    )
                if "attack_type_counts" in manifest:
                    observed_attack_types = Counter(
                        str(atom.get("attack_type", "")) for atom in self.atoms
                    )
                    expected_attack_types = Counter(
                        {
                            str(key): int(value)
                            for key, value in manifest["attack_type_counts"].items()
                        }
                    )
                    if observed_attack_types != expected_attack_types:
                        raise ValueError(
                            "frozen strategy atom attack-type distribution mismatch: "
                            f"expected {dict(expected_attack_types)}, "
                            f"got {dict(observed_attack_types)}"
                        )
                self.version = str(manifest["knowledge_base_version"])
        self.documents = [
            _tokenize(
                " ".join(
                    [
                        str(atom["category"]),
                        str(atom["attack_type"]),
                        str(atom["content"]),
                        *map(str, atom["keywords"]),
                        *map(str, atom["tiers"]),
                        *map(str, atom["stages"]),
                    ]
                )
            )
            for atom in self.atoms
        ]
        self.lengths = [len(document) for document in self.documents]
        self.average_length = (sum(self.lengths) / len(self.lengths)) if self.lengths else 1.0
        document_frequency: Counter[str] = Counter()
        for document in self.documents:
            document_frequency.update(set(document))
        self.idf = {
            token: math.log(
                1 + (len(self.documents) - frequency + 0.5) / (frequency + 0.5)
            )
            for token, frequency in document_frequency.items()
        }

    def search(
        self,
        threat_summary: str,
        attack_stage: str,
        source_tier: str,
        target_tiers: list[str],
        top_k: int,
    ) -> list[dict[str, Any]]:
        query_tokens = _tokenize(
            " ".join([threat_summary, attack_stage, source_tier, *target_tiers])
        )
        query_frequency = Counter(query_tokens)
        scored: list[tuple[float, dict[str, Any]]] = []
        k1, b = 1.5, 0.75
        for atom, document, length in zip(self.atoms, self.documents, self.lengths):
            term_frequency = Counter(document)
            score = 0.0
            for token, query_count in query_frequency.items():
                frequency = term_frequency[token]
                if frequency == 0:
                    continue
                denominator = frequency + k1 * (
                    1 - b + b * length / self.average_length
                )
                score += (
                    self.idf.get(token, 0.0)
                    * frequency
                    * (k1 + 1)
                    / denominator
                    * min(query_count, 2)
                )
            tier_overlap = {source_tier, *target_tiers} & set(atom["tiers"])
            if tier_overlap:
                score += 0.25 * len(tier_overlap)
            if attack_stage in atom["stages"]:
                score += 0.35
            scored.append((score, atom))
        scored.sort(key=lambda item: (-item[0], str(item[1]["atom_id"])))
        return [
            {
                "atom_id": atom["atom_id"],
                "attack_type": atom["attack_type"],
                "category": atom["category"],
                "content": atom["content"],
                "score": round(score, 6),
                "tiers": atom["tiers"],
                "stages": atom["stages"],
            }
            for score, atom in scored[:top_k]
        ]

    def retrieve(
        self,
        threat_summary: str,
        attack_stage: str,
        source_tier: str,
        target_tiers: list[str],
        top_k: int,
    ) -> RetrievalResult:
        if not threat_summary.strip():
            raise ValueError("threat_summary must not be empty")
        if source_tier not in {"ground", "air", "space"}:
            raise ValueError("source_tier must be ground, air or space")
        if not set(target_tiers).issubset({"ground", "air", "space"}):
            raise ValueError("target_tiers contains an unknown tier")
        if not 1 <= top_k <= 10:
            raise ValueError("top_k must be between 1 and 10")
        started_ns = perf_counter_ns()
        atoms = self.search(
            threat_summary, attack_stage, source_tier, target_tiers, top_k
        )
        retrieved_payload = json.dumps(
            atoms, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
        return RetrievalResult(
            atoms=tuple(atoms),
            compute_ms=(perf_counter_ns() - started_ns) / 1_000_000,
            knowledge_base_atoms=len(self.atoms),
            knowledge_base_version=self.version,
            knowledge_base_sha256=self.sha256,
            retrieved_content_sha256=hashlib.sha256(retrieved_payload).hexdigest(),
        )
