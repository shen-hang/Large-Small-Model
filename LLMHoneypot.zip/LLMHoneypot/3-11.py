from __future__ import annotations

import csv
import os

import matplotlib.pyplot as plt
import numpy as np

from incentive_common import (
    Config,
    GROUPS,
    generate_trace,
    run_mechanism,
)


MECHANISMS = (
    'Data-quality Incentive',
    'Reputation-Shapley Incentive',
    'Proposed Incentive',
)
DISPLAY_LABELS = (
    'Baseline-4 ',
    'Baseline-5',
    'Proposed-5 ',
)
COLORS = ['#ff7f0e', '#1f77b4', '#2ca02c']


def configure_plot() -> None:
    plt.rcParams.update({
        'font.family': 'serif',
        'font.serif': ['Times New Roman', 'DejaVu Serif'],
        'axes.linewidth': 1.4,
        'xtick.major.width': 1.2,
        'ytick.major.width': 1.2,
        'grid.linewidth': 0.8,
    })


def plot_group_rewards(
    shares: np.ndarray,
    reward_budget: float,
    output_path: str,
) -> None:
    group_rewards = shares * reward_budget
    means = group_rewards.mean(axis=0)
    ci = 1.96 * group_rewards.std(axis=0, ddof=1) / np.sqrt(group_rewards.shape[0])
    x = np.arange(len(GROUPS))
    width = 0.24
    fig, ax = plt.subplots(figsize=(10.5, 5.4))
    for method_id, method in enumerate(DISPLAY_LABELS):
        offset = (method_id - 1) * width
        ax.bar(
            x + offset,
            means[method_id],
            width,
            yerr=ci[method_id],
            capsize=3,
            label=method,
            color=COLORS[method_id],
            alpha=0.88,
        )
    ax.set_ylabel('Average group reward per round', fontsize=18)
    ax.set_xticks(x)
    ax.set_xticklabels(['High-value', 'Novelty', 'Effectiveness', 'Medium-value', 'Low-value', 'Unreliable'], fontsize=15)
    ax.tick_params(axis='y', labelsize=15)
    ax.set_ylim(bottom=0)
    ax.grid(True, axis='y', linestyle='--', alpha=0.4)
    ax.legend(fontsize=13, frameon=True)
    fig.tight_layout()
    fig.savefig(output_path, format='pdf', dpi=600, bbox_inches='tight')
    plt.close(fig)


def plot_metrics(metrics: np.ndarray, output_path: str) -> None:
    metric_labels = ['Invalid reward', 'High-value reward', 'Low-value reward']
    means = metrics.mean(axis=0)
    ci = 1.96 * metrics.std(axis=0, ddof=1) / np.sqrt(metrics.shape[0])
    x = np.arange(len(metric_labels))
    width = 0.24
    fig, ax = plt.subplots(figsize=(9.5, 5.2))
    for method_id, method in enumerate(DISPLAY_LABELS):
        offset = (method_id - 1) * width
        ax.bar(
            x + offset,
            means[method_id],
            width,
            yerr=ci[method_id],
            capsize=3,
            label=method,
            color=COLORS[method_id],
            alpha=0.88,
        )
    ax.set_ylabel('Metric value', fontsize=18)
    ax.set_xticks(x)
    ax.set_xticklabels(metric_labels, fontsize=14)
    ax.tick_params(axis='y', labelsize=15)
    ax.set_ylim(0, 1.05)
    ax.grid(True, axis='y', linestyle='--', alpha=0.4)
    ax.legend(fontsize=13, frameon=True)
    fig.tight_layout()
    fig.savefig(output_path, format='pdf', dpi=600, bbox_inches='tight')
    plt.close(fig)


def main() -> None:
    cfg = Config()
    output_dir = os.path.join('output', 'incentive_redesign')
    pdf_dir = os.path.join(output_dir, 'pdf')
    os.makedirs(pdf_dir, exist_ok=True)
    configure_plot()

    group_share_runs = []
    metric_runs = []
    budget_error_runs = []
    master_rng = np.random.default_rng(cfg.seed)

    for _ in range(cfg.repetitions):
        seed = int(master_rng.integers(0, 2**32 - 1))
        trace = generate_trace(cfg, seed)
        group_index = trace['group_index']
        mechanism_shares = []
        mechanism_metrics = []
        mechanism_budget_errors = []

        for mechanism in MECHANISMS:
            result = run_mechanism(trace, cfg, mechanism)
            reward = result['reward']
            total_reward = float(reward.sum())
            group_total = np.array([
                reward[:, group_index == group_id].sum()
                for group_id in range(len(GROUPS))
            ])
            mechanism_shares.append(group_total / total_reward)

            invalid_reward = float(
                reward[trace['verification'] == 0].sum() / total_reward
            )
            high_reward = float(
                reward[:, group_index == GROUPS.index('High-value')].sum()
                / total_reward
            )
            low_reward = float(
                reward[:, group_index == GROUPS.index('Low-value')].sum()
                / total_reward
            )

            mechanism_metrics.append([
                invalid_reward,
                high_reward,
                low_reward,
            ])
            per_round_error = np.abs(
                reward.sum(axis=1) - cfg.reward_budget
            )
            mechanism_budget_errors.append(float(per_round_error.max()))

        group_share_runs.append(mechanism_shares)
        metric_runs.append(mechanism_metrics)
        budget_error_runs.append(mechanism_budget_errors)

    group_share_runs = np.asarray(group_share_runs)
    metric_runs = np.asarray(metric_runs)
    budget_error_runs = np.asarray(budget_error_runs)

    plot_group_rewards(
        group_share_runs,
        cfg.reward_budget,
        os.path.join(pdf_dir, 'scheme_group_reward_per_round.pdf'),
    )
    plot_metrics(
        metric_runs,
        os.path.join(pdf_dir, 'scheme_effectiveness_metrics.pdf'),
    )

    with open(
        os.path.join(output_dir, 'scheme_summary.csv'),
        'w', newline='', encoding='utf-8-sig'
    ) as stream:
        writer = csv.writer(stream)
        writer.writerow([
            'mechanism', 'invalid_reward_share', 'high_value_reward_share',
            'low_value_reward_share', 'max_budget_error'
        ])
        mean_metrics = metric_runs.mean(axis=0)
        max_budget_error = budget_error_runs.max(axis=0)
        for method_id, mechanism in enumerate(DISPLAY_LABELS):
            writer.writerow([
                mechanism,
                f'{mean_metrics[method_id, 0]:.6f}',
                f'{mean_metrics[method_id, 1]:.6f}',
                f'{mean_metrics[method_id, 2]:.6f}',
                f'{max_budget_error[method_id]:.12f}',
            ])

    with open(
        os.path.join(output_dir, 'scheme_group_reward_per_round.csv'),
        'w', newline='', encoding='utf-8-sig'
    ) as stream:
        writer = csv.writer(stream)
        writer.writerow(['mechanism', *GROUPS, 'total'])
        mean_group_rewards = group_share_runs.mean(axis=0) * cfg.reward_budget
        for method_id, mechanism in enumerate(DISPLAY_LABELS):
            row = mean_group_rewards[method_id]
            writer.writerow([
                mechanism,
                *[f'{value:.6f}' for value in row],
                f'{row.sum():.6f}',
            ])

    print('Incentive scheme comparison completed.')
    for method_id, mechanism in enumerate(DISPLAY_LABELS):
        print(
            f'{mechanism}: invalid reward={mean_metrics[method_id, 0]:.2%}, '
            f'high-value reward={mean_metrics[method_id, 1]:.2%}, '
            f'low-value reward={mean_metrics[method_id, 2]:.2%}, '
            f'max budget error={max_budget_error[method_id]:.3e}'
        )


if __name__ == '__main__':
    main()
