from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

import numpy as np


@dataclass(frozen=True)
class Config:
    seed: int = 42
    rounds: int = 100
    repetitions: int = 30
    # One representative node for each of the six behavior types.
    nodes_per_group: int = 1
    reward_budget: float = 20.0
    initial_reputation: float = 0.55
    score_threshold: float = 0.08
    reputation_gain: float = 0.03
    invalid_penalty: float = 0.02
    reputation_lambda: float = 20.0


GROUPS = (
    "High-value",
    "Novelty-oriented",
    "Effectiveness-oriented",
    "Medium-value",
    "Low-value",
    "Unreliable",
)

# low, high, mean, standard deviation
NOVELTY_PARAMS = np.array(
    [
        [0.75, 1.00, 0.85, 0.05],
        [0.75, 1.00, 0.85, 0.05],
        [0.30, 0.50, 0.40, 0.05],
        [0.55, 0.75, 0.65, 0.05],
        [0.20, 0.40, 0.30, 0.05],
        [0.75, 1.00, 0.85, 0.05],
    ],
    dtype=float,
)

EFFECTIVENESS_PARAMS = np.array(
    [
        [0.75, 1.00, 0.85, 0.05],
        [0.30, 0.50, 0.40, 0.05],
        [0.75, 1.00, 0.85, 0.05],
        [0.55, 0.75, 0.65, 0.05],
        [0.20, 0.40, 0.30, 0.05],
        [0.75, 1.00, 0.85, 0.05],
    ],
    dtype=float,
)


def clipped_samples(
    rng: np.random.Generator,
    params: np.ndarray,
    size: tuple[int, int],
) -> np.ndarray:
    low, high, mean, std = params
    return np.clip(rng.normal(mean, std, size=size), low, high)


def generate_trace(cfg: Config, seed: int) -> Dict[str, np.ndarray]:
    rng = np.random.default_rng(seed)
    group_count = len(GROUPS)
    nodes = group_count * cfg.nodes_per_group
    group_index = np.repeat(np.arange(group_count), cfg.nodes_per_group)

    novelty = np.zeros((cfg.rounds, nodes), dtype=float)
    effectiveness = np.zeros_like(novelty)
    verification = np.ones_like(novelty)

    for group_id in range(group_count):
        start = group_id * cfg.nodes_per_group
        end = start + cfg.nodes_per_group
        size = (cfg.rounds, cfg.nodes_per_group)
        novelty[:, start:end] = clipped_samples(
            rng, NOVELTY_PARAMS[group_id], size
        )
        effectiveness[:, start:end] = clipped_samples(
            rng, EFFECTIVENESS_PARAMS[group_id], size
        )

    unreliable = group_index == GROUPS.index("Unreliable")
    verification[:, unreliable] = (
        rng.random((cfg.rounds, unreliable.sum())) >= 0.30
    ).astype(float)

    return {
        "novelty": novelty,
        "effectiveness": effectiveness,
        "verification": verification,
        "group_index": group_index,
    }


def reputation_gate(reputation: np.ndarray, cfg: Config) -> np.ndarray:
    return 1.0 / (
        1.0 + np.exp(-cfg.reputation_lambda * (reputation - 0.5))
    )


def allocate_reward(weights: np.ndarray, budget: float) -> np.ndarray:
    total = float(weights.sum())
    if total <= 0:
        return np.zeros_like(weights)
    return budget * weights / total


def update_reputation(
    reputation: np.ndarray,
    score: np.ndarray,
    verification: np.ndarray,
    cfg: Config,
) -> np.ndarray:
    updated = reputation.copy()
    invalid = verification == 0
    accepted = (~invalid) & (score >= cfg.score_threshold)

    updated[invalid] -= cfg.invalid_penalty
    updated[accepted] += (
        cfg.reputation_gain
        * (1.0 - updated[accepted])
        * score[accepted]
    )
    return np.clip(updated, 0.0, 1.0)


def shapley_max_game(values: np.ndarray) -> np.ndarray:
    """Exact Shapley values for coalition utility U(S)=max_{i in S} value_i."""
    n = values.size
    order = np.argsort(values)
    sorted_values = values[order]
    increments = np.diff(np.concatenate(([0.0], sorted_values)))
    shared = increments / np.arange(n, 0, -1)
    sorted_phi = np.cumsum(shared)
    phi = np.empty_like(values)
    phi[order] = sorted_phi
    return phi


def run_mechanism(
    trace: Dict[str, np.ndarray],
    cfg: Config,
    mechanism: str,
) -> Dict[str, np.ndarray]:
    novelty = trace["novelty"]
    effectiveness = trace["effectiveness"]
    verification = trace["verification"]
    rounds, nodes = novelty.shape

    reputation = np.zeros((rounds + 1, nodes), dtype=float)
    reputation[0] = cfg.initial_reputation
    reward = np.zeros((rounds, nodes), dtype=float)
    score = verification * novelty * effectiveness

    for t in range(rounds):
        if mechanism == "Proposed Incentive":
            weights = score[t] * reputation_gate(reputation[t], cfg)
            weights[score[t] < cfg.score_threshold] = 0.0
        elif mechanism == "Data-quality Incentive":
            # Baseline uses semantic data quality only and has no verification gate.
            weights = novelty[t].copy()
        elif mechanism == "Reputation-Shapley Incentive":
            # Coalition utility rewards coverage of both novelty and effectiveness.
            # The baseline does not use the proposed verification gate.
            phi = 0.5 * shapley_max_game(novelty[t])
            phi += 0.5 * shapley_max_game(effectiveness[t])
            weights = phi * reputation_gate(reputation[t], cfg)
        else:
            raise ValueError(f"Unknown mechanism: {mechanism}")

        reward[t] = allocate_reward(weights, cfg.reward_budget)
        reputation[t + 1] = update_reputation(
            reputation[t], score[t], verification[t], cfg
        )

    return {
        "reputation": reputation,
        "reward": reward,
        "score": score,
    }


def group_means(values: np.ndarray, group_index: np.ndarray) -> np.ndarray:
    """Convert [..., nodes] values to [..., groups] means."""
    return np.stack(
        [values[..., group_index == group_id].mean(axis=-1)
         for group_id in range(len(GROUPS))],
        axis=-1,
    )


def mean_ci(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    mean = values.mean(axis=0)
    ci = 1.96 * values.std(axis=0, ddof=1) / np.sqrt(values.shape[0])
    return mean, ci


def rankdata_average(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values)
    ranks = np.empty(values.size, dtype=float)
    sorted_values = values[order]
    start = 0
    while start < values.size:
        end = start + 1
        while end < values.size and sorted_values[end] == sorted_values[start]:
            end += 1
        ranks[order[start:end]] = 0.5 * (start + end - 1) + 1.0
        start = end
    return ranks


def spearman_correlation(x: np.ndarray, y: np.ndarray) -> float:
    rx = rankdata_average(x)
    ry = rankdata_average(y)
    if np.std(rx) == 0 or np.std(ry) == 0:
        return 0.0
    return float(np.corrcoef(rx, ry)[0, 1])
